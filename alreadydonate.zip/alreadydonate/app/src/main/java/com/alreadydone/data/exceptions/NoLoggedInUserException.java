package com.alreadydone.data.exceptions;

public class NoLoggedInUserException extends DataException {
}
