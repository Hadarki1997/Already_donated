package com.alreadydone.control.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.alreadydone.R;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Optional;

public class CampaignRejectInfoDialog extends Dialog {

    private final String description;

    public CampaignRejectInfoDialog(@NonNull Context context, String description) {
        super(context);
        this.description = description;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.reject_info_dialog);

        final View continueBtn = findViewById(R.id.continueBtn);
        final TextView descriptionTxt = findViewById(R.id.description);

        descriptionTxt.setText(description);

        continueBtn.setOnClickListener((v)-> {
            dismiss();
        });
    }
}
