package com.alreadydone.data.meta;

import com.google.firebase.database.DataSnapshot;

import java.util.Map;

public interface ModelMeta<T> {

    String getRefName();
    String getId(T t);

    Map<String, Object> serialize(T t);
    T parse(DataSnapshot dataSnapshot);

    Object serializeValue(Object value);
}
