package com.alreadydone.data.model;

public enum CampaignState {
    PENDING_APPROVAL,
    APPROVAL_REJECTED,
    ONGOING,
    CLOSED
}
