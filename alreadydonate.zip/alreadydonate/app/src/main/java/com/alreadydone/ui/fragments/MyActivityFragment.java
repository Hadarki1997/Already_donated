package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.DonationInfoObserver;
import com.alreadydone.data.Filters;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.ui.ActivitiesHelper;

import java.util.Optional;

public class MyActivityFragment extends Fragment {

    private String associationId;
    private RecyclerListController<FullDonationInfo> donationsController;
    private DonationInfoObserver donationInfoObserver;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_activity, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        LoginRepository loginRepository = LoginRepository.getInstance();
        Optional<LoggedInUser> optional = loginRepository.getLoggedUser();
        if (!optional.isPresent()) {
            ActivitiesHelper.moveToLogin(getActivity());
            return;
        }

        final Bundle arguments = getArguments();
        associationId = arguments.getString("id", null);

        final RecyclerView donationsView = view.findViewById(R.id.view_donations);
        donationsController =
                RecyclerHelper.loadDonationsInto(donationsView, (item)-> {});
        donationInfoObserver = MainRepository.getInstance().createDonationObserver(donationsController, Filters.noFilter());
    }

    @Override
    public void onResume() {
        super.onResume();

        if (associationId != null) {
            donationInfoObserver.reFilter(Filters.donationToAssociation(associationId));
        } else {
            donationInfoObserver.reFilter(Filters.nothing());
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        donationInfoObserver.close();
    }
}