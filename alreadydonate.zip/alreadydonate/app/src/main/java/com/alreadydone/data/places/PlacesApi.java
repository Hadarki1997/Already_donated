package com.alreadydone.data.places;

import android.content.Context;
import android.text.TextUtils;

import com.alreadydone.BuildConfig;
import com.alreadydone.util.Logger;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.net.PlacesClient;

public class PlacesApi {

    private final PlacesClient client;

    public PlacesApi(Context context) {
        String apiKey = BuildConfig.PLACES_API_KEY;

        //noinspection ConstantValue
        if (TextUtils.isEmpty(apiKey) || apiKey.equals("DEFAULT_API_KEY")) {
            Logger.error("Places API key missing");
            throw new Error("PLACES API KEY MISSING");
        }

        Places.initialize(context.getApplicationContext(), apiKey);
        client = Places.createClient(context);
    }

    public PlacesAutocompletePredictions createAutocomplete() {
        return new PlacesAutocompletePredictions(client);
    }
}
