package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.campaigns.CampaignRowConfig;
import com.alreadydone.control.dialogs.CampaignRejectInfoDialog;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.control.recyclerview.SingleSelectableRecyclerListController;
import com.alreadydone.data.CampaignInfoObserver;
import com.alreadydone.data.Filters;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.CampaignApprovalState;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.data.model.FundraisingType;
import com.alreadydone.data.model.FundraisingTypeData;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.ui.ActivitiesHelper;
import com.alreadydone.util.future.Future;

import java.util.Optional;

public class MyFundraisingFragment extends Fragment {

    private String associationId;
    private RecyclerListController<CampaignAndDonations> campaignListController;
    private CampaignInfoObserver campaignInfoObserver;
    private CampaignInfoObserver campaignInfoObserverForTypes;
    private SingleSelectableRecyclerListController<FundraisingTypeData> typeListController;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_fundraising, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        LoginRepository loginRepository = LoginRepository.getInstance();
        Optional<LoggedInUser> optional = loginRepository.getLoggedUser();
        if (!optional.isPresent()) {
            ActivitiesHelper.moveToLogin(getActivity());
            return;
        }

        final Bundle arguments = getArguments();
        associationId = arguments.getString("id", null);

        final RecyclerView typesView = view.findViewById(R.id.view_types);
        final RecyclerView campaignsView = view.findViewById(R.id.view_campaigns);

        campaignListController =
                RecyclerHelper.loadCampaignsInto(campaignsView, CampaignRowConfig.forAssociationList(), (campaign, clickType)-> {
                    switch (clickType) {
                        case CAMPAIGN:
                            ActivitiesHelper.moveToCampaign(getActivity(), campaign.getCampaign().getId());
                            break;
                        case EDIT:
                            if (campaign.getCampaign().getState() == CampaignState.APPROVAL_REJECTED) {
                                ActivitiesHelper.moveToEditCampaign(requireActivity(), campaign.getCampaign().getId());
                            }
                            break;
                        case SHARE:
                            break;
                        case SEE_MORE: {
                            if (campaign.getCampaign().getState() == CampaignState.APPROVAL_REJECTED) {
                                MainRepository mainRepository = MainRepository.getInstance();
                                Future.checkedCall(
                                        ()-> mainRepository.getApprovalState(campaign.getCampaign().getId()),
                                        (result)-> {
                                            if (result.hasValue()) {
                                                CampaignApprovalState state = result.getValue();
                                                if (!state.isRejected()) {
                                                    return;
                                                }

                                                CampaignRejectInfoDialog dialog = new CampaignRejectInfoDialog(requireContext(), state.getDescription());
                                                dialog.show();
                                            }
                                        }
                                );
                            }
                            break;
                        }
                    }
        });
        typeListController =
                RecyclerHelper.loadFundraisingTypeSmallInto(typesView, (type)-> {
                    if (type != null && associationId != null && campaignInfoObserver != null) {
                        campaignInfoObserver.reFilter(FundraisingType.typeFilter(type.type));
                    }
                });
        CampaignInfoObserver.TypedCampaignControl typedCampaignControl = new CampaignInfoObserver.TypedCampaignControl(typeListController);
        typedCampaignControl.load();

        campaignInfoObserver = MainRepository.getInstance().createCampaignObserver(campaignListController, Filters.campaignOfAssociation(associationId));
        campaignInfoObserverForTypes = MainRepository.getInstance().createCampaignObserver(typedCampaignControl, Filters.campaignOfAssociation(associationId));

        campaignInfoObserver.reFilter(FundraisingType.typeFilter(FundraisingType.ALL));
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        campaignInfoObserver.close();
        campaignInfoObserverForTypes.close();
    }
}