package com.alreadydone.ui;

import android.app.Activity;
import android.content.Intent;

import com.alreadydone.ui.login.LoginActivity;
import com.alreadydone.ui.login.SignUpActivity;

public class ActivitiesHelper {

    public static void moveToMain(Activity currentActivity) {
        Intent intent = new Intent(currentActivity, MainActivity.class);
        currentActivity.startActivity(intent);
    }

    public static void moveToCampaign(Activity currentActivity, String campaignId) {
        Intent intent = new Intent(currentActivity, CampaignActivity.class);
        intent.putExtra("id", campaignId);
        currentActivity.startActivity(intent);
    }

    public static void moveToAdminCampaign(Activity currentActivity, String campaignId) {
        Intent intent = new Intent(currentActivity, AdminCampaignActivity.class);
        intent.putExtra("id", campaignId);
        currentActivity.startActivity(intent);
    }

    public static void moveToDonate(Activity currentActivity, String campaignId) {
        Intent intent = new Intent(currentActivity, DonateActivity.class);
        intent.putExtra("id", campaignId);
        currentActivity.startActivity(intent);
    }

    public static void moveToAddCard(Activity currentActivity) {
        Intent intent = new Intent(currentActivity, AddCardActivity.class);
        currentActivity.startActivity(intent);
    }

    public static void moveToAssociation(Activity currentActivity, String associationId) {
        Intent intent = new Intent(currentActivity, AssociationActivity.class);
        intent.putExtra("id", associationId);
        currentActivity.startActivity(intent);
    }

    public static void moveToNewCampaign(Activity currentActivity, String associationId) {
        Intent intent = new Intent(currentActivity, NewCampaignActivity.class);
        intent.putExtra("associationId", associationId);
        currentActivity.startActivity(intent);
    }

    public static void moveToLogin(Activity currentActivity) {
        Intent intent = new Intent(currentActivity, LoginActivity.class);
        currentActivity.startActivity(intent);
    }

    public static void moveToSignUp(Activity currentActivity) {
        Intent intent = new Intent(currentActivity, SignUpActivity.class);
        currentActivity.startActivity(intent);
    }

    public static void moveToAccountSetup(Activity currentActivity) {
        Intent intent = new Intent(currentActivity, AccountSetupActivity.class);
        currentActivity.startActivity(intent);
    }

    public static void moveToEditCampaign(Activity currentActivity, String campaignId) {
        Intent intent = new Intent(currentActivity, EditCampaignActivity.class);
        intent.putExtra("campaignId", campaignId);
        currentActivity.startActivity(intent);
    }
}
