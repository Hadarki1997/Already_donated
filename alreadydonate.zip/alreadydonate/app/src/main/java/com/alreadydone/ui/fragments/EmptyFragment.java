package com.alreadydone.ui.fragments;

import androidx.fragment.app.Fragment;

public class EmptyFragment extends Fragment {
}
