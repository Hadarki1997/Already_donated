package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.ui.ActivitiesHelper;
import com.google.android.material.tabs.TabLayout;

import java.util.Arrays;

public class AssociationCampaignFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_association_campaigns, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        String associationId = args.getString("associationId");

        final ViewPager2 pager = view.findViewById(R.id.pager);
        final TabLayout tabs = view.findViewById(R.id.tabs);
        final View addBtn = view.findViewById(R.id.add_btn);

        Bundle additionalArgs = new Bundle();
        additionalArgs.putString("id", associationId);

        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(this,
                Arrays.asList(
                        new GenericPagerAdapter.FragmentDef(MyFundraisingFragment::new),
                        new GenericPagerAdapter.FragmentDef(MyActivityFragment::new)
                ),
                additionalArgs
            ));

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                pager.setCurrentItem(tab.getPosition(), false);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        addBtn.setOnClickListener((v)-> {
            ActivitiesHelper.moveToNewCampaign(getActivity(), associationId);
        });
    }
}
