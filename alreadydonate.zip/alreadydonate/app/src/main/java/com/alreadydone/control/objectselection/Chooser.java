package com.alreadydone.control.objectselection;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import androidx.activity.result.ActivityResultCaller;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.alreadydone.util.RunningJob;
import com.alreadydone.util.future.Future;

public class Chooser {

    private final Context context;
    private final RequiredActivityResults activityResults;

    public Chooser(Context context, ActivityResultCaller resultCaller) {
        this.context = context;
        activityResults = new RequiredActivityResults(resultCaller, context.getMainLooper());
    }

    public static Chooser create(AppCompatActivity activity) {
        return new Chooser(activity, activity);
    }

    public static Chooser create(Fragment fragment) {
        return new Chooser(fragment.requireContext(), fragment);
    }

    public Future<Uri> start(Intent requestIntent, String[] neededPermissions) {
        RunningJob<Uri> job = new RunningJob<>(context.getMainLooper());
        ChooserRunner runner = new ChooserRunner(context, job, activityResults, neededPermissions);
        job.setBean(runner);

        runner.start(requestIntent);
        return Future.create(job);
    }
}
