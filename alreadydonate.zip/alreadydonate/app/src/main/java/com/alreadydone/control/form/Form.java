package com.alreadydone.control.form;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class Form {

    public static class FieldBuilder<T> {

        protected final Builder builder;
        protected final String name;
        protected final FormInput<T> input;

        protected final List<Validator<T>> validators;

        public FieldBuilder(Builder builder, String name, FormInput<T> input) {
            this.builder = builder;
            this.name = name;
            this.input = input;

            validators = new ArrayList<>();
        }

        public FieldBuilder<T> withValidator(Validator<T> validator) {
            validators.add(validator);
            return this;
        }

        public <T2> FieldBuilder<T2> convert(Converter<T, T2> converter) {
            return new ConvertedFieldBuilder<>(builder, name, this, converter);
        }

        public <T2> FieldBuilder<T2> convert(Function<T, T2> converter, Validator<T> preConversionValidator) {
            return convert(Converter.create(converter, preConversionValidator));
        }

        public Builder build() {
            builder.addField(name, createField());
            return builder;
        }

        FormField<T> createField() {
            return new BaseFormField<>(input, new Validator.GroupValidator<>(validators));
        }
    }

    public static class ConvertedFieldBuilder<T, T2> extends FieldBuilder<T2> {

        private final FieldBuilder<T> originalBuilder;
        private final Converter<T, T2> converter;

        public ConvertedFieldBuilder(Builder builder,
                                     String name,
                                     FieldBuilder<T> originalBuilder,
                                     Converter<T, T2> converter) {
            super(builder, name, null);
            this.originalBuilder = originalBuilder;
            this.converter = converter;
        }

        public Builder build() {
            FormField<T> base = originalBuilder.createField();
            FormField<T2> converted = base.as(converter, new Validator.GroupValidator<>(validators));

            builder.addField(name, converted);
            return builder;
        }
    }

    public static class Builder {

        private final Map<String, FormField<?>> fields;

        public Builder() {
            fields = new HashMap<>();
        }

        public <T> FieldBuilder<T> register(String name, FormInput<T> input) {
            return new FieldBuilder<>(this, name, input);
        }

        public Form build() {
            return new Form(fields);
        }

        void addField(String name, FormField<?> field) {
            fields.put(name, field);
        }
    }

    private final Map<String, FormField<?>> fields;

    public Form(Map<String, FormField<?>> fields) {
        this.fields = new HashMap<>(fields);
    }

    public void enableAutoValidation() {
        for (FormField<?> field : fields.values()) {
            field.enableAutoValidate();
        }
    }

    public FormResult getResult() {
        Map<String, ValidatedValue<?>> values = new HashMap<>();
        for (Map.Entry<String, FormField<?>> entry : fields.entrySet()) {
            values.put(entry.getKey(), entry.getValue().validateAndGetValue());
        }

        return new FormResult(values);
    }
}
