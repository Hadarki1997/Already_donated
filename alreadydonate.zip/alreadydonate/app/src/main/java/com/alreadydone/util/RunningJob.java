package com.alreadydone.util;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import androidx.annotation.NonNull;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

public class RunningJob<R> {

    private static final int WHAT_COMPLETE = 0x1122;

    private final Handler handler;
    private final Queue<Consumer<Result<R>>> completeQueue;
    private final AtomicReference<Result<R>> result;

    private Object bean;

    public RunningJob(Looper looper) {
        handler = new Handler(looper) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                Result<R> result = RunningJob.this.result.get();

                if (msg.obj != null) {
                    //noinspection unchecked
                    Consumer<Result<R>> consumer = (Consumer<Result<R>>) msg.obj;
                    consumer.accept(result);
                } else {
                    invokeAllConsumers(result);
                }
            }
        };
        completeQueue = new LinkedList<>();
        result = new AtomicReference<>();
    }

    public void setBean(Object bean) {
        this.bean = bean;
    }

    public synchronized void onComplete(Consumer<Result<R>> consumer) {
        Result<R> result = this.result.get();
        if (result != null) {
            Message message = handler.obtainMessage(WHAT_COMPLETE);
            message.obj = consumer;
            message.sendToTarget();
        } else {
            completeQueue.add(consumer);
        }
    }

    public synchronized void markComplete(Result<R> result) {
        this.result.set(result);

        Message message = handler.obtainMessage(WHAT_COMPLETE);
        message.sendToTarget();
    }

    public void markFinished(R value) {
        markComplete(Result.value(value));
    }

    public void markErrored(Throwable error) {
        markComplete(Result.error(error));
    }

    private synchronized void invokeAllConsumers(Result<R> result) {
        for (Consumer<Result<R>> consumer : completeQueue) {
            consumer.accept(result);
        }
    }
}
