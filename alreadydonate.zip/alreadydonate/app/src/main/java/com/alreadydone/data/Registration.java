package com.alreadydone.data;

public interface Registration {

    void close();
}
