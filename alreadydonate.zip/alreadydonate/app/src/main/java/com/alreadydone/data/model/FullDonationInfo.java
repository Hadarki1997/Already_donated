package com.alreadydone.data.model;

public class FullDonationInfo {

    private Donation donation;
    private Campaign campaign;
    private User user;

    public FullDonationInfo(Donation donation, Campaign campaign, User user) {
        this.donation = donation;
        this.campaign = campaign;
        this.user = user;
    }

    public Donation getDonation() {
        return donation;
    }

    public void setDonation(Donation donation) {
        this.donation = donation;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
