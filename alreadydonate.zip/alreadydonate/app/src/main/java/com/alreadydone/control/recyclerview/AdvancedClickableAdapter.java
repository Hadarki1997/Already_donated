package com.alreadydone.control.recyclerview;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public class AdvancedClickableAdapter<T, A extends RecyclerView.ViewHolder, C> extends BaseAdapter<T, A> {

    private final BiFunction<T, A, Map<View, C>> clicksDefiner;
    private final AtomicReference<BiConsumer<T, C>> onClick;

    public AdvancedClickableAdapter(int layoutId, Function<View, A> aCreator, BiConsumer<T, A> bind, BiFunction<T, A, Map<View, C>> clicksDefiner) {
        super(layoutId, aCreator, bind);
        this.clicksDefiner = clicksDefiner;

        this.onClick = new AtomicReference<>();
    }

    public void setOnClick(BiConsumer<T, C> onClick) {
        this.onClick.set(onClick);
    }

    @Override
    public void onBindViewHolder(@NonNull A holder, int position) {
        super.onBindViewHolder(holder, position);

        T t = list.get(position);
        Map<View, C> defs = clicksDefiner.apply(t, holder);
        for (Map.Entry<View, C> def : defs.entrySet()) {
            View view = def.getKey();
            C c = def.getValue();

            view.setClickable(true);
            view.setOnClickListener((v)-> {
                onClick(t, c);
            });
        }
    }

    private void onClick(T t, C c) {
        BiConsumer<T, C> onSelect = this.onClick.get();
        if (onSelect != null) {
            onSelect.accept(t, c);
        }
    }
}
