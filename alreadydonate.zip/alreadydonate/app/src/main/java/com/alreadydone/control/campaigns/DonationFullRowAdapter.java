package com.alreadydone.control.campaigns;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.ClickableAdapter;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.util.Logger;
import com.bumptech.glide.Glide;

import java.util.Locale;

public class DonationFullRowAdapter extends ClickableAdapter<FullDonationInfo, DonationFullRowAdapter.ViewHolder> {

    public DonationFullRowAdapter() {
        super(R.layout.donation_full_box, ViewHolder::new, DonationFullRowAdapter::bindView);
    }

    private static void bindView(FullDonationInfo item, DonationFullRowAdapter.ViewHolder holder) {
        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        int height = holder.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.campaign_box_height_expanded);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);

        int margin = holder.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.campaign_box_margin);
        params.setMargins(margin, margin, margin, margin);

        holder.itemView.setLayoutParams(params);

        Campaign campaign = item.getCampaign();

        StorageRepository repository = StorageRepository.getInstance();
        repository.getCampaignImage(campaign.getId()).onComplete((result)-> {
            if (result.hasValue()) {
                Glide.with(holder.image.getContext())
                        .load(result.getValue())
                        .into(holder.image);
            } else {
                Logger.error("Failed to retrieve image for campaign", result.getError());
                holder.image.setImageResource(R.drawable.groups);
            }
        });

        holder.name.setText(campaign.getName());
        holder.donatedMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.getRaisedAmount()));
        holder.requiredMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.getGoalAmount()));
        holder.daysLeft.setText(String.format(Locale.ENGLISH, "%d", campaign.getDaysLeftToDonate()));
        holder.progressBar.setProgress((int) campaign.getRaisedAmount());
        holder.progressBar.setMax((int) campaign.getGoalAmount());

        holder.donationAmount.setText(String.format(Locale.ENGLISH, "$%d", (int) item.getDonation().getAmount()));
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView image;
        public final TextView name;
        public final TextView donatedMoney;
        public final TextView requiredMoney;
        public final TextView daysLeft;
        public final ProgressBar progressBar;
        public final TextView donationAmount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            donatedMoney = itemView.findViewById(R.id.raised_money);
            requiredMoney = itemView.findViewById(R.id.total_money);
            daysLeft = itemView.findViewById(R.id.days_left);
            progressBar = itemView.findViewById(R.id.progress_bar);
            donationAmount = itemView.findViewById(R.id.donation_amount);
        }
    }
}
