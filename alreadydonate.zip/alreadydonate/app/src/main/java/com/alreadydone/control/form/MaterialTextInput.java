package com.alreadydone.control.form;

import android.text.Editable;
import android.text.TextWatcher;

import com.google.android.material.textfield.TextInputEditText;

import java.util.function.Consumer;

public class MaterialTextInput implements FormInput<String> {

    private final TextInputEditText field;

    public MaterialTextInput(TextInputEditText field) {
        this.field = field;
    }

    @Override
    public String getValue() {
        return field.getText().toString();
    }

    @Override
    public void setValid() {
        field.setError(null);
    }

    @Override
    public void setError(String message) {
        field.setError(message);
    }

    @Override
    public void registerForValueChanges(Consumer<String> consumer) {
        field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String value = s.toString();
                consumer.accept(value);
            }
        });
    }
}
