package com.alreadydone.data.exceptions;

public class ElementDoesNotExistException extends DataException {

    public ElementDoesNotExistException() {
        super();
    }
}
