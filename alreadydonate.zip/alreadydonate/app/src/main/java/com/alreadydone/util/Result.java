package com.alreadydone.util;

import androidx.annotation.NonNull;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;

public class Result<T> {

    private final T value;
    private final boolean hasValue;
    private final Throwable error;

    private Result(T value, boolean hasValue, Throwable error) {
        this.value = value;
        this.hasValue = hasValue;
        this.error = error;
    }

    public static <T> Result<T> value(T value) {
        return new Result<>(value, true, null);
    }

    public static <T> Result<T> error(Throwable error) {
        return new Result<>(null, false, error);
    }

    public boolean hasValue() {
        return hasValue;
    }

    public boolean hasError() {
        return error != null;
    }

    public T getValue() {
        if (!hasValue()) {
            throw new IllegalStateException("no value");
        }

        return value;
    }

    public Throwable getError() {
        if (!hasError()) {
            throw new IllegalStateException("no error");
        }

        return error;
    }

    public Optional<T> asOptional() {
        if (hasError()) {
            return Optional.empty();
        } else {
            return Optional.of(value);
        }
    }

    public T getOr(Supplier<T> supplier) {
        if (hasError()) {
            return supplier.get();
        }

        return getValue();
    }

    public T getOrThrow() throws Throwable {
        if (hasError()) {
            throw error;
        } else {
            return value;
        }
    }

    public <E extends Throwable> T getOrThrowAs(Class<E> exClass, Function<Throwable, E> errorCreator) throws E {
        if (hasError()) {
            if (exClass.isInstance(error)) {
                //noinspection DataFlowIssue
                throw exClass.cast(error);
            } else {
                throw errorCreator.apply(error);
            }
        } else {
            return value;
        }
    }

    public <E extends Throwable> T getOrThrowAs(Class<E> exClass) throws E {
        return getOrThrowAs(exClass, (t)-> {
            try {
                Constructor<E> ctor = exClass.getConstructor(Throwable.class);
                return ctor.newInstance(t);
            } catch (NoSuchMethodException | IllegalAccessException | InstantiationException |
                     InvocationTargetException e) {
                throw new IllegalArgumentException("exception class has no usable cause constructor", e);
            }
        });
    }

    public T getOrThrowRuntime() {
        if (hasError()) {
            if (error instanceof RuntimeException) {
                throw (RuntimeException) error;
            } else {
                throw new RuntimeException(error);
            }
        } else {
            return value;
        }
    }

    public <R> Result<R> as(Function<T, R> converter) {
        if (hasError()) {
            return Result.error(this.error);
        } else {
            try {
                R value = converter.apply(this.value);
                return Result.value(value);
            } catch (Throwable t) {
                return Result.error(t);
            }
        }
    }

    @NonNull
    @Override
    public String toString() {
        if (hasError()) {
            return String.format(Locale.ENGLISH, "Result{error=%s}", error.toString());
        } else {
            return String.format(Locale.ENGLISH, "Result{%s}", value);
        }
    }
}
