package com.alreadydone.control.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.alreadydone.R;

public class SuccessDialog extends Dialog {

    private final Info info;

    public SuccessDialog(@NonNull Context context, Info info) {
        super(context);
        this.info = info;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.success_dialog);

        final View continueBtn = findViewById(R.id.continueBtn);
        final TextView title = findViewById(R.id.title);
        final TextView description = findViewById(R.id.description);
        final TextView btnTxt = findViewById(R.id.btn_txt);

        title.setText(info.title);
        description.setText(info.description);
        btnTxt.setText(info.buttonText);

        continueBtn.setOnClickListener((v)-> {
            dismiss();
        });
    }

    public static class Info {
        public final int title;
        public final int description;
        public final int buttonText;

        public Info(int title, int description, int buttonText) {
            this.title = title;
            this.description = description;
            this.buttonText = buttonText;
        }
    }
}
