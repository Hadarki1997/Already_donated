package com.alreadydone.control;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;

import java.util.List;
import java.util.Locale;
import java.util.function.IntConsumer;

public class PaymentOptionAdapter extends RecyclerView.Adapter<PaymentOptionAdapter.ViewHolder> {

    private final List<Integer> options;
    private final IntConsumer onClick;

    private ViewHolder selected;

    public PaymentOptionAdapter(List<Integer> options, IntConsumer onClick) {
        this.options = options;
        this.onClick = onClick;

        selected = null;
    }

    @NonNull
    @Override
    public PaymentOptionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View view = inflater.inflate(R.layout.payment_option_small, parent, false);
        return new PaymentOptionAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentOptionAdapter.ViewHolder holder, int position) {
        int amount = options.get(position);

        holder.amount.setText(String.format(Locale.ENGLISH, "$%d", amount));
        holder.itemView.setClickable(true);
        holder.itemView.setOnClickListener((v)-> {
            select(holder, amount);
        });
    }

    @Override
    public int getItemCount() {
        return options.size();
    }

    private void select(ViewHolder holder, int amount) {
        if (selected != null) {
            selected.itemView.setSelected(false);
        }

        selected = holder;
        holder.itemView.setSelected(true);
        onClick.accept(amount);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final TextView amount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            amount = itemView.findViewById(R.id.amount);
        }
    }
}
