package com.alreadydone.data.model;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.function.Predicate;

public enum FundraisingType {
    ALL,
    ONGOING,
    PAST,
    PENDING,
    REJECTED
    ;

    public static Predicate<Campaign> typeFilter(FundraisingType type) {
        return (campaign)-> type == FundraisingType.ALL || getTypeForCampaign(campaign) == type;
    }

    public static FundraisingType getTypeForCampaign(Campaign campaign) {
        ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
        switch (campaign.getState()) {
            case PENDING_APPROVAL:
                return FundraisingType.PENDING;
            case APPROVAL_REJECTED:
                return FundraisingType.REJECTED;
            case ONGOING: {
                if (campaign.getEndTime().isBefore(now)) {
                    return FundraisingType.PAST;
                }

                return FundraisingType.ONGOING;
            }
            default:
                return FundraisingType.PAST;
        }
    }
}
