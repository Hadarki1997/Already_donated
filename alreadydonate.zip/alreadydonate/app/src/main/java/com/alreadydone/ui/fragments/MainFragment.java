package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.fragments.GenericPagerAdapter;

import java.util.Arrays;

public class MainFragment extends Fragment {

    private View navbar1;
    private View navbar2;
    private ViewPager2 pager;
    private TextView navbar2_pageTitle;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle ourArgs = getArguments();
        String userId = ourArgs.getString("userId");

        navbar1 = view.findViewById(R.id.navbar_1);
        navbar2 = view.findViewById(R.id.navbar_2);

        final View navbar1_bookmarksButton = view.findViewById(R.id.bookmark_btn);
        final View navbar1_searchBtn = view.findViewById(R.id.search_btn);

        final View navbar2_backBtn = view.findViewById(R.id.back_arrow);
        navbar2_pageTitle = view.findViewById(R.id.page_title);

        pager = view.findViewById(R.id.pager);

        navbar1_bookmarksButton.setOnClickListener((v)-> {
            switchView(1);
        });
        navbar1_searchBtn.setOnClickListener((v)-> {
            switchView(4);
        });
        navbar2_backBtn.setOnClickListener((v)-> {
            switchView(0);
        });

        Bundle additionalArgs = new Bundle();
        additionalArgs.putString("userId", userId);

        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                Arrays.asList(
                        new GenericPagerAdapter.FragmentDef(CampaignSummaryFragment::new),
                        new GenericPagerAdapter.FragmentDef(CampaignViewFragment::new, (args)-> {
                            args.putInt("viewType", CampaignViewFragment.ViewType.BOOKMARKS.ordinal());
                        }),
                        new GenericPagerAdapter.FragmentDef(CampaignViewFragment::new, (args)-> {
                            args.putInt("viewType", CampaignViewFragment.ViewType.URGENT.ordinal());
                        }),
                        new GenericPagerAdapter.FragmentDef(CampaignViewFragment::new, (args)-> {
                            args.putInt("viewType", CampaignViewFragment.ViewType.COMING_TO_AN_END.ordinal());
                        }),
                        new GenericPagerAdapter.FragmentDef(CampaignViewFragment::new, (args)-> {
                            args.putInt("viewType", CampaignViewFragment.ViewType.SEARCH.ordinal());
                        })
                ),
                additionalArgs
            ));
    }

    @Override
    public void onStart() {
        super.onStart();
        switchView(0);
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void switchViewToUrgentView() {
        switchView(2);
    }

    public void switchViewToComingToAnEndView() {
        switchView(3);
    }

    private void switchView(int index) {
        if (index == 0) {
            navbar1.setVisibility(View.VISIBLE);
            navbar2.setVisibility(View.GONE);
        } else if (index <= 4) {
            navbar1.setVisibility(View.GONE);
            navbar2.setVisibility(View.VISIBLE);

            CampaignViewFragment.ViewType type = CampaignViewFragment.ViewType.values()[index - 1];
            navbar2_pageTitle.setText(type.getPageTitle());
        } else if (index == 5) {
            navbar1.setVisibility(View.GONE);
            navbar2.setVisibility(View.GONE);
        }

        pager.setCurrentItem(index, false);
    }
}
