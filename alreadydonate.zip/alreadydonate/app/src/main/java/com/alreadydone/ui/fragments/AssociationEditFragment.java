package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.alreadydone.R;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.alreadydone.control.objectselection.UploadProfilePic;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Association;
import com.alreadydone.exceptions.CancelledException;
import com.alreadydone.util.Logger;
import com.alreadydone.util.future.Future;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;

public class AssociationEditFragment extends Fragment {

    private UploadProfilePic uploadProfilePic;
    private TextInputEditText nameTxt;
    private TextInputEditText descriptionTxt;

    private ImageView profilePic;
    private View profilePicEdit;

    private View continueBtn;
    private Form form;

    private String userId;
    private Uri selectedPicUri;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_edit_association, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        userId = args.getString("userId");

        uploadProfilePic = UploadProfilePic.create(this);

        profilePicEdit = view.findViewById(R.id.profile_pic_edit);
        profilePicEdit.setEnabled(false);

        profilePic = view.findViewById(R.id.setting_profile_image);

        nameTxt = view.findViewById(R.id.name);
        descriptionTxt = view.findViewById(R.id.description);
        continueBtn = view.findViewById(R.id.continueBtn);
        final View backArrow = view.findViewById(R.id.back_arrow);

        backArrow.setOnClickListener((v)-> {
            getParent().cancelAssociationEdit();
        });

        form = new Form.Builder()
                .register("Name", FormInput.create(nameTxt))
                    .withValidator(Validators.longEnough(3))
                    .build()
                .register("Description", FormInput.create(descriptionTxt))
                    .withValidator(Validators.longEnough(5))
                    .build()
                .build();
        form.enableAutoValidation();

        profilePicEdit.setOnClickListener((v)-> {
            profilePicEdit.setEnabled(false);

            Future.checkedCall(
                    uploadProfilePic::start,
                    (result)-> {
                        profilePicEdit.setEnabled(true);

                        if (result.hasValue()) {
                            Uri uri = result.getValue();
                            selectedPicUri = uri;
                            Glide.with(this)
                                    .load(uri)
                                    .into(profilePic);
                        } else {
                            selectedPicUri = null;
                            Throwable error = result.getError();
                            Logger.debug("failed to load image", error);

                            if (error instanceof CancelledException) {
                                // this is fine
                                return;
                            }

                            Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
            );
        });

        continueBtn.setOnClickListener((v)-> {
            FormResult result = form.getResult();
            if (!result.areAllValid()) {
                return;
            }

            String name = result.getField("Name", String.class).trim();
            String description = result.getField("Description", String.class).trim();

            AssociationEditParent.EditableAssociationInfo info = new AssociationEditParent.EditableAssociationInfo();
            info.profilePicture = selectedPicUri;
            info.name = name;
            info.description = description;

            getParent().saveAssociationInfo(info);
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        loadData();
    }

    private void loadData() {
        profilePicEdit.setEnabled(true);
        continueBtn.setEnabled(true);

        if (userId != null) {
            loadDataForExisting(userId);
        }
    }

    private void loadDataForExisting(String userId) {
        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        Future.checkedCall(
                ()-> mainRepository.getAssociationForUser(userId),
                (result)-> {
                    if (result.hasValue()) {
                        Association association = result.getValue();

                        nameTxt.setText(association.getName());
                        descriptionTxt.setText(association.getDescription());

                        profilePicEdit.setEnabled(false);
                        Future.checkedCall(
                                ()-> storageRepository.getAssociationImage(association.getId()),
                                (resultUri)-> {
                                    profilePicEdit.setEnabled(true);

                                    if (resultUri.hasValue()) {
                                        Glide.with(this)
                                                .load(resultUri.getValue())
                                                .into(profilePic);
                                    } else {
                                        Throwable error = resultUri.getError();
                                        Logger.debug("failed to load image", error);
                                        Toast.makeText(getContext(), "Failed to load profile pic", Toast.LENGTH_LONG).show();
                                    }
                                }
                        );
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to load association info", error);
                    }
                }
        );
    }

    private AssociationEditParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof AssociationEditParent) {
            return (AssociationEditParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof AssociationEditParent) {
            return (AssociationEditParent) activity;
        }

        throw new IllegalStateException("parent does not support saving");
    }

    private void resetPic() {
        selectedPicUri = null;
        profilePic.setImageResource(R.drawable.ic_users);
    }
}
