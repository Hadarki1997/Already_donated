package com.alreadydone.exceptions;

import java.util.Map;

public class PermissionNotGrantedException extends Exception {

    public PermissionNotGrantedException(Map<String, Boolean> permissions) {
        super(permissions.toString());
    }
}
