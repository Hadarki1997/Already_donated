package com.alreadydone.data.exceptions;

public class ElementAlreadyExistsException extends DataException {
}
