package com.alreadydone.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.exceptions.ElementAlreadyExistsException;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.data.model.CampaignWrapper;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.databinding.ActivityCampaignBinding;
import com.alreadydone.util.Logger;
import com.alreadydone.util.function.BasicProperty;
import com.bumptech.glide.Glide;

import java.io.File;
import java.util.Locale;
import java.util.Optional;

public class CampaignActivity extends AppCompatActivity {

    private ActivityCampaignBinding binding;
    private String campaignId = null;
    private Campaign campaign = null;

    private final BasicProperty<File> proposalDocFile = new BasicProperty<>(null);
    private final BasicProperty<File> medicalDocFile = new BasicProperty<>(null);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityCampaignBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final View donateBtn = binding.donateBtn;
        final View backBtn = binding.back;
        final View bookmarkBtn = binding.bookmarkBtn;
        final View proposalDocLayout = binding.proposaldocLayout;
        final View medicalDocLayout = binding.medicaldocLayout;
        final ImageView image = binding.image;
        final RecyclerView imagesView = binding.imagesView;
        final View associationLayout = binding.associationLayout;

        image.setVisibility(View.VISIBLE);
        imagesView.setVisibility(View.GONE);
        proposalDocLayout.setVisibility(View.GONE);
        medicalDocLayout.setVisibility(View.GONE);
        donateBtn.setEnabled(false);

        proposalDocLayout.setOnClickListener((v)-> {
            File file = proposalDocFile.get();
            if (file == null) {
                return;
            }

            Uri uri = FileProvider.getUriForFile(this,
                    getApplicationContext().getPackageName() + ".provider",
                    file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(uri, "text/plain");
            startActivity(intent);
        });
        medicalDocLayout.setOnClickListener((v)-> {
            File file = medicalDocFile.get();
            if (file == null) {
                return;
            }

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(Uri.fromFile(file), "text/plain");
            startActivity(intent);
        });

        donateBtn.setOnClickListener((v)-> {
            Optional<LoggedInUser> user = LoginRepository.getInstance().getLoggedUser();
            if (!user.isPresent()) {
                return;
            }
            if (campaignId == null) {
                return;
            }

            ActivitiesHelper.moveToDonate(this, campaignId);
        });
        backBtn.setOnClickListener((v)-> {
            finish();
        });
        bookmarkBtn.setOnClickListener((v)-> {
            Optional<LoggedInUser> user = LoginRepository.getInstance().getLoggedUser();
            if (!user.isPresent()) {
                return;
            }
            if (campaignId == null) {
                return;
            }

            MainRepository.getInstance().addBookmark(user.get().getUserId(), campaignId).onComplete((result)-> {
                if (result.hasError()) {
                    Throwable error = result.getError();
                    if (error instanceof ElementAlreadyExistsException) {
                        Toast.makeText(this, "Bookmark already saved", Toast.LENGTH_SHORT).show();
                    } else {
                        Logger.error("Failed to save bookmark", result.getError());
                        Toast.makeText(this, "Failed to save bookmark", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show();
                }
            });
        });
        associationLayout.setOnClickListener((v)-> {
            if (campaign != null) {
                ActivitiesHelper.moveToAssociation(this, campaign.getAssociationId());
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        loadCampaignInfo();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        campaignId = null;
        campaign = null;
    }

    private void loadCampaignInfo() {
        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        if (id == null) {
            Logger.error("Expected id in intent, but it is missing");
            finish();
        }

        campaignId = id;
        campaign = null;

        Optional<LoggedInUser> user = LoginRepository.getInstance().getLoggedUser();
        if (!user.isPresent()) {
            ActivitiesHelper.moveToLogin(this);
        }

        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        final ImageView image = binding.image;
        final RecyclerView imagesView = binding.imagesView;
        final TextView name = binding.name;
        final TextView donatedMoney = binding.raisedMoney;
        final TextView requiredMoney = binding.totalMoney;
        final TextView donors = binding.donors;
        final TextView daysLeft = binding.daysLeft;
        final ProgressBar progressBar = binding.progressBar;
        final TextView category = binding.category;
        final TextView associationName = binding.associationName;
        final TextView recipientName = binding.recipientname;
        final View proposalDocLayout = binding.proposaldocLayout;
        final View medicalDocLayout = binding.medicaldocLayout;
        final TextView fundUsagePlan = binding.fundusageplan;
        final TextView description = binding.description;
        final View donateBtn = binding.donateBtn;
        final ImageView associationImg = binding.associationImg;

        imagesView.setVisibility(View.GONE);
        proposalDocLayout.setVisibility(View.GONE);
        medicalDocLayout.setVisibility(View.GONE);
        donateBtn.setEnabled(false);

        RecyclerListController<Uri> imagesController = RecyclerHelper.loadImagesInto(imagesView);

        mainRepository.getCampaign(id).onComplete((result)-> {
            if (result.hasError()) {
                Logger.error("Failed to load campaign", result.getError());
                Toast.makeText(this, "Failed to load campaign info", Toast.LENGTH_LONG).show();
                return;
            }

            CampaignWrapper campaign = result.getValue();
            this.campaign = campaign.campaign;

            storageRepository.getAllCampaignImages(campaign.campaign.getId()).onComplete((resultUri)-> {
                if (resultUri.hasValue()) {
                    imagesView.setVisibility(View.VISIBLE);
                    image.setVisibility(View.GONE);
                    imagesController.replace(resultUri.getValue());
                } else {
                    image.setVisibility(View.VISIBLE);
                    imagesView.setVisibility(View.GONE);
                    Logger.error("Failed to retrieve images for campaign", resultUri.getError());
                }
            });

            storageRepository.getAssociationImage(campaign.association.getId()).onComplete((resultUri)-> {
                if (resultUri.hasValue()) {
                    Glide.with(this)
                            .load(resultUri.getValue())
                            .into(associationImg);
                } else {
                    Logger.error("Failed to retrieve image for association", resultUri.getError());
                }
            });

            File docsOutputDir = new File(getCacheDir(), "campaignDocs");
            storageRepository.downloadCampaignProposalDocument(campaign.campaign.getId(), docsOutputDir).onComplete((resultFile)-> {
                if (resultFile.hasValue()) {
                    proposalDocFile.set(resultFile.getValue());
                    proposalDocLayout.setVisibility(View.VISIBLE);
                } else {
                    proposalDocFile.set(null);
                    proposalDocLayout.setVisibility(View.GONE);
                    Logger.error("Failed to retrieve file for campaign", resultFile.getError());
                }
            });
            storageRepository.downloadCampaignMedicalDocument(campaign.campaign.getId(), docsOutputDir).onComplete((resultFile)-> {
                if (resultFile.hasValue()) {
                    medicalDocFile.set(resultFile.getValue());
                    medicalDocLayout.setVisibility(View.VISIBLE);
                } else {
                    medicalDocFile.set(null);
                    medicalDocLayout.setVisibility(View.GONE);
                    Logger.error("Failed to retrieve file for campaign", resultFile.getError());
                }
            });

            category.setText(campaign.category.getName());
            name.setText(campaign.campaign.getName());
            donatedMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.campaign.getRaisedAmount()));
            requiredMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.campaign.getGoalAmount()));
            donors.setText(String.format(Locale.ENGLISH, "%d", campaign.donations.size()));
            daysLeft.setText(String.format(Locale.ENGLISH, "%d", campaign.campaign.getDaysLeftToDonate()));
            progressBar.setProgress((int) campaign.campaign.getRaisedAmount());
            progressBar.setMax((int) campaign.campaign.getGoalAmount());
            associationName.setText(campaign.association.getName());
            recipientName.setText(campaign.campaign.getRecipient());
            fundUsagePlan.setText(campaign.campaign.getUsagePlan());
            description.setText(campaign.campaign.getDescription());

            if (campaign.campaign.getState() == CampaignState.ONGOING) {
                donateBtn.setEnabled(true);
            }
        });
    }
}
