package com.alreadydone.control.countries;

import java.text.Collator;

public class CountryInfo implements Comparable<CountryInfo> {

    public final String alpha2;
    public final String alpha3;
    public final String englishName;
    public final String demonym;
    public final String capitalEnglishName;
    public final String areaKM2;
    public final int population;
    public final String currencyCode;
    public final String currencyName;
    public final String currencySymbol;
    public final String cctld;
    public final String flagEmoji;
    public final int phoneCode;

    public CountryInfo(String alpha2, String alpha3, String englishName, String demonym,
                       String capitalEnglishName, String areaKM2, int population,
                       String currencyCode, String currencyName, String currencySymbol,
                       String cctld, String flagEmoji, int phoneCode) {
        this.alpha2 = alpha2;
        this.alpha3 = alpha3;
        this.englishName = englishName;
        this.demonym = demonym;
        this.capitalEnglishName = capitalEnglishName;
        this.areaKM2 = areaKM2;
        this.population = population;
        this.currencyCode = currencyCode;
        this.currencyName = currencyName;
        this.currencySymbol = currencySymbol;
        this.cctld = cctld;
        this.flagEmoji = flagEmoji;
        this.phoneCode = phoneCode;
    }

    @Override
    public int compareTo(CountryInfo countryInfo) {
        return Collator.getInstance().compare(this.englishName, countryInfo.englishName);
    }
}
