package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.SelectableRecyclerListController;
import com.alreadydone.data.model.Category;

public class InterestSelectionFragment extends Fragment {

    private SelectableRecyclerListController<Category> controller;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_interest_selection, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final View continueBtn = view.findViewById(R.id.continueBtn);
        final RecyclerView interestsView = view.findViewById(R.id.interestList);

        controller = RecyclerHelper.loadCategoriesInto(interestsView);

        continueBtn.setEnabled(true);
        continueBtn.setOnClickListener((v)-> {
            save();
        });
    }

    private void save() {
        AccountSetupParent parent = getParent();
        parent.setSelectedInterests(controller.getSelected());
        parent.onContinue();
    }

    private AccountSetupParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof AccountSetupParent) {
            return (AccountSetupParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof AccountSetupParent) {
            return (AccountSetupParent) activity;
        }

        throw new IllegalStateException("parent does not support setup");
    }
}
