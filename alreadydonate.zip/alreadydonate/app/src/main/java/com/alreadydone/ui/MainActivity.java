package com.alreadydone.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.exceptions.ElementDoesNotExistException;
import com.alreadydone.data.model.Association;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.data.model.User;
import com.alreadydone.data.model.UserType;
import com.alreadydone.databinding.ActivityMainBinding;
import com.alreadydone.ui.fragments.AdminMainFragment;
import com.alreadydone.ui.fragments.AssociationCampaignFragment;
import com.alreadydone.ui.fragments.AssociationEditFragment;
import com.alreadydone.ui.fragments.AssociationEditParent;
import com.alreadydone.ui.fragments.EmptyFragment;
import com.alreadydone.ui.fragments.MainFragment;
import com.alreadydone.ui.fragments.MyDonationsFragment;
import com.alreadydone.ui.fragments.ProfileFragment;
import com.alreadydone.util.Logger;
import com.alreadydone.util.future.Future;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MainActivity extends AppCompatActivity implements AssociationEditParent {

    private ActivityMainBinding binding;
    private User loadedUser = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkAccountStatus();
    }

    private void checkAccountStatus() {
        MainRepository mainRepository = MainRepository.getInstance();
        LoginRepository loginRepository = LoginRepository.getInstance();

        Optional<LoggedInUser> loggedInUserOptional = loginRepository.getLoggedUser();
        if (loggedInUserOptional.isPresent()) {
            LoggedInUser loggedInUser = loggedInUserOptional.get();
            Future<User> future = mainRepository.getUserById(loggedInUser.getUserId());
            future.onComplete((result)-> {
                if (result.hasValue()) {
                    // account already set up
                    User user = result.getValue();
                    if (loadedUser == null || !user.getId().equals(loadedUser.getId())) {
                        setupActivity(user);
                    }
                } else {
                    Throwable error = result.getError();
                    if (error instanceof ElementDoesNotExistException) {
                        // no such account, meaning it was not setup
                        ActivitiesHelper.moveToAccountSetup(MainActivity.this);
                    } else {
                        Logger.error("Failed to get user info", error);
                        Toast.makeText(this, "Failed to get user info", Toast.LENGTH_LONG).show();
                    }
                }
            });
        } else {
            ActivitiesHelper.moveToLogin(this);
        }
    }

    private void setupActivity(User user) {
        setContentView(binding.getRoot());

        final View homeBtn = binding.homeBtn;
        final View eventsBtn = binding.eventsBtn;
        final View associationBtn = binding.associationBtn;
        final View profileBtn = binding.profileBtn;

        final ViewPager2 pager = binding.pager;

        Bundle additionalArgs = new Bundle();
        additionalArgs.putString("userId", user.getId());
        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                Arrays.asList(
                    new GenericPagerAdapter.FragmentDef(MainFragment::new),
                    new GenericPagerAdapter.FragmentDef(MyDonationsFragment::new),
                    new GenericPagerAdapter.FragmentDef(AssociationCampaignFragment::new, (args)-> {
                        additionalArgs.putString("associationId", user.getAssociationId());
                    }),
                    new GenericPagerAdapter.FragmentDef(ProfileFragment::new),
                    new GenericPagerAdapter.FragmentDef(AdminMainFragment::new),
                    new GenericPagerAdapter.FragmentDef(AssociationEditFragment::new)
                ),
                additionalArgs));

        homeBtn.setOnClickListener((v)-> handleClick(v, true));
        eventsBtn.setOnClickListener((v)-> handleClick(v, true));
        associationBtn.setOnClickListener((v)-> {
            if (user.getAssociationId() == null) {
                pager.setCurrentItem(5, false);
                handleClick(v, false);
            } else {
                handleClick(v, true);
            }
        });
        profileBtn.setOnClickListener((v)-> handleClick(v, true));

        if (user.getType() == UserType.ADMIN) {
            binding.navbar.setVisibility(View.GONE);
            pager.setCurrentItem(4, false);
        } else {
            homeBtn.setSelected(true);
            pager.setCurrentItem(0, false);
        }

        loadedUser = user;
    }

    private void handleClick(View clicked, boolean switchPage) {
        List<View> views = Arrays.asList(
                binding.homeBtn,
                binding.eventsBtn,
                binding.associationBtn,
                binding.profileBtn
        );
        final ViewPager2 pager = binding.pager;

        for (int i = 0; i < views.size(); i++) {
            View view = views.get(i);
            if (clicked == view) {
                view.setSelected(true);

                if (switchPage) {
                    pager.setCurrentItem(i, false);
                }

            } else {
                view.setSelected(false);
            }
        }
    }

    @Override
    public void saveAssociationInfo(EditableAssociationInfo info) {
        Association association = new Association();
        association.setName(info.name);
        association.setDescription(info.description);
        association.setUserId(loadedUser.getId());

        Future.checkedCall(
                ()-> MainRepository.getInstance().configureAssociation(loadedUser.getId(), association),
                (result)-> {
                    if (result.hasError()) {
                        Logger.error("Failed to create association", result.getError());
                        Toast.makeText(this, "Failed to create association", Toast.LENGTH_SHORT).show();
                    } else {
                        if (info.profilePicture != null) {
                            StorageRepository.getInstance()
                                    .uploadAssociationPic(result.getValue(), info.profilePicture).onComplete((resultImg)-> {
                                        if (resultImg.hasError()) {
                                            Logger.error("Failed to upload association image", resultImg.getError());
                                        }
                                    });
                        }

                        loadedUser.setAssociationId(result.getValue());
                        handleClick(binding.associationBtn, true);
                    }
                }
        );
    }

    @Override
    public void cancelAssociationEdit() {
        handleClick(binding.homeBtn, true);
    }
}