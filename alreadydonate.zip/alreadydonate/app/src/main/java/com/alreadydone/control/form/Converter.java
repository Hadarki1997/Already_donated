package com.alreadydone.control.form;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.function.Function;

public interface Converter<T, R> {

    DateTimeFormatter BASIC_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    ValidatedValue<R> convertAndValidate(T value);

    default <R2> Converter<T, R2> andThen(Converter<R, R2> converter) {
        return new AndThenConverter<>(this, converter);
    }

    static <T, R> Converter<T, R> create(Function<T, R> converter, Validator<T> preConversionValidator) {
        return new Basic<>(converter, preConversionValidator);
    }

    static Converter<String, Double> stringToDouble() {
        return create(Double::parseDouble, Validators.isNumber());
    }

    static Converter<String, LocalDate> stringToBaseDate() {
        return create((txt)-> {
            return LocalDate.parse(txt, BASIC_FORMATTER);
        }, Validators.isDate());
    }

    class AndThenConverter<T, R, R2> implements Converter<T, R2> {

        private final Converter<T, R> original;
        private final Converter<R, R2> next;

        public AndThenConverter(Converter<T, R> original, Converter<R, R2> next) {
            this.original = original;
            this.next = next;
        }

        @Override
        public ValidatedValue<R2> convertAndValidate(T value) {
            ValidatedValue<R> validatedValue = original.convertAndValidate(value);
            if (validatedValue.isValid()) {
                return new ValidatedValue<>(null, validatedValue.validationResult);
            }

            return next.convertAndValidate(validatedValue.value);
        }
    }

    class Basic<T, R> implements Converter<T, R> {

        private final Function<T, R> converter;
        private final Validator<T> preConversionValidator;

        public Basic(Function<T, R> converter, Validator<T> preConversionValidator) {
            this.converter = converter;
            this.preConversionValidator = preConversionValidator;
        }

        @Override
        public ValidatedValue<R> convertAndValidate(T value) {
            ValidationResult result = preConversionValidator.validate(value);
            if (!result.isValid()) {
                return new ValidatedValue<>(null, result);
            }

            R convertedValue = converter.apply(value);
            return new ValidatedValue<>(convertedValue, ValidationResult.valid());
        }
    }
}
