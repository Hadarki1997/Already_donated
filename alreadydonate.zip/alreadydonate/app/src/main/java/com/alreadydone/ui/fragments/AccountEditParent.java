package com.alreadydone.ui.fragments;

import android.net.Uri;

import com.alreadydone.control.countries.CountryInfo;

import java.util.Optional;

public interface AccountEditParent {

    class EditableUserInfo {
        public Uri profilePicture;
        public String fullName;
        public String phoneNumber;
        public String gender;
        public String country;
        public String city;
    }

    Optional<CountryInfo> getSelectedCountry();
    void saveUserInfo(EditableUserInfo userInfo);
}
