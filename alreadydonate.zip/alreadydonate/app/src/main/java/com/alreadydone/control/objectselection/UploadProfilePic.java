package com.alreadydone.control.objectselection;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.alreadydone.util.RunningJob;
import com.alreadydone.util.future.Future;

public class UploadProfilePic {

    private static final String[] CAMERA_PERMISSIONS = new String[]{Manifest.permission.CAMERA};
    // Manifest.permission.READ_MEDIA_IMAGES
    private static final String[] GALLERY_PERMISSIONS = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};

    private final Context context;
    private final Chooser chooser;

    public UploadProfilePic(Context context, Chooser chooser) {
        this.context = context;
        this.chooser = chooser;
    }

    public static UploadProfilePic create(AppCompatActivity activity) {
        return new UploadProfilePic(activity, Chooser.create(activity));
    }

    public static UploadProfilePic create(Fragment fragment) {
        return new UploadProfilePic(fragment.requireContext(), Chooser.create(fragment));
    }

    public Future<Uri> start() {
        RunningJob<Uri> job = new RunningJob<>(context.getMainLooper());

        String[] options = {"Camera", "Gallery"};
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Pick Image From");
        builder.setItems(options, (dialog, which) -> {
            // if access is not given then we will request for permission
            if (which == 0) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.Images.Media.TITLE, "Temp_pic");
                contentValues.put(MediaStore.Images.Media.DESCRIPTION, "Temp Description");
                Uri imageUri = context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

                chooser.start(intent, CAMERA_PERMISSIONS).onComplete((result)-> {
                    if (result.hasError()) {
                        job.markComplete(result);
                    } else {
                        job.markFinished(imageUri);
                    }
                });
            } else if (which == 1) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");

                chooser.start(intent, GALLERY_PERMISSIONS).onComplete(job::markComplete);
            } else {
                job.markErrored(new AssertionError());
            }
        });
        builder.create().show();

        return Future.create(job);
    }
}
