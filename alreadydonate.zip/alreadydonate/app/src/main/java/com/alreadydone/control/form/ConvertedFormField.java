package com.alreadydone.control.form;

public class ConvertedFormField<T, T2> implements FormField<T2> {

    private final FormField<T> originalField;
    private final Converter<T, T2> converter;
    private final Validator<T2> validator;

    public ConvertedFormField(FormField<T> originalField, Converter<T, T2> converter, Validator<T2> validator) {
        this.originalField = originalField;
        this.converter = converter;
        this.validator = validator;
    }

    @Override
    public ValidatedValue<T2> validateAndGetValue() {
        ValidatedValue<T> value = originalField.validateAndGetValue();
        if (!value.isValid()) {
            return new ValidatedValue<>(null, value.validationResult);
        }

        ValidatedValue<T2> convertedValue = converter.convertAndValidate(value.value);
        if (!convertedValue.isValid()) {
            return convertedValue;
        }

        ValidationResult validationResult = validator.validate(convertedValue.value);
        return new ValidatedValue<>(convertedValue.value, validationResult);
    }

    @Override
    public void enableAutoValidate(Validator<T2> additionalValidator) {
        originalField.enableAutoValidate(new ConverterValidator<>(converter, validator.and(additionalValidator)));
    }

    @Override
    public <T3> FormField<T3> as(Converter<T2, T3> converter, Validator<T3> validator) {
        return new ConvertedFormField<>(
                this,
                converter,
                validator);
    }

    private static class ConverterValidator<T, T2> implements Validator<T> {

        private final Converter<T, T2> converter;
        private final Validator<T2> postConversionValidator;

        private ConverterValidator(Converter<T, T2> converter,
                                   Validator<T2> postConversionValidator) {
            this.converter = converter;
            this.postConversionValidator = postConversionValidator;
        }

        @Override
        public ValidationResult validate(T t) {
            ValidatedValue<T2> convertedValue = converter.convertAndValidate(t);
            if (!convertedValue.isValid()) {
                return convertedValue.validationResult;
            }

            return postConversionValidator.validate(convertedValue.value);
        }
    }
}
