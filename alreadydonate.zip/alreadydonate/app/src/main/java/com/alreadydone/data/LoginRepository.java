package com.alreadydone.data;

import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.util.future.Future;

import java.util.Optional;

public class LoginRepository {

    private static LoginRepository instance;

    public static synchronized LoginRepository getInstance() {
        if (instance == null) {
            instance = new LoginRepository();
        }
        return instance;
    }

    private final LoginDataSource dataSource;

    private LoginRepository() {
        this.dataSource = new LoginDataSource();
    }

    public boolean isLoggedIn() {
        return getLoggedUser().isPresent();
    }

    public Optional<LoggedInUser> getLoggedUser() {
        return dataSource.getCurrentLogin();
    }

    public Future<LoggedInUser> login(String email, String password) {
        return dataSource.login(email, password);
    }

    public Future<LoggedInUser> signup(String email, String password) {
        return dataSource.signup(email, password);
    }

    public void logout() {
        dataSource.logout();
    }
}