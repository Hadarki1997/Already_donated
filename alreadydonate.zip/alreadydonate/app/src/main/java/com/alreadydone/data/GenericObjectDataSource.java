package com.alreadydone.data;

import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.alreadydone.data.exceptions.AbortedTransactionException;
import com.alreadydone.data.exceptions.BadIdException;
import com.alreadydone.data.exceptions.ElementAlreadyExistsException;
import com.alreadydone.data.exceptions.ElementDoesNotExistException;
import com.alreadydone.data.meta.ModelMeta;
import com.alreadydone.data.meta.ModelMetaRegistry;
import com.alreadydone.util.Logger;
import com.alreadydone.util.Result;
import com.alreadydone.util.RunningJob;
import com.alreadydone.util.function.PredicateList;
import com.alreadydone.util.future.Future;
import com.alreadydone.util.future.FuturesResult;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.Transaction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class GenericObjectDataSource<T> implements DataSource<T> {

    private final FirebaseDatabase database;
    private final Class<T> cls;
    private final ModelMeta<T> meta;

    public GenericObjectDataSource(FirebaseDatabase database, Class<T> cls) {
        this.database = database;
        this.cls = cls;
        this.meta = ModelMetaRegistry.getMetaForModel(cls);
    }

    @Override
    public Future<List<T>> getAll() {
        DatabaseReference ref = getBaseRef();
        Task<DataSnapshot> task = ref.get();
        return Future.create(task).as(this::snapshotToListOfChildren);
    }

    @Override
    public Future<List<T>> getAllByField(String fieldName, String value) {
        DatabaseReference ref = getBaseRef();
        Task<DataSnapshot> task = ref.orderByChild(fieldName)
                .equalTo(value)
                .get();
        return Future.create(task).as(this::snapshotToListOfChildren);
    }

    @Override
    public Future<T> getById(String id) {
        if (!isValidId(id)) {
            return Future.immediate(Result.error(new BadIdException(id)));
        }

        DatabaseReference ref = getBaseRef();
        Task<DataSnapshot> task = ref.child(id).get();
        return Future.create(task).as(this::snapshotToSingle);
    }

    @Override
    public Future<List<T>> getAllByIds(Collection<String> ids, List<Predicate<T>> filters) {
        Predicate<T> filter = new PredicateList<>(filters);

        List<Future<T>> futures = new ArrayList<>(ids.size());
        for (String id : ids) {
            Future<T> future = getById(id);
            futures.add(future);
        }

        return Future.merge(futures)
                .as((result)-> mergedFutureResultToListAndFilter(futures, filter, result));
    }

    @Override
    public void listen(Listener<T> listener) {
        DatabaseReference ref = getBaseRef();
        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                T t = GenericObjectDataSource.this.snapshotToSingle(snapshot);
                Logger.info("New child %s", GenericObjectDataSource.this.meta.getId(t));
                listener.onNew(t);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                T t = GenericObjectDataSource.this.snapshotToSingle(snapshot);
                Logger.info("child changed %s", GenericObjectDataSource.this.meta.getId(t));
                listener.onChanged(t);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                T t = GenericObjectDataSource.this.snapshotToSingle(snapshot);
                String id = GenericObjectDataSource.this.meta.getId(t);
                Logger.info("child removed %s", id);
                listener.onRemoved(id);
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Logger.error("Listener canceled %s", error.getMessage());
            }
        });
    }

    @Override
    public Future<Void> add(T t) {
        DatabaseReference ref = getBaseRef();
        Task<Void> task = ref.child(meta.getId(t)).setValue(meta.serialize(t));
        return Future.create(task);
    }

    @Override
    public Future<Void> addToField(String id, String fieldName, double amount) {
        DatabaseReference ref = getBaseRef();
         return runTransaction(ref.child(id).child(fieldName), (currentData)-> {
            Double oldValue = currentData.getValue(double.class);
            if (oldValue == null) {
                oldValue = 0.0;
            }

            currentData.setValue(oldValue + amount);
            return Transaction.success(currentData);
        });
    }

    @Override
    public Future<Void> appendToListField(String id, String fieldName, Object value, AppendFlag... flags) {
        Set<AppendFlag> flagSet = new HashSet<>(Arrays.asList(flags));

        DatabaseReference ref = getBaseRef();
        return runTransaction(ref.child(id).child(fieldName), (currentData)-> {
            //noinspection unchecked
            List<Object> list = (List<Object>) currentData.getValue();
            if (list == null) {
                list = new ArrayList<>();
            }

            if (flagSet.contains(AppendFlag.NO_DUPLICATES) && list.contains(value)) {
                return Transaction.abort();
            }

            list.add(value);
            currentData.setValue(list);
            return Transaction.success(currentData);
        }).convertError((throwable)-> {
            if (throwable instanceof AbortedTransactionException) {
                return Result.error(new ElementAlreadyExistsException());
            }

            return null;
        });
    }

    @Override
    public Future<Void> updateField(String id, String fieldName, Object value) {
        value = meta.serializeValue(value);

        DatabaseReference ref = getBaseRef();
        Task<Void> task = ref.child(id).child(fieldName).setValue(value);
        return Future.create(task);
    }

    @Override
    public Future<Void> update(T t) {
        return add(t);
    }

    @Override
    public Future<Void> deleteById(String id) {
        DatabaseReference ref = getBaseRef();
        Task<Void> task = ref.child(id).setValue(null);
        return Future.create(task);
    }

    private List<T> snapshotToListOfChildren(DataSnapshot snapshot) {
        if (!snapshot.exists()) {
            throw new ElementDoesNotExistException();
        }

        return StreamSupport.stream(snapshot.getChildren().spliterator(), false)
                .map(meta::parse)
                .collect(Collectors.toList());
    }

    private List<T> mergedFutureResultToListAndFilter(List<Future<T>> futures, Predicate<T> filter, FuturesResult result) {
        List<T> list = new ArrayList<>(futures.size());
        for (Future<T> future : futures) {
            Result<T> resultForFuture = result.getResultFor(future);
            if (resultForFuture.hasError()) {
                Logger.error("Error while fetching list, future failed", resultForFuture.getError());
            } else {
                T t = resultForFuture.getValue();
                if (filter.test(t)) {
                    list.add(t);
                }
            }
        }

        return list;
    }

    private T snapshotToSingle(DataSnapshot snapshot) {
        if (!snapshot.exists()) {
            throw new ElementDoesNotExistException();
        }

        return meta.parse(snapshot);
    }

    private boolean isValidId(String id) {
        return id != null && !id.isEmpty();
    }

    private DatabaseReference getBaseRef() {
        return database.getReference().child(meta.getRefName());
    }

    private Future<Void> runTransaction(DatabaseReference reference,
                                        Function<MutableData, Transaction.Result> transaction) {
        RunningJob<Void> job = new RunningJob<>(Looper.getMainLooper());
        reference.runTransaction(new Transaction.Handler() {
            @NonNull
            @Override
            public Transaction.Result doTransaction(@NonNull MutableData currentData) {
                return transaction.apply(currentData);
            }

            @Override
            public void onComplete(@Nullable DatabaseError error, boolean committed, @Nullable DataSnapshot currentData) {
                if (error != null) {
                    job.markErrored(error.toException());
                } else if (!committed) {
                    job.markErrored(new AbortedTransactionException());
                } else {
                    job.markFinished(null);
                }
            }
        });

        return Future.create(job);
    }
}
