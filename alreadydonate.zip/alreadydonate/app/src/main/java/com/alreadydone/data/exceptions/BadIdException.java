package com.alreadydone.data.exceptions;

import java.util.Locale;

public class BadIdException extends DataException {

    public BadIdException(String id) {
        super(String.format(Locale.ENGLISH, "bad id: %s", id));
    }
}
