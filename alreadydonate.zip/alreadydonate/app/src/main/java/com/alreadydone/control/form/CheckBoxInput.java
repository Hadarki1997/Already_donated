package com.alreadydone.control.form;

import android.widget.CheckBox;

import java.util.function.Consumer;

public class CheckBoxInput implements FormInput<Boolean> {

    private final CheckBox input;

    public CheckBoxInput(CheckBox input) {
        this.input = input;
    }

    @Override
    public Boolean getValue() {
        return input.isChecked();
    }

    @Override
    public void setValid() {
        input.setError(null);
    }

    @Override
    public void setError(String message) {
        input.setError(message);
    }

    @Override
    public void registerForValueChanges(Consumer<Boolean> consumer) {
        input.setOnCheckedChangeListener((v, value)-> {
            consumer.accept(value);
        });
    }
}
