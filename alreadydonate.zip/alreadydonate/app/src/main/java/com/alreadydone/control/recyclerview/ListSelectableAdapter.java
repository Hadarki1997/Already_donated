package com.alreadydone.control.recyclerview;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class ListSelectableAdapter<T, A extends RecyclerView.ViewHolder> extends BaseAdapter<T, A> {

    private final AtomicReference<Consumer<Set<T>>> onSelect;
    private final Set<T> selected;

    public ListSelectableAdapter(int layoutId, Function<View, A> aCreator, BiConsumer<T, A> bind) {
        super(layoutId, aCreator, bind);

        this.onSelect = new AtomicReference<>();
        this.selected = new HashSet<>();
    }

    public Set<T> getSelected() {
        return Collections.unmodifiableSet(selected);
    }

    public void setOnSelect(Consumer<Set<T>> onSelect) {
        this.onSelect.set(onSelect);

        if (!selected.isEmpty()) {
            onSelect.accept(getSelected());
        }
    }

    @Override
    public void onBindViewHolder(@NonNull A holder, int position) {
        super.onBindViewHolder(holder, position);

        T t = list.get(position);
        holder.itemView.setClickable(true);
        holder.itemView.setOnClickListener((view)-> {
            select(holder, t);
        });
    }

    private void select(A holder, T t) {
        if (holder.itemView.isSelected()) {
            holder.itemView.setSelected(false);
            selected.remove(t);
        } else {
            holder.itemView.setSelected(true);
            selected.add(t);
        }

        Consumer<Set<T>> onSelect = this.onSelect.get();
        if (onSelect != null) {
            onSelect.accept(getSelected());
        }
    }
}
