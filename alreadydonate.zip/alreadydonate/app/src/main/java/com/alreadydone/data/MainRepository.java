package com.alreadydone.data;

import android.os.Looper;

import com.alreadydone.data.model.Association;
import com.alreadydone.data.model.Bookmark;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.CampaignApprovalState;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.data.model.CampaignWrapper;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.Donation;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.data.model.PaymentMethod;
import com.alreadydone.data.model.User;
import com.alreadydone.util.function.PredicateList;
import com.alreadydone.util.future.Future;
import com.google.firebase.database.FirebaseDatabase;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.function.Predicate;

public class MainRepository {

    private static MainRepository instance;

    public static synchronized MainRepository getInstance() {
        if (instance == null) {
            instance = new MainRepository();
        }

        return instance;
    }

    private final DataSource<User> userDataSource;
    private final DataSource<Association> associationDataSource;
    private final DataSource<Campaign> campaignDataSource;
    private final DataSource<Donation> donationDataSource;
    private final DataSource<Category> categoryDataSource;
    private final DataSource<Bookmark> bookmarkDataSource;
    private final DataSource<PaymentMethod> paymentMethodDataSource;
    private final DataSource<CampaignApprovalState> campaignApprovalDataSource;

    private final DataRegistry<Campaign> campaignsRegistry;
    private final DataRegistry<Donation> donationsRegistry;
    private final DataRegistry<Bookmark> bookmarkRegistry;
    private final DataRegistry<User> userRegistry;
    private final DataRegistry<PaymentMethod> paymentMethodRegistry;

    private final List<Object> objectHolder = new ArrayList<>();

    public MainRepository() {
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://alreadydone-project-default-rtdb.europe-west1.firebasedatabase.app/");
        userDataSource = new GenericObjectDataSource<>(database, User.class);
        associationDataSource = new GenericObjectDataSource<>(database, Association.class);
        campaignDataSource = new GenericObjectDataSource<>(database, Campaign.class);
        donationDataSource = new GenericObjectDataSource<>(database, Donation.class);
        categoryDataSource = new GenericObjectDataSource<>(database, Category.class);
        bookmarkDataSource = new GenericObjectDataSource<>(database, Bookmark.class);
        paymentMethodDataSource = new GenericObjectDataSource<>(database, PaymentMethod.class);
        campaignApprovalDataSource = new GenericObjectDataSource<>(database, CampaignApprovalState.class);

        campaignsRegistry = new DataRegistry<>(Looper.getMainLooper(), campaignDataSource, Campaign.class);
        donationsRegistry = new DataRegistry<>(Looper.getMainLooper(), donationDataSource, Donation.class);
        bookmarkRegistry = new DataRegistry<>(Looper.getMainLooper(), bookmarkDataSource, Bookmark.class);
        userRegistry = new DataRegistry<>(Looper.getMainLooper(), userDataSource, User.class);
        paymentMethodRegistry = new DataRegistry<>(Looper.getMainLooper(), paymentMethodDataSource, PaymentMethod.class);
    }

    public CampaignInfoObserver createCampaignObserver(DataRegistry.Observer<CampaignAndDonations> observer, Predicate<Campaign> baseFilter) {
        CampaignInfoObserver campaignInfoObserver = new CampaignInfoObserver(campaignsRegistry, donationsRegistry, observer, baseFilter);
        objectHolder.add(campaignInfoObserver);

        return campaignInfoObserver;
    }

    public CampaignInfoObserver createCampaignObserver(DataRegistry.Observer<CampaignAndDonations> observer, List<Predicate<Campaign>> baseFilters) {
        return createCampaignObserver(observer, new PredicateList<>(baseFilters));
    }

    public Registration observeBookmarks(String userId, DataRegistry.Observer<Bookmark> observer) {
        return bookmarkRegistry.observe(observer, (bookmark)-> bookmark.getId().equals(userId));
    }

    public DonationInfoObserver createDonationObserver(DataRegistry.Observer<FullDonationInfo> observer, Predicate<Donation> baseFilter) {
        DonationInfoObserver donationInfoObserver = new DonationInfoObserver(donationsRegistry, campaignsRegistry, userRegistry, observer, baseFilter);
        objectHolder.add(donationInfoObserver);

        return donationInfoObserver;
    }

    public Registration observePaymentMethods(String userId, DataRegistry.Observer<PaymentMethod> observer) {
        return paymentMethodRegistry.observe(observer, (paymentMethod)-> paymentMethod.getUserId().equals(userId));
    }

    public Future<User> getUserById(String id) {
        return userDataSource.getById(id);
    }

    public Future<Association> getAssociationForUser(String userId) {
        return getUserById(userId).andThen((user)-> associationDataSource.getById(user.getAssociationId()));
    }

    public Future<Association> getAssociationById(String associationId) {
        return associationDataSource.getById(associationId);
    }

    public Future<List<Category>> getAllCategories() {
        return categoryDataSource.getAll();
    }

    public Future<List<Category>> getCategories(Collection<String> categoryIds) {
        return categoryDataSource.getAllByIds(categoryIds);
    }

    public Future<List<PaymentMethod>> getPaymentMethods(String userId) {
        return paymentMethodDataSource.getAllByField("userId", userId);
    }

    public Future<CampaignApprovalState> getApprovalState(String campaignId) {
        return campaignApprovalDataSource.getById(campaignId);
    }

    public Future<Campaign> getBaseCampaign(String id) {
        return campaignDataSource.getById(id);
    }

    public Future<CampaignWrapper> getCampaign(String id) {
        Future<Campaign> future = campaignDataSource.getById(id);
        return future.andThen((campaign)-> {
            Future<List<Donation>> donationsFuture = donationDataSource.getAllByField("campaignId", campaign.getId());
            Future<Category> categoryFuture = categoryDataSource.getById(campaign.getCategoryId());
            Future<Association> associationFuture = associationDataSource.getById(campaign.getAssociationId());

            return Future.merge(donationsFuture, categoryFuture, associationFuture)
                    .as((result)-> {
                        List<Donation> donations = result.getResultFor(donationsFuture).getOr(ArrayList::new);
                        Category category = result.getResultFor(categoryFuture).getOrThrowRuntime();
                        Association association = result.getResultFor(associationFuture).getOrThrowRuntime();

                        return new CampaignWrapper(campaign, category, association, donations);
                    });
        });
    }

    public Future<Void> addDonation(Donation donation) {
        String id = UUID.randomUUID().toString();
        donation.setId(id);
        ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
        donation.setDate(now);

        Future<Void> future = donationDataSource.add(donation);
        return future.andThen((v)-> {
            return campaignDataSource.addToField(donation.getCampaignId(), "raisedAmount", donation.getAmount());
        });
    }

    public Future<Void> addUser(User user) {
        return userDataSource.add(user);
    }

    public Future<Void> saveUser(User user) {
        return userDataSource.update(user);
    }

    public Future<String> configureAssociation(String userId, Association association) {
        association.setId(UUID.randomUUID().toString());
        association.setUserId(userId);

        return getUserById(userId).andThen((user)-> {
            user.setAssociationId(association.getId());
            return Future.merge(
                    associationDataSource.add(association),
                    userDataSource.update(user)
            );
        }).as((result)-> {
            return association.getId();
        });
    }

    public Future<Void> addBookmark(String userId, String campaignId) {
        return bookmarkDataSource.appendToListField(userId, "campaignIds", campaignId, DataSource.AppendFlag.NO_DUPLICATES);
    }

    public Future<Void> addCampaign(Campaign campaign) {
        String id = UUID.randomUUID().toString();
        campaign.setId(id);
        ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
        campaign.setStartTime(now);

        return campaignDataSource.add(campaign);
    }

    public Future<Void> approveCampaign(Campaign campaign) {
        campaignApprovalDataSource.deleteById(campaign.getId());
        return campaignDataSource.updateField(campaign.getId(), "state", CampaignState.ONGOING);
    }

    public Future<Void> rejectCampaign(Campaign campaign, String description) {
        CampaignApprovalState approvalState = new CampaignApprovalState();
        approvalState.setId(campaign.getId());
        approvalState.setDescription(description);
        approvalState.setRejected(true);
        approvalState.setUpdateTime(ZonedDateTime.now(ZoneOffset.UTC));

        Future<Void> updateApproval = campaignApprovalDataSource.update(approvalState);
        Future<Void> updateState = campaignDataSource.updateField(campaign.getId(), "state", CampaignState.APPROVAL_REJECTED);

        return Future.merge(updateApproval, updateState).asVoid();
    }

    public Future<Void> addPaymentMethod(String userId, PaymentMethod paymentMethod) {
        paymentMethod.setId(UUID.randomUUID().toString());
        paymentMethod.setUserId(userId);

        return paymentMethodDataSource.add(paymentMethod);
    }

    public Future<Void> updateAboutField(String userId, String about) {
        return userDataSource.updateField(userId, "about", about);
    }

    public Future<Void> updateCampaign(String id, Campaign campaign) {
        return campaignDataSource.getById(id).andThen((actualCampaign)-> {
            actualCampaign.setName(campaign.getName());
            actualCampaign.setRecipient(campaign.getRecipient());
            actualCampaign.setCategoryId(campaign.getCategoryId());
            actualCampaign.setUsagePlan(campaign.getUsagePlan());
            actualCampaign.setDescription(campaign.getDescription());
            actualCampaign.setEndTime(campaign.getEndTime());
            actualCampaign.setGoalAmount(campaign.getGoalAmount());
            actualCampaign.setState(CampaignState.PENDING_APPROVAL);

            return campaignDataSource.update(actualCampaign);
        });
    }
}
