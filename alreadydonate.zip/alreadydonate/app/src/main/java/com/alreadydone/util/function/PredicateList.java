package com.alreadydone.util.function;

import java.util.List;
import java.util.function.Predicate;

public class PredicateList<T> implements Predicate<T> {

    private final List<Predicate<T>> predicates;

    public PredicateList(List<Predicate<T>> predicates) {
        this.predicates = predicates;
    }

    @Override
    public boolean test(T t) {
        for (Predicate<T> predicate : predicates) {
            if (!predicate.test(t)) {
                return false;
            }
        }

        return true;
    }
}
