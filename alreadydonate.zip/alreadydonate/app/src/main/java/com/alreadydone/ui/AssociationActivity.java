package com.alreadydone.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.alreadydone.control.campaigns.CampaignRowConfig;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.CampaignInfoObserver;
import com.alreadydone.data.Filters;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Association;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.databinding.ActivityAssociationBinding;
import com.alreadydone.util.Logger;
import com.bumptech.glide.Glide;

import java.util.Arrays;

public class AssociationActivity extends AppCompatActivity {

    private ActivityAssociationBinding binding;
    private String associationId = null;
    private RecyclerListController<CampaignAndDonations> campaignsController;
    private CampaignInfoObserver campaignInfoObserver;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAssociationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final View backBtn = binding.backArrow;

        backBtn.setOnClickListener((v)-> {
            finish();
        });

        campaignsController =
                RecyclerHelper.loadCampaignsInto(binding.viewCampaigns, CampaignRowConfig.forListView(), (campaign)-> {
                    ActivitiesHelper.moveToCampaign(this, campaign.getCampaign().getId());
                });
        campaignInfoObserver = MainRepository.getInstance().createCampaignObserver(campaignsController,
                Arrays.asList(Filters.campaignWithDaysLeft(), Filters.ongoingCampaign()));
        campaignInfoObserver.reFilter(Filters.nothing());
    }

    @Override
    protected void onStart() {
        super.onStart();

        loadAssociationInfo();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        associationId = null;
        campaignInfoObserver.reFilter(Filters.nothing());
    }

    private void loadAssociationInfo() {
        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        if (id == null) {
            Logger.error("Expected id in intent, but it is missing");
            finish();
        }

        associationId = id;

        final TextView name = binding.name;
        final TextView description = binding.description;
        final ImageView profilePic = binding.profileImage;

        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        mainRepository.getAssociationById(associationId).onComplete((result)-> {
            if (result.hasValue()) {
                Association association = result.getValue();

                name.setText(association.getName());
                description.setText(association.getDescription() != null ? association.getDescription() : "");
            } else {
                Throwable error = result.getError();
                Logger.debug("Failed to profile info", error);
                Toast.makeText(this, "Failed to profile info", Toast.LENGTH_LONG).show();
            }
        });

        storageRepository.getAssociationImage(associationId).onComplete((result)-> {
            if (result.hasValue()) {
                Glide.with(this)
                        .load(result.getValue())
                        .into(profilePic);
            } else {
                Throwable error = result.getError();
                Logger.debug("failed to load image", error);
                Toast.makeText(this, "Failed to load profile pic", Toast.LENGTH_LONG).show();
            }
        });

        campaignInfoObserver.reFilter(Filters.campaignOfAssociation(associationId));
    }
}
