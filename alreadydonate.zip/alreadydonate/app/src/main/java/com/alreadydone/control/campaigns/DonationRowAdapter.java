package com.alreadydone.control.campaigns;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.ClickableAdapter;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.util.Logger;
import com.bumptech.glide.Glide;

import java.util.Locale;

public class DonationRowAdapter extends ClickableAdapter<FullDonationInfo, DonationRowAdapter.ViewHolder> {

    public DonationRowAdapter() {
        super(R.layout.donation_box, ViewHolder::new, DonationRowAdapter::bindView);
    }

    private static void bindView(FullDonationInfo item, DonationRowAdapter.ViewHolder holder) {
        if (item.getUser() != null) {
            StorageRepository repository = StorageRepository.getInstance();
            repository.getProfileImage(item.getUser().getId()).onComplete((result)-> {
                if (result.hasValue()) {
                    Glide.with(holder.image.getContext())
                            .load(result.getValue())
                            .into(holder.image);
                } else {
                    Logger.error("Failed to retrieve image for user", result.getError());
                }
            });

            holder.name.setText(item.getUser().getFullName());
        } else {
            holder.name.setText("Anonymous");
        }

        holder.donatedMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) item.getDonation().getAmount()));
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView image;
        public final TextView name;
        public final TextView donatedMoney;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.user_name);
            donatedMoney = itemView.findViewById(R.id.donation_amount);
        }
    }
}
