package com.alreadydone.control.categories;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.BaseAdapter;
import com.alreadydone.data.model.Category;

public class CategoryRowSmallAdapter extends BaseAdapter<Category, CategoryRowSmallAdapter.ViewHolder> {

    public CategoryRowSmallAdapter() {
        super(R.layout.category_box_small, ViewHolder::new, (item, holder)-> {
            holder.name.setText(item.getName());
        });
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final TextView name;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
        }
    }
}
