package com.alreadydone.control.campaigns;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.SingleSelectableAdapter;
import com.alreadydone.data.model.FundraisingType;
import com.alreadydone.data.model.FundraisingTypeData;

import java.util.Locale;

public class CampaignTypeRowSmallAdapter extends SingleSelectableAdapter<FundraisingTypeData, CampaignTypeRowSmallAdapter.ViewHolder> {

    public CampaignTypeRowSmallAdapter() {
        super(R.layout.campaigntype_box_small, ViewHolder::new, (item, holder)-> {
            if (item.campaigns != null) {
                holder.name.setText(String.format(Locale.ENGLISH, "%s (%d)", item.type.name(), item.campaigns.size()));
            } else {
                holder.name.setText(String.format(Locale.ENGLISH, "%s (-)", item.type.name()));
            }
        }, (item)-> item.type == FundraisingType.ALL, null);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final TextView name;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.name);
        }
    }
}
