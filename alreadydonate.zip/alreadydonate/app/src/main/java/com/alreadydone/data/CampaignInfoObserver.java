package com.alreadydone.data;

import com.alreadydone.control.recyclerview.SingleSelectableRecyclerListController;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.Donation;
import com.alreadydone.data.model.FundraisingType;
import com.alreadydone.data.model.FundraisingTypeData;
import com.alreadydone.util.function.PredicateList;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;

public class CampaignInfoObserver implements Registration {

    private final DataRegistry<Campaign> campaignRegistry;
    private final DataRegistry<Donation> donationRegistry;
    private final AtomicReference<DataRegistry.Observer<CampaignAndDonations>> observerRef;
    private final AtomicReference<Predicate<CampaignAndDonations>> filterRef;

    private final Map<String, CampaignAndDonations> data;
    private final RegistrationList registrationList;

    public CampaignInfoObserver(DataRegistry<Campaign> campaignRegistry,
                                DataRegistry<Donation> donationRegistry,
                                DataRegistry.Observer<CampaignAndDonations> observer,
                                Predicate<Campaign> baseFilter) {
        this.campaignRegistry = campaignRegistry;
        this.donationRegistry = donationRegistry;
        this.observerRef = new AtomicReference<>(observer);
        this.filterRef = new AtomicReference<>(Filters.noFilter());
        this.data = new HashMap<>();
        this.registrationList = new RegistrationList();

        Registration registration;
        registration = campaignRegistry.observe(new CampaignObserver(), baseFilter);
        registrationList.add(registration);
        registration = donationRegistry.observe(new DonationObserver());
        registrationList.add(registration);
    }

    public void reFilter(Predicate<Campaign> predicate) {
        DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
        if (observer == null) {
            return;
        }

        Predicate<CampaignAndDonations> newFilter = (info)-> predicate.test(info.getCampaign());
        Predicate<CampaignAndDonations> oldFilter = filterRef.getAndSet(newFilter);

        for (Map.Entry<String, CampaignAndDonations> entry : data.entrySet()) {
            CampaignAndDonations info = entry.getValue();
            boolean inOld = oldFilter.test(info);
            boolean inNew = newFilter.test(info);

            if (inOld && !inNew) {
                observer.itemRemoved(info);
            } else if (!inOld && inNew) {
                observer.itemAdded(info);
            }
        }
    }

    public void reFilter(List<Predicate<Campaign>> predicates) {
        reFilter(new PredicateList<>(predicates));
    }

    private void campaignUpdated(Campaign campaign) {
        CampaignAndDonations info = data.get(campaign.getId());
        if (info == null) {
            info = new CampaignAndDonations(campaign);

            data.put(campaign.getId(), info);

            DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
            Predicate<CampaignAndDonations> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemAdded(info);
            }
        } else {
            DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
            Predicate<CampaignAndDonations> filter = filterRef.get();

            boolean didMeetBeforeChange = (filter == null || filter.test(info));
            info.setCampaign(campaign);
            boolean didMeetAfterChange = (filter == null || filter.test(info));

            if (observer != null) {
                if (didMeetBeforeChange && !didMeetAfterChange) {
                    observer.itemRemoved(info);
                } else if (didMeetBeforeChange && didMeetAfterChange) {
                    observer.itemChanged(info);
                } else {
                    observer.itemAdded(info);
                }
            }
        }
    }

    private void campaignRemoved(Campaign campaign) {
        CampaignAndDonations info = data.get(campaign.getId());
        if (info != null) {
            DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
            Predicate<CampaignAndDonations> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemRemoved(info);
            }
        }
    }

    private void donationAdded(Donation donation) {
        CampaignAndDonations info = data.get(donation.getCampaignId());
        if (info == null) {
            return;
        }

        info.addDonation(donation);

        DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
        Predicate<CampaignAndDonations> filter = filterRef.get();
        if (observer != null && (filter == null || filter.test(info))) {
            observer.itemChanged(info);
        }
    }

    private void donationChanged(Donation donation) {
        CampaignAndDonations info = data.get(donation.getCampaignId());
        if (info == null) {
            return;
        }

        info.updateDonation(donation);

        DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
        Predicate<CampaignAndDonations> filter = filterRef.get();
        if (observer != null && (filter == null || filter.test(info))) {
            observer.itemChanged(info);
        }
    }

    private void donationRemoved(Donation donation) {
        CampaignAndDonations info = data.get(donation.getCampaignId());
        if (info == null) {
            return;
        }

        info.removeDonation(donation);

        DataRegistry.Observer<CampaignAndDonations> observer = observerRef.get();
        Predicate<CampaignAndDonations> filter = filterRef.get();
        if (observer != null && (filter == null || filter.test(info))) {
            observer.itemChanged(info);
        }
    }

    @Override
    public void close() {
        registrationList.close();
    }

    private class CampaignObserver implements DataRegistry.Observer<Campaign> {

        @Override
        public void itemAdded(Campaign campaign) {
            campaignUpdated(campaign);
        }

        @Override
        public void itemChanged(Campaign campaign) {
            campaignUpdated(campaign);
        }

        @Override
        public void itemRemoved(Campaign campaign) {
            campaignRemoved(campaign);
        }
    }

    private class DonationObserver implements DataRegistry.Observer<Donation> {

        @Override
        public void itemAdded(Donation donation) {
            donationAdded(donation);
        }

        @Override
        public void itemChanged(Donation donation) {
            donationChanged(donation);
        }

        @Override
        public void itemRemoved(Donation donation) {
            donationRemoved(donation);
        }
    }

    public static class TypedCampaignControl implements DataRegistry.Observer<CampaignAndDonations> {

        private final SingleSelectableRecyclerListController<FundraisingTypeData> typeListController;
        private final Map<FundraisingType, FundraisingTypeData> typesMapping;
        private final Map<String, FundraisingType> campaignTypeMapping;

        public TypedCampaignControl(SingleSelectableRecyclerListController<FundraisingTypeData> typeListController) {
            this.typeListController = typeListController;
            typesMapping = new HashMap<>();
            campaignTypeMapping = new HashMap<>();
        }

        public void load() {
            typesMapping.clear();
            for (FundraisingType type : FundraisingType.values()) {
                typesMapping.put(type, new FundraisingTypeData(type, new ArrayList<>()));
            }

            List<FundraisingTypeData> fundraisingTypeData = new ArrayList<>(typesMapping.values());
            fundraisingTypeData.sort(Comparator.comparing((type)-> type.type.name()));
            typeListController.replace(fundraisingTypeData);
        }

        @Override
        public void itemAdded(CampaignAndDonations campaignAndDonations) {
            FundraisingType type = FundraisingType.getTypeForCampaign(campaignAndDonations.getCampaign());
            campaignTypeMapping.put(campaignAndDonations.getCampaign().getId(), type);

            FundraisingTypeData data = typesMapping.get(type);
            if (data != null) {
                data.campaigns.add(campaignAndDonations);
                typeListController.itemChanged(data);
            }

            data = typesMapping.get(FundraisingType.ALL);
            if (data != null) {
                data.campaigns.add(campaignAndDonations);
                typeListController.itemChanged(data);
            }
        }

        @Override
        public void itemChanged(CampaignAndDonations campaignAndDonations) {
            FundraisingType oldType = campaignTypeMapping.get(campaignAndDonations.getCampaign().getId());
            FundraisingType type = FundraisingType.getTypeForCampaign(campaignAndDonations.getCampaign());

            if (oldType != type) {
                FundraisingTypeData data = typesMapping.get(oldType);
                if (data != null) {
                    data.campaigns.remove(campaignAndDonations);
                    typeListController.itemChanged(data);
                }

                data = typesMapping.get(type);
                if (data != null) {
                    data.campaigns.add(campaignAndDonations);
                    typeListController.itemChanged(data);
                }
            } else {
                FundraisingTypeData data = typesMapping.get(type);
                if (data != null) {
                    int index = data.campaigns.indexOf(campaignAndDonations);
                    if (index >= 0) {
                        data.campaigns.set(index, campaignAndDonations);
                    } else {
                        data.campaigns.add(campaignAndDonations);
                    }

                    typeListController.itemChanged(data);
                }
            }

            FundraisingTypeData data = typesMapping.get(FundraisingType.ALL);
            if (data != null) {
                int index = data.campaigns.indexOf(campaignAndDonations);
                if (index >= 0) {
                    data.campaigns.set(index, campaignAndDonations);
                    typeListController.itemChanged(data);
                }
            }
        }

        @Override
        public void itemRemoved(CampaignAndDonations campaignAndDonations) {
            campaignTypeMapping.remove(campaignAndDonations.getCampaign().getId());

            FundraisingType type = FundraisingType.getTypeForCampaign(campaignAndDonations.getCampaign());
            FundraisingTypeData data = typesMapping.get(type);
            if (data != null) {
                data.campaigns.remove(campaignAndDonations);
                typeListController.itemChanged(data);
            }

            data = typesMapping.get(FundraisingType.ALL);
            if (data != null) {
                data.campaigns.remove(campaignAndDonations);
                typeListController.itemChanged(data);
            }
        }
    }
}
