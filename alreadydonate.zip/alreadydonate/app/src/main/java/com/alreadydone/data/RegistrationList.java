package com.alreadydone.data;

import java.util.ArrayList;
import java.util.List;

public class RegistrationList implements Registration {

    private final List<Registration> registrations;

    public RegistrationList() {
        registrations = new ArrayList<>();
    }

    public void add(Registration registration) {
        registrations.add(registration);
    }

    @Override
    public void close() {
        for (Registration registration : registrations) {
            registration.close();
        }
    }
}
