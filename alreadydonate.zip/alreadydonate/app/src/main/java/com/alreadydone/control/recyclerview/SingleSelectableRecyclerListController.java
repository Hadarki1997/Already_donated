package com.alreadydone.control.recyclerview;

public class SingleSelectableRecyclerListController<T> extends RecyclerListController<T> {

    private final SingleSelectableAdapter<T, ?> adapter;

    public SingleSelectableRecyclerListController(SingleSelectableAdapter<T, ?> adapter) {
        super(adapter);
        this.adapter = adapter;
    }

    public T getSelected() {
        return adapter.getSelected();
    }

    public void clearSelected() {
        adapter.clearSelected();
    }
}
