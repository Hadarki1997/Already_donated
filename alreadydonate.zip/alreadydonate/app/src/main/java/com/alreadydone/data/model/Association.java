package com.alreadydone.data.model;

import com.alreadydone.data.meta.annotations.Column;
import com.alreadydone.data.meta.annotations.Ref;

import java.util.Objects;

@Ref(name = "associations")
public class Association {

    @Column(primaryKey = true)
    private String id;
    @Column
    private String name;
    @Column
    private String userId;
    @Column
    private String description;

    public Association() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof Association)) return false;
        Association that = (Association) object;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
