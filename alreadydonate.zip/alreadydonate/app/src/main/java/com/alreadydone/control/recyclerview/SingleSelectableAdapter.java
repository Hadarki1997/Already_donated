package com.alreadydone.control.recyclerview;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class SingleSelectableAdapter<T, A extends RecyclerView.ViewHolder> extends BaseAdapter<T, A> {

    private final Predicate<T> initialSelected;
    private final BiConsumer<A, Boolean> onSelection;

    private final AtomicReference<Consumer<T>> onSelect;
    private T selected;
    private A selectedHolder;

    public SingleSelectableAdapter(int layoutId, Function<View, A> aCreator, BiConsumer<T, A> bind, Predicate<T> initialSelected, BiConsumer<A, Boolean> onSelection) {
        super(layoutId, aCreator, bind);
        this.initialSelected = initialSelected;
        this.onSelection = onSelection;

        this.onSelect = new AtomicReference<>();
        this.selected = null;
        this.selectedHolder = null;
    }

    public SingleSelectableAdapter(int layoutId, Function<View, A> aCreator, BiConsumer<T, A> bind) {
        this(layoutId, aCreator, bind, null, null);
    }

    public T getSelected() {
        return selected;
    }

    public void clearSelected() {
        clearSelection();
    }

    public void setOnSelect(Consumer<T> onSelect) {
        this.onSelect.set(onSelect);

        if (selected != null) {
            onSelect.accept(selected);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull A holder, int position) {
        super.onBindViewHolder(holder, position);

        T t = list.get(position);

        holder.itemView.setClickable(true);
        holder.itemView.setOnClickListener((view)-> {
            select(holder, t, true);
        });

        if (initialSelected != null && initialSelected.test(t)) {
            select(holder, t, false);
        }
    }

    private void select(A holder, T t, boolean notify) {
        if (selected != null && selected == t) {
            return;
        }

        clearSelection();

        holder.itemView.setSelected(true);
        selected = t;
        selectedHolder = holder;

        if (onSelection != null) {
            onSelection.accept(selectedHolder, true);
        }

        Consumer<T> onSelect = this.onSelect.get();
        if (onSelect != null && notify) {
            onSelect.accept(selected);
        }
    }

    private void clearSelection() {
        if (selected != null) {
            selectedHolder.itemView.setSelected(false);

            if (onSelection != null) {
                onSelection.accept(selectedHolder, false);
            }

            selected = null;
            selectedHolder = null;
        }
    }
}
