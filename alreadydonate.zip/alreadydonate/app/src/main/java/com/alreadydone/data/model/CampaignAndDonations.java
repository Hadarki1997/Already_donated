package com.alreadydone.data.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class CampaignAndDonations {

    private Campaign campaign;
    private List<Donation> donations;

    public CampaignAndDonations(Campaign campaign, List<Donation> donations) {
        this.campaign = campaign;
        this.donations = donations;
    }

    public CampaignAndDonations(Campaign campaign) {
        this(campaign, new ArrayList<>());
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public List<Donation> getDonations() {
        return Collections.unmodifiableList(donations);
    }

    public void addDonation(Donation donation) {
        donations.add(donation);
    }

    public void updateDonation(Donation donation) {
        int index = getDonationIndex(donation);
        if (index >= 0) {
            donations.set(index, donation);
        }
    }

    public void removeDonation(Donation donation) {
        int index = getDonationIndex(donation);
        if (index >= 0) {
            donations.remove(index);
        }
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        CampaignAndDonations that = (CampaignAndDonations) object;
        return this.campaign.getId().equals(that.campaign.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hash(campaign, donations);
    }

    @Override
    public String toString() {
        return "CampaignAndDonations{" +
                "campaign=" + campaign +
                ", donations=" + donations +
                '}';
    }

    private int getDonationIndex(Donation donation) {
        for (int i = 0; i < donations.size(); i++) {
            Donation d = donations.get(i);
            if (d.getId().equals(donation.getId())) {
                return i;
            }
        }

        return -1;
    }
}
