package com.alreadydone.control.form;

public class ValidationResult {

    private final boolean isValid;
    private final String errorMsg;

    private ValidationResult(boolean isValid, String errorMsg) {
        this.isValid = isValid;
        this.errorMsg = errorMsg;
    }

    public static ValidationResult valid() {
        return new ValidationResult(true, null);
    }

    public static ValidationResult notValid(String msg) {
        return new ValidationResult(false, msg);
    }

    public boolean isValid() {
        return isValid;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
