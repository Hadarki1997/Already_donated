package com.alreadydone.ui.fragments;

import com.alreadydone.data.model.PaymentMethod;

public interface DonationSetupParent extends PinSelectionParent {

    class DonationInfo {
        public int amount;
        public boolean anonymous;
    }

    void setSelectedDonationInfo(DonationInfo info);
    void setPaymentMethod(PaymentMethod paymentMethod);

    void onContinue();
}
