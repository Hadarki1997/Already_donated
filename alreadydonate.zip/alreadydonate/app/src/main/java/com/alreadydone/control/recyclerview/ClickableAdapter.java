package com.alreadydone.control.recyclerview;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

public class ClickableAdapter<T, A extends RecyclerView.ViewHolder> extends BaseAdapter<T, A> {

    private final AtomicReference<Consumer<T>> onClick;

    public ClickableAdapter(int layoutId, Function<View, A> aCreator, BiConsumer<T, A> bind) {
        super(layoutId, aCreator, bind);

        this.onClick = new AtomicReference<>();
    }

    public void setOnClick(Consumer<T> onClick) {
        this.onClick.set(onClick);
    }

    @Override
    public void onBindViewHolder(@NonNull A holder, int position) {
        super.onBindViewHolder(holder, position);

        T t = list.get(position);
        holder.itemView.setClickable(true);
        holder.itemView.setOnClickListener((view)-> {
            Consumer<T> onSelect = this.onClick.get();
            if (onSelect != null) {
                onSelect.accept(t);
            }
        });
    }
}
