package com.alreadydone.control.campaigns;

import android.net.Uri;
import android.view.View;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.BaseAdapter;
import com.bumptech.glide.Glide;

public class CampaignImageAdapter extends BaseAdapter<Uri, CampaignImageAdapter.ViewHolder> {

    public CampaignImageAdapter() {
        super(R.layout.single_image_view, ViewHolder::new, (item, holder)-> {
            Glide.with(holder.itemView.getContext())
                    .load(item)
                    .into(holder.view);
        });
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            view = itemView.findViewById(R.id.image);
        }
    }
}
