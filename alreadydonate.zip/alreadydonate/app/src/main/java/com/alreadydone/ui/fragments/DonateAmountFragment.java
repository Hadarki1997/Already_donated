package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.PaymentOptionAdapter;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class DonateAmountFragment extends Fragment {

    private static final Pattern NUMBER_PATTERN = Pattern.compile("^\\d+$");

    private EditText amountTxt;
    private CheckBox asAnonymous;
    private View continueBtn;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_donate_amount, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        amountTxt = view.findViewById(R.id.input);
        final RecyclerView quickOptions = view.findViewById(R.id.quick_options);
        asAnonymous = view.findViewById(R.id.anonymous_select);
        continueBtn = view.findViewById(R.id.continueBtn);

        List<Integer> paymentQuickSelectOptions = Arrays.asList(5, 10, 25, 50, 100, 200);
        PaymentOptionAdapter adapter = new PaymentOptionAdapter(paymentQuickSelectOptions, (amount)-> {
            amountTxt.setText(String.format(Locale.ENGLISH, "%d", amount));
        });
        quickOptions.setAdapter(adapter);

        amountTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                validateAmount(s);
            }
        });
        amountTxt.setText("0");

        continueBtn.setOnClickListener((v)-> {
            save();
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        validateAmount(amountTxt.getText());
    }

    private void save() {
        DonationSetupParent.DonationInfo donationInfo = new DonationSetupParent.DonationInfo();
        String value = amountTxt.getText().toString();
        donationInfo.amount = Integer.parseInt(value);
        donationInfo.anonymous = asAnonymous.isChecked();

        DonationSetupParent parent = getParent();
        parent.setSelectedDonationInfo(donationInfo);
        parent.onContinue();
    }

    private void validateAmount(Editable s) {
        String value = s.toString();
        if (!NUMBER_PATTERN.matcher(value).matches()) {
            continueBtn.setEnabled(false);
        } else {
            int amount = Integer.parseInt(value);
            continueBtn.setEnabled(amount >= 1);
        }
    }

    private DonationSetupParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof DonationSetupParent) {
            return (DonationSetupParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof DonationSetupParent) {
            return (DonationSetupParent) activity;
        }

        throw new IllegalStateException("parent does not support setup");
    }
}
