package com.alreadydone.data.exceptions;

import java.util.Locale;

public class IllegalModelException extends DataException {

    public IllegalModelException(Class<?> modelCls, String message) {
        super(String.format(Locale.ENGLISH, "model %s not legal: %s", modelCls.getName(), message));
    }
}
