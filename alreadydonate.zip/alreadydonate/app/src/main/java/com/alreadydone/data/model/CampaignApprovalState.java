package com.alreadydone.data.model;

import com.alreadydone.data.meta.annotations.Column;
import com.alreadydone.data.meta.annotations.Ref;

import java.time.ZonedDateTime;
import java.util.Objects;

@Ref(name = "campaign_approval")
public class CampaignApprovalState {

    @Column(primaryKey = true)
    private String id;
    @Column(optional = true)
    private String description;
    @Column
    private boolean rejected;
    @Column
    private ZonedDateTime updateTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isRejected() {
        return rejected;
    }

    public void setRejected(boolean rejected) {
        this.rejected = rejected;
    }

    public ZonedDateTime getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(ZonedDateTime updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof CampaignApprovalState)) return false;
        CampaignApprovalState that = (CampaignApprovalState) object;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
