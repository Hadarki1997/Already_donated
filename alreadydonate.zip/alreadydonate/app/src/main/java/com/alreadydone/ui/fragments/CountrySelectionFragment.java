package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.countries.CountryInfo;
import com.alreadydone.control.countries.CountryList;
import com.alreadydone.control.countries.CountryRowAdapter;
import com.alreadydone.util.Logger;

import java.util.List;

public class CountrySelectionFragment extends Fragment {

    private View continueBtn;
    private CountryRowAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_country_selection, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final RecyclerView countryFlagView = view.findViewById(R.id.countryList);
        continueBtn = view.findViewById(R.id.continueBtn);

        List<CountryInfo> countryInfos = CountryList.COUNTRY_INFOS;
        adapter = new CountryRowAdapter(countryInfos, (countryInfo)-> {
            Logger.debug("Country selected %s", countryInfo.englishName);
            continueBtn.setVisibility(View.VISIBLE);
            continueBtn.setEnabled(true);
        });
        countryFlagView.setAdapter(adapter);

        continueBtn.setEnabled(false);
        continueBtn.setOnClickListener((v)-> {
            save();
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        if (adapter.getSelectedCountry() != null) {
            continueBtn.setVisibility(View.VISIBLE);
            continueBtn.setEnabled(true);
        } else {
            continueBtn.setVisibility(View.GONE);
            continueBtn.setEnabled(false);
        }
    }

    private void save() {
        AccountSetupParent parent = getParent();
        parent.setSelectedCountry(adapter.getSelectedCountry());
        parent.onContinue();
    }

    private AccountSetupParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof AccountSetupParent) {
            return (AccountSetupParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof AccountSetupParent) {
            return (AccountSetupParent) activity;
        }

        throw new IllegalStateException("parent does not support setup");
    }
}
