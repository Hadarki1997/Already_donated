package com.alreadydone.control.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.alreadydone.R;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Optional;

public class CampaignRejectDialog extends Dialog {

    private Form form;
    private boolean hasResult = false;

    public CampaignRejectDialog(@NonNull Context context) {
        super(context);
    }

    public Optional<String> getResult() {
        if (!hasResult) {
            return Optional.empty();
        }

        FormResult result = form.getResult();
        if (!result.areAllValid()) {
            return Optional.empty();
        }

        return Optional.of(result.getField("Description", String.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.reject_dialog);

        hasResult = false;

        final View continueBtn = findViewById(R.id.continueBtn);
        final TextInputEditText descriptionTxt = findViewById(R.id.description);

        form = new Form.Builder()
                .register("Description", FormInput.create(descriptionTxt))
                        .withValidator(Validators.longEnough(5))
                        .build()
                .build();

        continueBtn.setOnClickListener((v)-> {
            FormResult result = form.getResult();
            if (!result.areAllValid()) {
                return;
            }

            hasResult = true;
            dismiss();
        });
    }
}
