package com.alreadydone.data.model;

import com.alreadydone.data.meta.annotations.Column;
import com.alreadydone.data.meta.annotations.Ref;

import java.time.ZonedDateTime;
import java.util.Objects;

@Ref(name = "payment_methods")
public class PaymentMethod {

    @Column(primaryKey = true)
    private String id;
    @Column
    private String userId;
    @Column
    private PaymentMethodType type;

    @Column(optional = true)
    private String ownerName;
    @Column(optional = true)
    private String cardNumber;
    @Column(optional = true)
    private ZonedDateTime expirationDate;
    @Column(optional = true)
    private String cvv;

    public PaymentMethod() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public PaymentMethodType getType() {
        return type;
    }

    public void setType(PaymentMethodType type) {
        this.type = type;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public ZonedDateTime getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(ZonedDateTime expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof PaymentMethod)) return false;
        PaymentMethod that = (PaymentMethod) object;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
