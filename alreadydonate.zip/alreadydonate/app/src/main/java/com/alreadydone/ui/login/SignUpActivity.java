package com.alreadydone.ui.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.databinding.ActivitySignUpBinding;
import com.alreadydone.ui.ActivitiesHelper;
import com.alreadydone.ui.fragments.AuthFragment;
import com.alreadydone.ui.fragments.AuthParent;
import com.alreadydone.util.Logger;
import com.alreadydone.util.future.Future;

import java.util.Arrays;
import java.util.function.Consumer;

public class SignUpActivity extends AppCompatActivity implements AuthParent {

    private ActivitySignUpBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final View loginLink = binding.loginLink;
        final ViewPager2 pager = binding.pager;

        Bundle additionalArgs = new Bundle();
        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                Arrays.asList(
                        new GenericPagerAdapter.FragmentDef(AuthFragment::new)
                ),
                additionalArgs
        ));
        pager.setCurrentItem(0, false);

        loginLink.setOnClickListener((view)-> {
            ActivitiesHelper.moveToLogin(this);
        });
    }

    @Override
    public String getBtnText() {
        return "Sign Up";
    }

    @Override
    public void acceptAuthInfo(AutoInfo info, Consumer<String> onError) {
        LoginRepository loginRepository = LoginRepository.getInstance();
        Future.checkedCall(
            ()-> loginRepository.signup(info.email, info.password),
            (result)-> {
                if (result.hasValue()) {
                    Toast.makeText(this, getString(R.string.welcome) + info.email, Toast.LENGTH_LONG).show();
                    ActivitiesHelper.moveToMain(this);
                } else {
                    Logger.error("Login failed", result.getError());
                    Toast.makeText(this, "Login Failed", Toast.LENGTH_LONG).show();
                    onError.accept(getErrorString(result.getError()));
                }
            }
        );
    }

    private String getErrorString(Throwable error) {
        Throwable cause = error.getCause();
        if (cause == null) {
            return error.getMessage();
        }

        return cause.getMessage();
    }
}