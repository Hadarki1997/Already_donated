package com.alreadydone.ui.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.databinding.ActivityLoginBinding;
import com.alreadydone.ui.ActivitiesHelper;
import com.alreadydone.ui.fragments.AuthFragment;
import com.alreadydone.ui.fragments.AuthParent;
import com.alreadydone.util.Logger;

import java.util.Arrays;
import java.util.function.Consumer;

public class LoginActivity extends AppCompatActivity implements AuthParent {

    private ActivityLoginBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final View forgotPasswordLink = binding.forgotPassword;
        final View signUpLink = binding.signUpLink;
        final ViewPager2 pager = binding.pager;

        Bundle additionalArgs = new Bundle();
        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                Arrays.asList(
                        new GenericPagerAdapter.FragmentDef(AuthFragment::new)
                ),
                additionalArgs
        ));
        pager.setCurrentItem(0, false);

        forgotPasswordLink.setOnClickListener((view)-> {
            forgotPassword();
        });

        signUpLink.setOnClickListener((view)-> {
            ActivitiesHelper.moveToSignUp(this);
        });
    }

    private void forgotPassword() {
        Logger.debug("User requested \"forgot password\"");
    }

    @Override
    public String getBtnText() {
        return "Log In";
    }

    @Override
    public void acceptAuthInfo(AutoInfo info, Consumer<String> onError) {
        LoginRepository loginRepository = LoginRepository.getInstance();
        loginRepository.login(info.email, info.password).onComplete((result)-> {
            if (result.hasValue()) {
                Toast.makeText(this, getString(R.string.welcome) + info.email, Toast.LENGTH_LONG).show();
                ActivitiesHelper.moveToMain(this);
            } else {
                Logger.error("Login failed", result.getError());
                Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
                onError.accept(getErrorString(result.getError()));
            }
        });
    }

    private String getErrorString(Throwable error) {
        Throwable cause = error.getCause();
        if (cause == null) {
            return error.getMessage();
        }

        return cause.getMessage();
    }
}