package com.alreadydone.control.form;

public class ValidatedValue<T> {

    public final T value;
    public final ValidationResult validationResult;

    public ValidatedValue(T value, ValidationResult validationResult) {
        this.value = value;
        this.validationResult = validationResult;
    }

    public boolean isValid() {
        return validationResult.isValid();
    }
}
