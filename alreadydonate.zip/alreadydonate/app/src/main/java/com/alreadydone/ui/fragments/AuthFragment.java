package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.alreadydone.R;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.google.android.material.textfield.TextInputEditText;

import java.util.function.Consumer;

public class AuthFragment extends Fragment {

    private View formErrorLayout;
    private TextView saveBtnTxt;
    private View saveBtn;
    private Form form;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_auth, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final TextInputEditText emailEditText = view.findViewById(R.id.email);
        final TextInputEditText passwordEditText = view.findViewById(R.id.password);
        final TextView formErrorText = view.findViewById(R.id.form_error);

        formErrorLayout = view.findViewById(R.id.form_error_layout);
        saveBtnTxt = view.findViewById(R.id.login_btn_txt);
        saveBtn = view.findViewById(R.id.login_btn);
        saveBtn.setEnabled(true);
        saveBtn.setClickable(true);

        form = new Form.Builder()
                .register("Email", FormInput.create(emailEditText))
                    .withValidator(Validators.notBlank())
                    .withValidator(Validators.isEmail())
                    .build()
                .register("Password", FormInput.create(passwordEditText))
                    .withValidator(Validators.longEnough(5))
                    .build()
                .build();
        form.enableAutoValidation();

        Consumer<String> onError = (message)-> {
            formErrorLayout.setVisibility(View.VISIBLE);
            formErrorText.setText(message);
        };

        saveBtn.setOnClickListener((v)-> {
            FormResult result = form.getResult();
            if (!result.areAllValid()) {
                return;
            }

            String email = result.getField("Email", String.class).trim();
            String password = result.getField("Password", String.class).trim();

            AuthParent.AutoInfo authInfo = new AuthParent.AutoInfo();
            authInfo.email = email;
            authInfo.password = password;

            getParent().acceptAuthInfo(authInfo, onError);
        });
    }

    @Override
    public void onStart() {
        super.onStart();

        formErrorLayout.setVisibility(View.GONE);
        saveBtnTxt.setText(getParent().getBtnText());
    }

    private AuthParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof AuthParent) {
            return (AuthParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof AuthParent) {
            return (AuthParent) activity;
        }

        throw new IllegalStateException("parent does not support saving");
    }
}
