package com.alreadydone.data.model;

import java.util.List;

public class FundraisingTypeData {

    public final FundraisingType type;
    public final List<CampaignAndDonations> campaigns;

    public FundraisingTypeData(FundraisingType type, List<CampaignAndDonations> campaigns) {
        this.type = type;
        this.campaigns = campaigns;
    }

    public FundraisingTypeData(FundraisingType type) {
        this(type, null);
    }
}
