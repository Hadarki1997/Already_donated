package com.alreadydone.control.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;

public class BaseAdapter<T, A extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<A> {

    private final int layoutId;
    private final Function<View, A> aCreator;
    private final BiConsumer<T, A> bind;

    final List<T> list;

    public BaseAdapter(int layoutId, Function<View, A> aCreator, BiConsumer<T, A> bind) {
        this.layoutId = layoutId;
        this.aCreator = aCreator;
        this.bind = bind;

        this.list = new ArrayList<>();
    }

    @NonNull
    @Override
    public A onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View view = inflater.inflate(layoutId, parent, false);
        return aCreator.apply(view);
    }

    @Override
    public void onBindViewHolder(@NonNull A holder, int position) {
        T t = list.get(position);

        bind.accept(t, holder);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
}
