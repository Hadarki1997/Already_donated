package com.alreadydone.data.meta;

import com.alreadydone.data.model.Association;
import com.alreadydone.data.model.Bookmark;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignApprovalState;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.Donation;
import com.alreadydone.data.model.PaymentMethod;
import com.alreadydone.data.model.User;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class ModelMetaRegistry {

    private static final Map<Class<?>, ModelMeta<?>> registry;

    static {
        Map<Class<?>, ModelMeta<?>> registryMap = new HashMap<>();
        registryMap.put(User.class, new ReflectiveModelMeta<>(User.class));
        registryMap.put(Association.class, new ReflectiveModelMeta<>(Association.class));
        registryMap.put(Campaign.class, new ReflectiveModelMeta<>(Campaign.class));
        registryMap.put(Donation.class, new ReflectiveModelMeta<>(Donation.class));
        registryMap.put(Category.class, new ReflectiveModelMeta<>(Category.class));
        registryMap.put(Bookmark.class, new ReflectiveModelMeta<>(Bookmark.class));
        registryMap.put(PaymentMethod.class, new ReflectiveModelMeta<>(PaymentMethod.class));
        registryMap.put(CampaignApprovalState.class, new ReflectiveModelMeta<>(CampaignApprovalState.class));

        registry = Collections.unmodifiableMap(registryMap);
    }

    public static <T> ModelMeta<T> getMetaForModel(Class<T> cls) {
        ModelMeta<?> meta = registry.get(cls);
        if (meta == null) {
            throw new IllegalArgumentException(cls.getName());
        }

        //noinspection unchecked
        return (ModelMeta<T>) meta;
    }

    public static <T> ModelMeta<T> getMetaForModel(T t) {
        //noinspection unchecked
        return (ModelMeta<T>) getMetaForModel(t.getClass());
    }
}
