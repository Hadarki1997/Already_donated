package com.alreadydone.control.campaigns;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.AdvancedClickableAdapter;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.util.Logger;
import com.bumptech.glide.Glide;

import java.util.Locale;
import java.util.Map;

public class InAdminCampaignRowAdapter extends AdvancedClickableAdapter<Campaign, InAdminCampaignRowAdapter.ViewHolder, InAdminCampaignRowAdapter.ClickType> {

    public enum ClickType {
        ALL,
        APPROVE
    }

    public InAdminCampaignRowAdapter() {
        super(R.layout.campaign_box_sideways_inadmin, ViewHolder::new,
                InAdminCampaignRowAdapter::bindItem,
                InAdminCampaignRowAdapter::configClicks);
    }

    private static void bindItem(Campaign campaign, InAdminCampaignRowAdapter.ViewHolder holder) {
        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        int height = holder.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.campaign_box_height_expanded_small);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);

        int margin = holder.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.campaign_box_margin);
        params.setMargins(margin, margin, margin, margin);

        holder.itemView.setLayoutParams(params);

        StorageRepository repository = StorageRepository.getInstance();
        repository.getCampaignImage(campaign.getId()).onComplete((result)-> {
            if (result.hasValue()) {
                Glide.with(holder.image.getContext())
                        .load(result.getValue())
                        .into(holder.image);
            } else {
                Logger.error("Failed to retrieve image for campaign", result.getError());
                holder.image.setImageResource(R.drawable.groups);
            }
        });

        holder.name.setText(campaign.getName());
        holder.requiredMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.getGoalAmount()));
        holder.daysLeft.setText(String.format(Locale.ENGLISH, "%d", campaign.getDaysLeftToDonate()));

        if (campaign.getState() == CampaignState.PENDING_APPROVAL) {
            holder.stateTxt.setText("Waiting Approval");
            holder.stateTxt.setTextColor(holder.itemView.getContext().getResources().getColor(R.color.main_theme_color));
            holder.stateTxt.setVisibility(View.VISIBLE);
        } else if (campaign.getState() == CampaignState.APPROVAL_REJECTED) {
            holder.stateTxt.setText("Rejected");
            holder.stateTxt.setTextColor(holder.itemView.getContext().getResources().getColor(R.color.rejected));
            holder.stateTxt.setVisibility(View.VISIBLE);
        } else {
            holder.stateTxt.setText("");
            holder.stateTxt.setVisibility(View.GONE);
        }
    }

    private static Map<View, ClickType> configClicks(Campaign campaign, InAdminCampaignRowAdapter.ViewHolder holder) {
        return Map.of(
                holder.itemView, ClickType.ALL,
                holder.approveBtn, ClickType.APPROVE);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView image;
        public final TextView name;
        public final TextView requiredMoney;
        public final TextView daysLeft;
        public final View approveBtn;
        public final TextView stateTxt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            requiredMoney = itemView.findViewById(R.id.total_money);
            daysLeft = itemView.findViewById(R.id.days_left);
            approveBtn = itemView.findViewById(R.id.approve_btn);
            stateTxt = itemView.findViewById(R.id.state);
        }
    }
}
