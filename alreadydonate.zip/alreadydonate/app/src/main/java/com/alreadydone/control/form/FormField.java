package com.alreadydone.control.form;

public interface FormField<T> {

    ValidatedValue<T> validateAndGetValue();

    void enableAutoValidate(Validator<T> additionalValidator);

    default void enableAutoValidate() {
        enableAutoValidate(Validators.alwaysValid());
    }

    <T2> FormField<T2> as(Converter<T, T2> converter, Validator<T2> validator);
}
