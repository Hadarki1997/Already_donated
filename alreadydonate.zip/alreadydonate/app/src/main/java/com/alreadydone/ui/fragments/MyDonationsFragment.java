package com.alreadydone.ui.fragments;

import static com.google.android.material.resources.MaterialAttributes.resolveOrThrow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.DonationInfoObserver;
import com.alreadydone.data.Filters;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.ui.ActivitiesHelper;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.datepicker.MaterialPickerOnPositiveButtonClickListener;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Optional;

public class MyDonationsFragment extends Fragment {

    private String userId;
    private RecyclerListController<FullDonationInfo> donationsController;
    private DonationInfoObserver donationInfoObserver;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_my_donations, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        LoginRepository loginRepository = LoginRepository.getInstance();
        Optional<LoggedInUser> optional = loginRepository.getLoggedUser();
        if (!optional.isPresent()) {
            ActivitiesHelper.moveToLogin(getActivity());
            return;
        }

        final Bundle arguments = getArguments();
        userId = arguments.getString("userId", null);

        DatePicker datePicker = view.findViewById(R.id.datepicker);
        LocalDate date = LocalDate.now();
        datePicker.init(date.getYear(), date.getMonthValue() - 1, date.getDayOfMonth(), new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                LocalDate date = LocalDate.of(year, monthOfYear + 1, dayOfMonth);
                donationInfoObserver.reFilter(Filters.onDate(date));
            }
        });

        final RecyclerView donationsView = view.findViewById(R.id.view_donations);
        donationsController =
                RecyclerHelper.loadDonationsFullInto(donationsView, (item)-> {});
        donationInfoObserver = MainRepository.getInstance().createDonationObserver(donationsController, Filters.donationByUser(userId));
        donationInfoObserver.reFilter(Filters.onDate(date));
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        donationInfoObserver.close();
    }
}