package com.alreadydone.data.exceptions;

public class DataException extends RuntimeException {

    public DataException(Throwable cause) {
        super(cause);
    }

    public DataException(String message) {
        super(message);
    }

    public DataException() {

    }
}
