package com.alreadydone.control.payments;

import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.SingleSelectableAdapter;
import com.alreadydone.data.model.PaymentMethod;

import java.util.Locale;

public class PaymentMethodRowAdapter extends SingleSelectableAdapter<PaymentMethod, PaymentMethodRowAdapter.ViewHolder> {

    public PaymentMethodRowAdapter() {
        super(R.layout.payment_method_box, ViewHolder::new, PaymentMethodRowAdapter::onBind, null, (holder, selected)-> {
            holder.selected.setChecked(selected);
        });
    }

    private static void onBind(PaymentMethod item, ViewHolder viewHolder) {
        switch (item.getType()) {
            case PAYPAL: {
                viewHolder.image.setImageResource(R.drawable.payment_icon_paypal);
                viewHolder.name.setText("Paypal");
                break;
            }
            case GOOGLE_PAY: {
                viewHolder.image.setImageResource(R.drawable.payment_icon_googlepay);
                viewHolder.name.setText("Google Pay");
                break;
            }
            case CREDIT_CARD: {
                viewHolder.image.setImageResource(R.drawable.payment_icon_debit);
                String number = item.getCardNumber();
                viewHolder.name.setText(String.format(Locale.ENGLISH, "**** **** **** %s", number.substring(12)));
                break;
            }
            default:
                break;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView image;
        public final TextView name;
        private final RadioButton selected;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            selected = itemView.findViewById(R.id.selected);
        }
    }
}
