package com.alreadydone.util.function;

import java.util.concurrent.atomic.AtomicReference;

public class BasicProperty<T> {

    private final AtomicReference<T> ref;

    public BasicProperty(T value) {
        ref = new AtomicReference<>(value);
    }

    public T get() {
        return ref.get();
    }

    public void set(T value) {
        ref.set(value);
    }
}
