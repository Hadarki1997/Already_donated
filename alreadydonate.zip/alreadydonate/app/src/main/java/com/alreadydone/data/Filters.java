package com.alreadydone.data;

import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.Donation;
import com.alreadydone.data.model.FullDonationInfo;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Filters {

    public static <T> Predicate<T> noFilter() {
        return (t)-> true;
    }

    public static <T> Predicate<T> nothing() {
        return (t)-> false;
    }

    public static Predicate<Campaign> campaignWithState(CampaignState state) {
        return (campaign)-> campaign.getState() == state;
    }

    public static Predicate<Campaign> ongoingCampaign() {
        return campaignWithState(CampaignState.ONGOING);
    }

    public static Predicate<Campaign> unapprovedCampaign() {
        return campaignWithState(CampaignState.PENDING_APPROVAL);
    }

    public static Predicate<Campaign> campaignWithDaysLeft() {
        return (campaign)-> campaign.getDaysLeftToDonate() > 0;
    }

    public static Predicate<Campaign> campaignsWithIds(Set<String> ids) {
        return (campaign)-> ids.contains(campaign.getId());
    }

    public static Predicate<Campaign> campaignWithCategory(Set<Category> categories) {
        Set<String> categoryIds = categories.stream()
                .map(Category::getId)
                .collect(Collectors.toSet());

        return (campaign)-> categoryIds.isEmpty() || categoryIds.contains(campaign.getCategoryId());
    }

    public static Predicate<Campaign> campaignNameContains(String name) {
        String term = name.toLowerCase(Locale.ENGLISH).trim();
        return (campaign)-> term.isEmpty() || campaign.getName().toLowerCase(Locale.ENGLISH).trim().contains(term);
    }

    public static Predicate<Campaign> urgentCampaign() {
        return (campaign)-> campaign.getRaisedAmount() < (campaign.getGoalAmount() / 2);
    }

    public static Predicate<Campaign> comingToAnEndCampaign() {
        ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
        return (campaign)-> campaign.getEndTime().isAfter(now) && campaign.getDaysLeftToDonate() < 16;
    }

    public static Predicate<Campaign> campaignOfAssociation(String associationId) {
        return (campaign)-> campaign.getAssociationId().equals(associationId);
    }

    public static Predicate<FullDonationInfo> donationToAssociation(String associationId) {
        return (info)-> info.getCampaign().getAssociationId().equals(associationId);
    }

    public static Predicate<Donation> donationByUser(String userId) {
        return (donation)-> userId.equals(donation.getUserId());
    }

    public static Predicate<FullDonationInfo> onDate(LocalDate date) {
        return (info)-> {
            LocalDate actualDate = info.getDonation().getDate().toLocalDate();
            return date.isEqual(actualDate);
        };
    }
}
