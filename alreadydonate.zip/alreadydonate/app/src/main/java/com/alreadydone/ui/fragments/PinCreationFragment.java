package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.alreadydone.R;

import java.util.Arrays;
import java.util.List;

public class PinCreationFragment extends Fragment {

    private View continueBtn;
    private EditText input;
    private List<View> digits;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_pin_selection, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        InputMethodManager inputMethodManager = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);

        continueBtn = view.findViewById(R.id.continueBtn);

        input = view.findViewById(R.id.input);
        digits = Arrays.asList(
                view.findViewById(R.id.digit_1),
                view.findViewById(R.id.digit_2),
                view.findViewById(R.id.digit_3),
                view.findViewById(R.id.digit_4),
                view.findViewById(R.id.digit_5),
                view.findViewById(R.id.digit_6)
        );

        input.setOnFocusChangeListener((v, hasFocus)-> {
            if (hasFocus) {
                inputMethodManager.showSoftInput(input, InputMethodManager.SHOW_FORCED);
            }
        });
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int length = s.length();
                for (int i = 0; i < digits.size(); i++) {
                    View view = digits.get(i);
                    if (i < length) {
                        view.setSelected(true);
                    } else {
                        view.setSelected(false);
                    }
                }

                if (s.length() < digits.size()) {
                    continueBtn.setEnabled(false);
                } else {
                    continueBtn.setEnabled(true);
                }
            }
        });

        continueBtn.setEnabled(true);
        continueBtn.setOnClickListener((v)-> {
            save();
        });

        view.setOnTouchListener((v, event)-> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                input.clearFocus();
                input.requestFocus();
            }

            return v.performClick();
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        if (input.getText().length() < digits.size()) {
            continueBtn.setEnabled(false);
        } else {
            continueBtn.setEnabled(true);
        }

        input.clearFocus();
        input.requestFocus();
    }

    private void save() {
        PinSelectionParent parent = getParent();
        parent.setSelectedPin(input.getText().toString());
        parent.onContinue();
    }

    private PinSelectionParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof PinSelectionParent) {
            return (PinSelectionParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof PinSelectionParent) {
            return (PinSelectionParent) activity;
        }

        throw new IllegalStateException("parent does not support setup");
    }
}
