package com.alreadydone.data.model;

import java.util.List;

public class CampaignWrapper {

    public final Campaign campaign;
    public final Category category;
    public final Association association;
    public final List<Donation> donations;

    public CampaignWrapper(Campaign campaign, Category category, Association association, List<Donation> donations) {
        this.campaign = campaign;
        this.category = category;
        this.association = association;
        this.donations = donations;
    }
}
