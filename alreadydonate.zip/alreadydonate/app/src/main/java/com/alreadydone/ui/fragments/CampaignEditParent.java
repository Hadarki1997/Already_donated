package com.alreadydone.ui.fragments;

import android.net.Uri;

import com.alreadydone.data.model.Category;

import java.time.ZonedDateTime;
import java.util.List;

public interface CampaignEditParent {

    class CampaignInfo {
        public List<Uri> imagesUris;
        public Uri uploadProposalUri;
        public Uri uploadMedicalDocUri;

        public String name;
        public Category category;
        public ZonedDateTime endTime;
        public double goalAmount;
        public String recipient;
        public String usagePlan;
        public String story;
    }

    void saveCampaignInfo(CampaignInfo info);
}
