package com.alreadydone.util.future;

import android.net.Uri;
import android.os.Looper;

import com.alreadydone.util.Result;
import com.alreadydone.util.RunningJob;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public interface Future<T> {

    <R> Future<R> as(Function<T, R> converter);

    default Future<Void> asVoid() {
        return as((v)-> null);
    }

    Future<T> convertError(Function<Throwable, Result<T>> converter);
    <R> Future<R> andThen(Function<T, Future<R>> converter);

    void onComplete(Consumer<Result<T>> consumer);

    static <T> Future<FuturesResult> merge(Collection<Future<T>> futures) {
        MergedFutures mergedFutures = new MergedFutures(Looper.getMainLooper(), new ArrayList<>(futures));
        return create(mergedFutures);
    }

    static <T> Future<FuturesResult> mergeGeneric(Collection<Future<?>> futures) {
        MergedFutures mergedFutures = new MergedFutures(Looper.getMainLooper(), futures);
        return create(mergedFutures);
    }

    static Future<FuturesResult> merge(Future<?>... futures) {
        MergedFutures mergedFutures = new MergedFutures(Looper.getMainLooper(), Arrays.asList(futures));
        return create(mergedFutures);
    }

    static <T> Future<T> immediate(Result<T> result) {
        return new GenericFuture<>(result, (consumer)-> consumer.accept(result));
    }

    static <T> Future<T> create(Task<T> task) {
        return new GenericFuture<>(task, (consumer)-> {
            task.addOnCompleteListener((t)-> {
                Result<T> result;
                if (task.isSuccessful()) {
                    result = Result.value(task.getResult());
                } else {
                    result = Result.error(task.getException());
                }

                consumer.accept(result);
            });
        });
    }

    static Future<Uri> create(UploadTask task) {
        return new GenericFuture<>(task, (consumer)-> {
            task.addOnCompleteListener((t)-> {
                Result<UploadTask.TaskSnapshot> result;
                if (task.isSuccessful()) {
                    result = Result.value(task.getResult());
                } else {
                    result = Result.error(task.getException());
                }

                consumer.accept(result.as(UploadTask.TaskSnapshot::getUploadSessionUri));
            });
        });
    }

    static Future<File> create(FileDownloadTask task, File downloadDest) {
        return new GenericFuture<>(task, (consumer)-> {
            task.addOnCompleteListener((t)-> {
                Result<FileDownloadTask.TaskSnapshot> result;
                if (task.isSuccessful()) {
                    result = Result.value(task.getResult());
                } else {
                    result = Result.error(task.getException());
                }

                consumer.accept(result.as((s)-> downloadDest));
            });
        });
    }

    static <T> Future<T> create(RunningJob<T> job) {
        return new GenericFuture<>(job, job::onComplete);
    }

    static Future<FuturesResult> create(MergedFutures mergedFutures) {
        return new GenericFuture<>(mergedFutures, mergedFutures::addOnComplete);
    }

    static <T> void checkedCall(Supplier<Future<T>> call, Consumer<Result<T>> onComplete) {
        Future<T> future;
        try {
            future = call.get();
        } catch (Throwable t) {
            future = immediate(Result.error(t));
        }

        future.onComplete(onComplete);
    }
}
