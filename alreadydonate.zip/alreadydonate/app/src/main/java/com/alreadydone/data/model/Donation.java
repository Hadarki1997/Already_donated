package com.alreadydone.data.model;

import com.alreadydone.data.meta.annotations.Column;
import com.alreadydone.data.meta.annotations.Ref;

import java.time.ZonedDateTime;
import java.util.Objects;

@Ref(name = "donations")
public class Donation {

    @Column(primaryKey = true)
    private String id;
    @Column
    private String campaignId;
    @Column(optional = true)
    private String userId;
    @Column
    private double amount;
    @Column
    private ZonedDateTime date;

    public Donation() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(String campaignId) {
        this.campaignId = campaignId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public ZonedDateTime getDate() {
        return date;
    }

    public void setDate(ZonedDateTime date) {
        this.date = date;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof Donation)) return false;
        Donation donation = (Donation) object;
        return Objects.equals(id, donation.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Donation{" +
                "id='" + id + '\'' +
                ", campaignId='" + campaignId + '\'' +
                ", userId='" + userId + '\'' +
                ", amount=" + amount +
                ", date=" + date +
                '}';
    }
}
