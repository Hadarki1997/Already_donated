package com.alreadydone.control.objectselection;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;

import androidx.activity.result.ActivityResult;
import androidx.core.content.ContextCompat;

import com.alreadydone.exceptions.CancelledException;
import com.alreadydone.exceptions.PermissionNotGrantedException;
import com.alreadydone.util.Logger;
import com.alreadydone.util.RunningJob;
import com.alreadydone.util.future.Future;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Consumer;

public class ChooserRunner {

    private final Context context;
    private final RunningJob<Uri> job;
    private final RequiredActivityResults activityResults;
    private final String[] requiredPermissions;

    public ChooserRunner(Context context, RunningJob<Uri> job, RequiredActivityResults activityResults, String[] requiredPermissions) {
        this.context = context;
        this.job = job;
        this.activityResults = activityResults;
        this.requiredPermissions = requiredPermissions;
    }

    public void start(Intent intent) {
        if (!hasPermissions(requiredPermissions)) {
            requestPermissions(requiredPermissions, (permissions)-> {
                if (wereAllPermissionsGranted(permissions)) {
                    launchChooser(intent);
                } else {
                    job.markErrored(new PermissionNotGrantedException(permissions));
                }
            });
        } else {
            launchChooser(intent);
        }
    }

    private void launchChooser(Intent intent) {
        launchActivityResultWithIntent(intent, (result)-> {
            Uri uri = result.getData();
            job.markFinished(uri);
        });
    }

    private void launchActivityResultWithIntent(Intent intent, Consumer<Intent> onResult) {
        Future<ActivityResult> future = activityResults.activityResultWithIntent.launch(intent);
        future.onComplete((result)-> {
            if (result.hasValue()) {
                ActivityResult activityResult = result.getValue();
                if (activityResult.getResultCode() == Activity.RESULT_OK) {
                    onResult.accept(activityResult.getData());
                } else {
                    job.markErrored(new CancelledException());
                }
            } else {
                Logger.debug("Encountered error while requesting selection", result.getError());
                job.markErrored(result.getError());
            }
        });
    }

    private boolean hasPermissions(String[] permissions) {
        for (String permission : permissions) {
            int result = ContextCompat.checkSelfPermission(context, permission);
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }

        return true;
    }

    private void requestPermissions(String[] permissions, Consumer<Map<String, Boolean>> onResult) {
        Future<Map<String, Boolean>> future = activityResults.activityResultForPermissions.launch(permissions);
        future.onComplete((result)-> {
            if (result.hasValue()) {
                onResult.accept(result.getValue());
            } else {
                Logger.debug("Encountered error while requesting permissions %s", result.getError(), Arrays.toString(permissions));
                job.markErrored(result.getError());
            }
        });
    }

    private boolean wereAllPermissionsGranted(Map<String, Boolean> permissions) {
        for (Boolean granted : permissions.values()) {
            if (granted == null || !granted) {
                return false;
            }
        }

        return true;
    }
}
