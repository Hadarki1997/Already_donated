package com.alreadydone.ui.fragments;

import android.net.Uri;

public interface AssociationEditParent {
    class EditableAssociationInfo {
        public Uri profilePicture;
        public String name;
        public String description;
    }

    void saveAssociationInfo(EditableAssociationInfo info);
    void cancelAssociationEdit();
}
