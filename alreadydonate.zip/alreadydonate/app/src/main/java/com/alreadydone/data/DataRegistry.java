package com.alreadydone.data;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import androidx.annotation.NonNull;

import com.alreadydone.data.meta.ModelMeta;
import com.alreadydone.data.meta.ModelMetaRegistry;
import com.alreadydone.util.function.PredicateList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.function.Predicate;

public class DataRegistry<T> implements DataSource.Listener<T> {

    private static final int WHAT_ADD = 10;
    private static final int WHAT_UPDATE = 11;
    private static final int WHAT_REMOVE = 12;

    public interface Observer<T> {
        void itemAdded(T t);
        void itemChanged(T t);
        void itemRemoved(T t);
    }

    private final DataSource<T> dataSource;
    private final ModelMeta<T> meta;
    private final ConcurrentMap<String, T> objects;
    private final Collection<ObservedList<T>> observedLists;

    private final Handler handler;

    public DataRegistry(Looper looper, DataSource<T> dataSource, Class<T> cls) {
        this.dataSource = dataSource;
        this.meta = ModelMetaRegistry.getMetaForModel(cls);
        this.objects = new ConcurrentHashMap<>();
        this.observedLists = new ArrayList<>();

        this.handler = new Handler(looper) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                ObjectAndId objectAndId = (ObjectAndId) msg.obj;
                String id = objectAndId.id;
                //noinspection unchecked
                T t = (T) objectAndId.obj;

                synchronized (observedLists) {
                    switch (msg.what) {
                        case WHAT_ADD:
                        case WHAT_UPDATE: {
                            for (ObservedList<T> observedList : observedLists) {
                                if (observedList.shouldInclude(t)) {
                                    observedList.update(id, t);
                                }
                            }
                            break;
                        }
                        case WHAT_REMOVE:{
                            for (ObservedList<T> observedList : observedLists) {
                                observedList.remove(id, t);
                            }
                            break;
                        }
                    }
                }
            }
        };

        dataSource.listen(this);
    }
    
    public List<T> get(Predicate<T> predicate, int limit) {
        List<T> list = new ArrayList<>(limit > 0 ? limit : 10);
        
        for (T t : objects.values()) {
            if (predicate.test(t)) {
                list.add(t);
                
                if (limit > 0) {
                    limit--;

                    if (limit <= 0) {
                        break;
                    }
                }
            }
        }
        
        return list;
    }

    public List<T> get(Predicate<T> predicate) {
        return get(predicate, -1);
    }

    public List<T> get(List<Predicate<T>> predicates, int limit) {
        Predicate<T> all = new PredicateList<>(predicates);
        return get(all, limit);
    }

    public Optional<T> getById(String id) {
        T t = objects.get(id);
        return Optional.ofNullable(t);
    }
    
    public Registration observe(Observer<T> observer, Predicate<T> predicate) {
        ObservedList<T> observedList = new ObservedList<>(observer, predicate);
        synchronized (observedLists) {
            observedLists.add(observedList);

            for (Map.Entry<String, T> entry : objects.entrySet()) {
                String id = entry.getKey();
                T t = entry.getValue();

                if (observedList.shouldInclude(t)) {
                    observedList.update(id, t);
                }
            }
        }

        return ()-> {
            synchronized (observedLists) {
                observedLists.remove(observedList);
            }
        };
    }

    public Registration observe(Observer<T> observer) {
        return observe(observer, (t)->true);
    }

    @Override
    public void onNew(T t) {
        String id = meta.getId(t);
        objects.put(id, t);

        Message message = handler.obtainMessage(WHAT_ADD);
        message.obj = new ObjectAndId(id, t);
        message.sendToTarget();
    }

    @Override
    public void onChanged(T t) {
        String id = meta.getId(t);
        objects.put(id, t);

        Message message = handler.obtainMessage(WHAT_UPDATE);
        message.obj = new ObjectAndId(id, t);
        message.sendToTarget();
    }

    @Override
    public void onRemoved(String id) {
        T t = objects.remove(id);
        if (t == null) {
            return;
        }

        Message message = handler.obtainMessage(WHAT_REMOVE);
        message.obj = new ObjectAndId(id, t);
        message.sendToTarget();
    }

    private static class ObjectAndId {
        public final String id;
        public final Object obj;

        private ObjectAndId(String id, Object obj) {
            this.id = id;
            this.obj = obj;
        }
    }
    
    private static class ObservedList<T> {

        private final Observer<T> observer;
        private final Predicate<T> predicate;

        private final Set<String> ids;

        private ObservedList(Observer<T> observer, Predicate<T> predicate) {
            this.observer = observer;
            this.predicate = predicate;
            this.ids = new HashSet<>();
        }
        
        public boolean shouldInclude(T t) {
            return predicate.test(t);
        }
        
        public void update(String id, T t) {
            if (ids.add(id)) {
                observer.itemAdded(t);
            } else {
                observer.itemChanged(t);
            }
        }

        public void remove(String id, T t) {
            if (ids.remove(id)) {
                observer.itemRemoved(t);
            }
        }
    }
}
