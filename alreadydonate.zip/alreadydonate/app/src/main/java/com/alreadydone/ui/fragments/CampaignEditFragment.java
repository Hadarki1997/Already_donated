package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.alreadydone.R;
import com.alreadydone.control.form.Converter;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.alreadydone.control.objectselection.UploadFile;
import com.alreadydone.control.objectselection.UploadProfilePic;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.User;
import com.alreadydone.exceptions.CancelledException;
import com.alreadydone.util.Logger;
import com.alreadydone.util.function.BasicProperty;
import com.alreadydone.util.future.Future;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.io.File;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CampaignEditFragment extends Fragment {

    private UploadProfilePic uploadPic;
    private UploadFile uploadFile;
    private Form form;
    private String campaignId;

    private View createBtn;

    private TextInputEditText titleField;
    private AutoCompleteTextView categoryField;
    private TextInputLayout categoryFieldLayout;
    private TextInputEditText amountField;
    private TextInputLayout enddateFieldLayout;
    private TextInputEditText enddateField;
    private TextInputEditText usageplanField;
    private TextInputEditText recipientnameField;
    private TextInputEditText uploadproposalField;
    private TextInputEditText uploadmedicalField;
    private TextInputEditText storyField;

    private ImageHolder[] imageHolders;

    private final BasicProperty<Set<String>> categoriesNamesProp = new BasicProperty<>(null);
    private final BasicProperty<Map<String, Category>> categoriesByNameProp = new BasicProperty<>(null);
    private final BasicProperty<Map<String, Category>> categoriesByIdProp = new BasicProperty<>(null);
    private final BasicProperty<Uri> uploadProposalUriProp = new BasicProperty<>(null);
    private final BasicProperty<Uri> uploadMedicalUriProp = new BasicProperty<>(null);

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_edit_campaign, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        campaignId = args.getString("campaignId", null);

        uploadPic = UploadProfilePic.create(this);
        uploadFile = UploadFile.create(this);

        MainRepository mainRepository = MainRepository.getInstance();

        createBtn = view.findViewById(R.id.create_btn);

        imageHolders = new ImageHolder[]{
                new ImageHolder(view.findViewById(R.id.image_main), view.findViewById(R.id.image_main_txt)),
                new ImageHolder(view.findViewById(R.id.image_1), view.findViewById(R.id.image_1_txt)),
                new ImageHolder(view.findViewById(R.id.image_2), view.findViewById(R.id.image_2_txt)),
                new ImageHolder(view.findViewById(R.id.image_3), view.findViewById(R.id.image_3_txt)),
                new ImageHolder(view.findViewById(R.id.image_4), view.findViewById(R.id.image_4_txt)),
        };

        titleField = view.findViewById(R.id.title_field);
        categoryField = view.findViewById(R.id.category_field);
        categoryFieldLayout = view.findViewById(R.id.category_field_layout);
        amountField = view.findViewById(R.id.amount_field);
        enddateFieldLayout = view.findViewById(R.id.enddate_field_layout);
        enddateField = view.findViewById(R.id.enddate_field);
        usageplanField = view.findViewById(R.id.usageplan_field);
        recipientnameField = view.findViewById(R.id.recipientname_field);
        uploadproposalField = view.findViewById(R.id.uploadproposal_field);
        uploadmedicalField = view.findViewById(R.id.uploadmedical_field);
        storyField = view.findViewById(R.id.story_field);
        final CheckBox termsField = view.findViewById(R.id.box_terms_and_services);

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item);
        categoryField.setAdapter(categoryAdapter);

        mainRepository.getAllCategories().onComplete((result)-> {
            if (result.hasValue()) {
                Map<String, Category> categoryByName = result.getValue().stream()
                        .collect(Collectors.toMap(Category::getName, (category)-> category));
                Map<String, Category> categoryById = result.getValue().stream()
                        .collect(Collectors.toMap(Category::getId, (category)-> category));
                Set<String> categoryNames = result.getValue().stream()
                        .map(Category::getName)
                        .collect(Collectors.toSet());

                categoriesByIdProp.set(categoryById);
                categoriesByNameProp.set(categoryByName);
                categoriesNamesProp.set(categoryNames);

                categoryAdapter.clear();
                categoryAdapter.addAll(categoryNames);
            } else {
                Logger.error("Failed loading categories", result.getError());
            }
        });

        long today = MaterialDatePicker.todayInUtcMilliseconds();
        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Expiration Date")
                .setCalendarConstraints(
                        new CalendarConstraints.Builder()
                                .setStart(today)
                                .build()
                )
                .build();
        datePicker.addOnPositiveButtonClickListener((selection)-> {
            ZonedDateTime dateTime = Instant.ofEpochMilli(selection).atZone(ZoneOffset.UTC);
            dateTime = dateTime.withZoneSameInstant(ZoneOffset.systemDefault());
            String dateTimeStr = dateTime.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            enddateField.setText(dateTimeStr);
        });

        enddateFieldLayout.setEndIconOnClickListener((v)-> {
            datePicker.show(getChildFragmentManager(), "tag");
        });

        uploadproposalField.setOnClickListener((v)-> {
            runUploadFile(this::onProposalDocLoaded);
        });
        uploadmedicalField.setOnClickListener((v)-> {
            runUploadFile(this::onMedicalDocLoaded);
        });

        form = new Form.Builder()
                .register("Title", FormInput.create(titleField))
                    .withValidator(Validators.longEnough(5))
                    .build()
                .register("Category", FormInput.create(categoryFieldLayout))
                    .withValidator(Validators.notBlank())
                    .withValidator(Validators.isIn(categoriesNamesProp::get))
                    .build()
                .register("EndDate", FormInput.create(enddateField))
                    .convert(Converter.stringToBaseDate())
                    .withValidator(Validators.afterToday())
                    .build()
                .register("TotalAmount", FormInput.create(amountField))
                    .convert(Converter.stringToDouble())
                    .withValidator(Validators.min(1))
                    .withValidator(Validators.max(10000))
                    .build()
                .register("UsagePlan", FormInput.create(usageplanField))
                    .withValidator(Validators.notBlank())
                    .build()
                .register("Recipient", FormInput.create(recipientnameField))
                    .withValidator(Validators.longEnough(5))
                    .build()
                .register("UploadProposal", FormInput.create(uploadproposalField))
                    .withValidator(Validators.notBlank())
                    .build()
                .register("UploadMedical", FormInput.create(uploadmedicalField))
                    .build()
                .register("Story", FormInput.create(storyField))
                    .withValidator(Validators.notBlank())
                    .build()
                .register("TermsCheck", FormInput.create(termsField))
                    .withValidator(Validators.isTrue())
                    .build()
                .build();
        form.enableAutoValidation();

        createBtn.setOnClickListener((v)-> {
            FormResult result = form.getResult();
            if (!result.areAllValid()) {
                return;
            }

            String name = result.getField("Title", String.class);
            String categoryName = result.getField("Category", String.class);
            LocalDate endDate = result.getField("EndDate", LocalDate.class);
            double totalAmount = result.getField("TotalAmount", Double.class);
            String usagePlan = result.getField("UsagePlan", String.class);
            String recipient = result.getField("Recipient", String.class);
            String story = result.getField("Story", String.class);

            List<Uri> images = Stream.of(imageHolders)
                    .map(ImageHolder::getUri)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
            Uri uploadProposalUri = uploadProposalUriProp.get();
            Uri uploadMedicalUri = uploadMedicalUriProp.get();

            ZonedDateTime endTime = endDate.atStartOfDay(ZoneOffset.UTC);
            Map<String, Category> categories = categoriesByNameProp.get();
            Category category = categories.get(categoryName);

            CampaignEditParent.CampaignInfo info = new CampaignEditParent.CampaignInfo();
            info.name = name;
            info.category = category;
            info.endTime = endTime;
            info.goalAmount = totalAmount;
            info.usagePlan = usagePlan;
            info.story = story;
            info.recipient = recipient;
            info.imagesUris = images;
            info.uploadProposalUri = uploadProposalUri;
            info.uploadMedicalDocUri = uploadMedicalUri;

            getParent().saveCampaignInfo(info);
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        loadData();
    }

    private void loadData() {
        createBtn.setEnabled(true);

        if (campaignId != null) {
            loadDataForExistingCampaign(campaignId);
        }
    }

    private void loadDataForExistingCampaign(String campaignId) {
        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        Future.checkedCall(
                ()-> mainRepository.getBaseCampaign(campaignId),
                (result)-> {
                    if (result.hasValue()) {
                        Campaign campaign = result.getValue();

                        Map<String, Category> categoriesById = this.categoriesByIdProp.get();
                        if (categoriesById != null) {
                            Category category = categoriesById.get(campaign.getCategoryId());
                            if (category != null) {
                                categoryField.setText(category.getName(), false);
                            }
                        }

                        titleField.setText(campaign.getName());
                        enddateField.setText(campaign.getEndTime().format(Converter.BASIC_FORMATTER));
                        amountField.setText(String.format(Locale.ENGLISH, "%d", (int) campaign.getGoalAmount()));
                        usageplanField.setText(campaign.getUsagePlan());
                        recipientnameField.setText(campaign.getRecipient());
                        storyField.setText(campaign.getDescription());
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to load campaign info", error);
                        Toast.makeText(getContext(), "Failed to load campaign info", Toast.LENGTH_LONG).show();
                    }
                }
        );

        Future.checkedCall(
                ()-> storageRepository.getAllCampaignImages(campaignId),
                (result)-> {
                    if (result.hasValue()) {
                        List<Uri> images = result.getValue();
                        for (int i = 0; i < images.size() && i < imageHolders.length; i++) {
                            Uri uri = images.get(i);
                            ImageHolder holder = imageHolders[i];

                            holder.setUri(uri);
                        }
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to load campaign images", error);
                        Toast.makeText(getContext(), "Failed to load campaign images", Toast.LENGTH_LONG).show();
                    }
                }
        );

        Future.checkedCall(
                ()-> storageRepository.downloadCampaignProposalDocument(campaignId, requireContext().getCacheDir()),
                (result)-> {
                    if (result.hasValue()) {
                        File file = result.getValue();
                        onProposalDocLoaded(Uri.fromFile(file));
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to load campaign proposal doc", error);
                        Toast.makeText(getContext(), "Failed to load campaign proposal doc", Toast.LENGTH_LONG).show();
                    }
                }
        );
        Future.checkedCall(
                ()-> storageRepository.downloadCampaignMedicalDocument(campaignId, requireContext().getCacheDir()),
                (result)-> {
                    if (result.hasValue()) {
                        File file = result.getValue();
                        onProposalDocLoaded(Uri.fromFile(file));
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to load campaign medical doc", error);
                        Toast.makeText(getContext(), "Failed to load campaign medical doc", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    private void runUploadFile(Consumer<Uri> consumer) {
        uploadFile.start().onComplete((result)-> { // TODO: FILE TYPES VERIFICATIONS
            if (result.hasValue()) {
                Uri uri = result.getValue();
                consumer.accept(uri);
            } else {
                Throwable error = result.getError();
                Logger.debug("failed to load document", error);

                if (error instanceof CancelledException) {
                    // this is fine
                    return;
                }

                Toast.makeText(requireContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void onProposalDocLoaded(Uri uri) {
        uploadproposalField.setText(uriToFileName(uri));
        uploadProposalUriProp.set(uri);
    }

    private void onMedicalDocLoaded(Uri uri) {
        uploadmedicalField.setText(uriToFileName(uri));
        uploadMedicalUriProp.set(uri);
    }

    private String uriToFileName(Uri uri) {
        return Paths.get(uri.getPath()).getFileName().toString();
    }

    private CampaignEditParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof CampaignEditParent) {
            return (CampaignEditParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof CampaignEditParent) {
            return (CampaignEditParent) activity;
        }

        throw new IllegalStateException("parent does not support saving");
    }

    private class ImageHolder {

        private final View view;
        private final View internalTxt;
        private final BasicProperty<Uri> uri;

        private ImageHolder(View view, View internalTxt) {
            this.view = view;
            this.internalTxt = internalTxt;
            uri = new BasicProperty<>(null);

            view.setOnClickListener((v)-> {
                CampaignEditFragment.this.uploadPic.start().onComplete((result)-> {
                    if (result.hasValue()) {
                        Uri uri = result.getValue();
                        setUri(uri);
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("failed to load image", error);

                        if (error instanceof CancelledException) {
                            // this is fine
                            return;
                        }

                        Toast.makeText(CampaignEditFragment.this.requireContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            });
        }

        public Uri getUri() {
            return uri.get();
        }

        public void setUri(Uri uri) {
            this.uri.set(uri);
            Glide.with(CampaignEditFragment.this)
                    .load(uri)
                    .into(new CustomTarget<Drawable>() {
                        @Override
                        public void onResourceReady(@NonNull Drawable resource, @Nullable Transition<? super Drawable> transition) {
                            view.setBackground(resource);
                            internalTxt.setVisibility(View.INVISIBLE);
                        }

                        @Override
                        public void onLoadCleared(@Nullable Drawable placeholder) {

                        }
                    });
        }
    }
}
