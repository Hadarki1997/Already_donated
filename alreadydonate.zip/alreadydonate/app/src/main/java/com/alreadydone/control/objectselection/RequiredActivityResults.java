package com.alreadydone.control.objectselection;

import android.content.Intent;
import android.os.Looper;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCaller;
import androidx.activity.result.contract.ActivityResultContracts;

import com.alreadydone.control.OpenActivityForResult;

import java.util.Map;

public class RequiredActivityResults {

    public final OpenActivityForResult<Intent, ActivityResult> activityResultWithIntent;
    public final OpenActivityForResult<String[], Map<String, Boolean>> activityResultForPermissions;

    RequiredActivityResults(ActivityResultCaller resultCaller, Looper looper) {
        activityResultWithIntent = new OpenActivityForResult<>(resultCaller,
                looper,
                new ActivityResultContracts.StartActivityForResult());
        activityResultForPermissions = new OpenActivityForResult<>(resultCaller, looper,
                new ActivityResultContracts.RequestMultiplePermissions());
    }
}
