package com.alreadydone.exceptions;

import java.util.Locale;

public class TypeMismatchException extends RuntimeException {

    public TypeMismatchException(Class<?> actual, Class<?> wanted) {
        super(String.format(Locale.ENGLISH, "type mismatch: actual=%s, wanted=%s", actual.getName(), wanted.getName()));
    }
}
