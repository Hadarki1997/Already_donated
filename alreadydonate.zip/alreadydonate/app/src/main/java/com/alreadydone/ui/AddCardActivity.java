package com.alreadydone.ui;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.alreadydone.control.form.Converter;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.data.model.PaymentMethod;
import com.alreadydone.data.model.PaymentMethodType;
import com.alreadydone.databinding.ActivityAddCardBinding;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputEditText;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class AddCardActivity extends AppCompatActivity {

    private ActivityAddCardBinding binding;
    private Form form;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAddCardBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final TextInputEditText nameField = binding.nameField;
        final TextInputEditText cardNumberField = binding.cardnumberField;
        final TextInputEditText expirationField = binding.expirationField;
        final TextInputEditText cvvField = binding.cvvField;
        final View continueBtn = binding.continueBtn;
        final View backArrow = binding.backArrow;

        long today = MaterialDatePicker.todayInUtcMilliseconds();
        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Select Expiration Date")
                .setCalendarConstraints(
                        new CalendarConstraints.Builder()
                                .setStart(today)
                                .build()
                )
                .build();
        datePicker.addOnPositiveButtonClickListener((selection)-> {
            ZonedDateTime dateTime = Instant.ofEpochMilli(selection).atZone(ZoneOffset.UTC);
            dateTime = dateTime.withZoneSameInstant(ZoneOffset.systemDefault());
            String dateTimeStr = dateTime.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            expirationField.setText(dateTimeStr);
        });
        binding.expirationFieldLayout.setEndIconOnClickListener((v)-> {
            datePicker.show(getSupportFragmentManager(), "tag");
        });

        form = new Form.Builder()
                .register("Name", FormInput.create(nameField))
                    .withValidator(Validators.longEnough(3))
                    .build()
                .register("CardNumber", FormInput.create(cardNumberField))
                    .withValidator(Validators.notBlank())
                    .withValidator(Validators.creditCardNumber())
                    .build()
                .register("ExpirationDate", FormInput.create(expirationField))
                    .convert(Converter.stringToBaseDate())
                    .withValidator(Validators.afterToday())
                    .build()
                .register("CVV", FormInput.create(cvvField))
                    .withValidator(Validators.exactLength(3))
                    .build()
                .build();
        form.enableAutoValidation();

        backArrow.setOnClickListener((v)-> {
            finish();
        });

        continueBtn.setOnClickListener((v)-> {
            FormResult formResult = form.getResult();
            if (!formResult.areAllValid()) {
                return;
            }

            LoginRepository loginRepository = LoginRepository.getInstance();
            Optional<LoggedInUser> loggedInUserOptional = loginRepository.getLoggedUser();
            if (!loggedInUserOptional.isPresent()) {
                return;
            }

            String name = formResult.getField("Name", String.class);
            String cardNumber = formResult.getField("CardNumber", String.class);
            LocalDate expirationDate = formResult.getField("ExpirationDate", LocalDate.class);
            String cvv = formResult.getField("CVV", String.class);

            ZonedDateTime expirationTime = expirationDate.atStartOfDay(ZoneOffset.UTC);

            PaymentMethod paymentMethod = new PaymentMethod();
            paymentMethod.setType(PaymentMethodType.CREDIT_CARD);
            paymentMethod.setOwnerName(name);
            paymentMethod.setCardNumber(cardNumber);
            paymentMethod.setExpirationDate(expirationTime);
            paymentMethod.setCvv(cvv);

            MainRepository.getInstance().addPaymentMethod(loggedInUserOptional.get().getUserId(), paymentMethod).onComplete((result)-> {
                finish();
            });
        });
    }
}