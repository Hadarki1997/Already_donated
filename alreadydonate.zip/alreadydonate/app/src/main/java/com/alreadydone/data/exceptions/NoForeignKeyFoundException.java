package com.alreadydone.data.exceptions;

import java.util.Locale;

public class NoForeignKeyFoundException extends DataException {

    public NoForeignKeyFoundException(Class<?> modelCls, Class<?> targetCls) {
        super(String.format(Locale.ENGLISH, "Foreign Key in cls %s targeting %s not found",
                modelCls.getName(), targetCls.getName()));
    }
}
