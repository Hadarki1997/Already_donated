package com.alreadydone.data.places;

import com.google.android.libraries.places.api.model.AutocompletePrediction;

public class BasicPlaceInfo {

    private final String id;
    private final String name;

    public BasicPlaceInfo(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public static BasicPlaceInfo fromPrediction(AutocompletePrediction prediction) {
        return new BasicPlaceInfo(prediction.getPlaceId(), prediction.getPrimaryText(null).toString());
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
