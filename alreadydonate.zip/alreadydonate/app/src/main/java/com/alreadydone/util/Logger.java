package com.alreadydone.util;

import android.util.Log;

import java.util.Locale;

public class Logger {

    private static final String TAG = "AlreadyDoneApp";

    public static void debug(String message, Throwable e, Object... args) {
        Log.d(TAG, formatMessage(message, args), e);
    }

    public static void debug(String message, Object... args) {
        Log.d(TAG, formatMessage(message, args));
    }

    public static void info(String message, Throwable e, Object... args) {
        Log.i(TAG, formatMessage(message, args), e);
    }

    public static void info(String message, Object... args) {
        Log.i(TAG, formatMessage(message, args));
    }

    public static void error(String message, Throwable e, Object... args) {
        Log.e(TAG, formatMessage(message, args), e);
    }

    public static void error(String message, Object... args) {
        Log.e(TAG, formatMessage(message, args));
    }

    private static String formatMessage(String message, Object... args) {
        String caller = getCallerClass();
        message = String.format(Locale.ENGLISH, message, args);
        return caller + ": " + message;
    }

    private static String getCallerClass() {
        // note: changing the logging code will affect this method, as it
        // depends on the specific call stack
        StackTraceElement[] elements = Thread.currentThread().getStackTrace();
        return elements[5].getClassName();
    }
}
