package com.alreadydone.ui.fragments;

import com.alreadydone.control.countries.CountryInfo;
import com.alreadydone.data.model.Category;

import java.util.Set;

public interface AccountSetupParent extends AccountEditParent, PinSelectionParent {

    void setSelectedCountry(CountryInfo countryInfo);
    void setSelectedInterests(Set<Category> interests);

    void onContinue();
}
