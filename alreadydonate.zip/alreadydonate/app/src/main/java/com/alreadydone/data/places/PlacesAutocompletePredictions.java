package com.alreadydone.data.places;

import com.alreadydone.control.countries.CountryInfo;
import com.alreadydone.util.future.Future;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.model.AutocompleteSessionToken;
import com.google.android.libraries.places.api.model.PlaceTypes;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class PlacesAutocompletePredictions {

    private final PlacesClient client;
    private final AutocompleteSessionToken token;

    public PlacesAutocompletePredictions(PlacesClient client) {
        this.client = client;
        token = AutocompleteSessionToken.newInstance();
    }

    public Future<List<BasicPlaceInfo>> findOptionsForCountry(String query) {
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setTypesFilter(Collections.singletonList(PlaceTypes.COUNTRY))
                .setSessionToken(token)
                .setQuery(query)
                .build();

        Task<FindAutocompletePredictionsResponse> task = client.findAutocompletePredictions(request);
        return Future.create(task).as((response)-> {
            return response.getAutocompletePredictions().stream()
                    .map(BasicPlaceInfo::fromPrediction)
                    .collect(Collectors.toList());
        });
    }

    public Future<List<BasicPlaceInfo>> findOptionsForCity(CountryInfo countryInfo, String query) {
        FindAutocompletePredictionsRequest request = FindAutocompletePredictionsRequest.builder()
                .setCountries(Collections.singletonList(countryInfo.alpha2))
                .setTypesFilter(Collections.singletonList(PlaceTypes.CITIES))
                .setSessionToken(token)
                .setQuery(query)
                .build();

        Task<FindAutocompletePredictionsResponse> task = client.findAutocompletePredictions(request);
        return Future.create(task).as((response)-> {
            return response.getAutocompletePredictions().stream()
                    .map(BasicPlaceInfo::fromPrediction)
                    .collect(Collectors.toList());
        });
    }
}
