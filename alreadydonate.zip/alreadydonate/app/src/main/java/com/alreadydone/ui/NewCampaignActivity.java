package com.alreadydone.ui;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.dialogs.SuccessDialog;
import com.alreadydone.control.form.Converter;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.control.objectselection.UploadFile;
import com.alreadydone.control.objectselection.UploadProfilePic;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.data.model.Category;
import com.alreadydone.databinding.ActivityNewCampaignBinding;
import com.alreadydone.exceptions.CancelledException;
import com.alreadydone.ui.fragments.CampaignEditFragment;
import com.alreadydone.ui.fragments.CampaignEditParent;
import com.alreadydone.util.Logger;
import com.alreadydone.util.function.BasicProperty;
import com.alreadydone.util.future.Future;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.nio.file.Paths;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NewCampaignActivity extends AppCompatActivity implements CampaignEditParent {

    private ActivityNewCampaignBinding binding;

    private String associationId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        associationId = intent.getStringExtra("associationId");
        if (associationId == null) {
            Logger.error("Missing association id");
            finish();
        }

        binding = ActivityNewCampaignBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final View backArrow = binding.backArrow;
        final ViewPager2 pager = binding.pager;

        Bundle additionalArgs = new Bundle();
        additionalArgs.putString("campaignId", null);
        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                Arrays.asList(
                        new GenericPagerAdapter.FragmentDef(CampaignEditFragment::new)
                ),
                additionalArgs
        ));
        pager.setCurrentItem(0, false);

        backArrow.setOnClickListener((v)-> {
            finish();
        });
    }

    @Override
    public void saveCampaignInfo(CampaignInfo info) {
        Campaign campaign = new Campaign();
        campaign.setName(info.name);
        campaign.setEndTime(info.endTime);
        campaign.setRaisedAmount(0);
        campaign.setGoalAmount(info.goalAmount);
        campaign.setDescription(info.story);
        campaign.setRecipient(info.recipient);
        campaign.setUsagePlan(info.usagePlan);
        campaign.setCategoryId(info.category.getId());
        campaign.setState(CampaignState.PENDING_APPROVAL);
        campaign.setAssociationId(associationId);

        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();
        mainRepository.addCampaign(campaign).onComplete((addResult)-> {
            if (addResult.hasError()) {
                Logger.error("Failed to create campaign", addResult.getError());
                Toast.makeText(this, "Failed to create campaign", Toast.LENGTH_LONG).show();
            } else {
                List<Future<Void>> futures = new ArrayList<>();
                futures.add(storageRepository.uploadCampaignProposalDocument(campaign.getId(), info.uploadProposalUri).as((r)-> null));
                if (info.uploadMedicalDocUri != null) {
                    futures.add(storageRepository.uploadCampaignMedicalDocument(campaign.getId(), info.uploadMedicalDocUri).as((r)-> null));
                }

                if (!info.imagesUris.isEmpty()) {
                    futures.add(storageRepository.uploadCampaignPics(campaign.getId(), info.imagesUris));
                }

                Future.merge(futures).onComplete((uploadResult)-> {
                    if (uploadResult.hasError()) {
                        Logger.error("Failed to upload campaign files", addResult.getError());
                        Toast.makeText(this, "Failed to upload campaign files", Toast.LENGTH_LONG).show();
                    } else {
                        SuccessDialog dialog = new SuccessDialog(this,
                                new SuccessDialog.Info(
                                        R.string.submit_success,
                                        R.string.submit_success_para,
                                        R.string.ok
                                ));
                        dialog.show();
                        dialog.setOnDismissListener((vv)-> {
                            finish();
                        });
                    }
                });
            }
        });
    }
}
