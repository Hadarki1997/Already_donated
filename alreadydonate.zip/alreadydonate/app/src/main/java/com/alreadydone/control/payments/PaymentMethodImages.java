package com.alreadydone.control.payments;

public class PaymentMethodImages {
}
