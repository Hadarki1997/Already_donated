package com.alreadydone.control.form;

public class BaseFormField<T> implements FormField<T> {

    private final FormInput<T> input;
    private final Validator<T> validator;

    public BaseFormField(FormInput<T> input, Validator<T> validator) {
        this.input = input;
        this.validator = validator;
    }

    @Override
    public ValidatedValue<T> validateAndGetValue() {
        T value = input.getValue();
        ValidationResult validationResult = checkValidate(value);
        return new ValidatedValue<>(value, validationResult);
    }

    @Override
    public void enableAutoValidate(Validator<T> additionalValidator) {
        input.registerForValueChanges((value)-> {
            checkValidate(value, additionalValidator);
        });
    }

    @Override
    public <T2> FormField<T2> as(Converter<T, T2> converter, Validator<T2> validator) {
        return new ConvertedFormField<>(this, converter, validator);
    }

    protected ValidationResult checkValidate(T value, Validator<T> additionalValidator) {
        ValidationResult result = validator.validate(value);
        if (!result.isValid()) {
            input.setError(result.getErrorMsg());
            return result;
        }

        result = additionalValidator.validate(value);
        if (!result.isValid()) {
            input.setError(result.getErrorMsg());
            return result;
        }

        input.setValid();

        return result;
    }

    protected ValidationResult checkValidate(T value) {
        return checkValidate(value, Validators.alwaysValid());
    }
}
