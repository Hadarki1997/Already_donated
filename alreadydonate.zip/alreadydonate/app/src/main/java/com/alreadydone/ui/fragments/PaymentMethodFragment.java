package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.SingleSelectableRecyclerListController;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.data.model.PaymentMethod;
import com.alreadydone.data.model.PaymentMethodType;
import com.alreadydone.ui.ActivitiesHelper;
import com.alreadydone.util.future.Future;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class PaymentMethodFragment extends Fragment {

    private View debitLayout;

    private SingleSelectableRecyclerListController<PaymentMethod> digitalMethodController;
    private SingleSelectableRecyclerListController<PaymentMethod> debitController;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_payment_selection, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final RecyclerView digitalPaymentsView = view.findViewById(R.id.view_digital_methods);
        debitLayout = view.findViewById(R.id.layout_debit);
        final RecyclerView debitView = view.findViewById(R.id.view_debits);
        final View continueBtn = view.findViewById(R.id.continueBtn);
        final View addCardBtn = view.findViewById(R.id.add_card_btn);

        digitalMethodController = RecyclerHelper.loadPaymentMethodsInto(digitalPaymentsView, (paymentMethod)-> {
            debitController.clearSelected();
        });
        debitController = RecyclerHelper.loadPaymentMethodsInto(debitView, (paymentMethod)-> {
            digitalMethodController.clearSelected();
        });

        PaymentMethod paypal = new PaymentMethod();
        paypal.setType(PaymentMethodType.PAYPAL);
        PaymentMethod googlepay = new PaymentMethod();
        googlepay.setType(PaymentMethodType.GOOGLE_PAY);
        digitalMethodController.replace(Arrays.asList(
                paypal, googlepay
        ));

        continueBtn.setOnClickListener((v)-> {
            PaymentMethod paymentMethod = getPaymentMethod();
            if (paymentMethod == null) {
                return;
            }

            DonationSetupParent parent = getParent();
            parent.setPaymentMethod(paymentMethod);
            parent.onContinue();
        });
        addCardBtn.setOnClickListener((v)-> {
            ActivitiesHelper.moveToAddCard(getActivity());
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        if (debitController.isEmpty()) {
            debitLayout.setVisibility(View.GONE);
        } else {
            debitLayout.setVisibility(View.VISIBLE);
        }

        LoginRepository loginRepository = LoginRepository.getInstance();
        Optional<LoggedInUser> loggedInUserOptional = loginRepository.getLoggedUser();
        if (!loggedInUserOptional.isPresent()) {
            return;
        }

        MainRepository mainRepository = MainRepository.getInstance();
        Future.checkedCall(
                ()-> mainRepository.getPaymentMethods(loggedInUserOptional.get().getUserId()),
                (result)-> {
                    if (result.hasValue()) {
                        List<PaymentMethod> paymentMethods = result.getValue();
                        debitController.replace(paymentMethods);

                        if (paymentMethods.isEmpty()) {
                            debitLayout.setVisibility(View.GONE);
                        } else {
                            debitLayout.setVisibility(View.VISIBLE);
                        }
                    }
                }
        );
    }

    private PaymentMethod getPaymentMethod() {
        PaymentMethod paymentMethod = debitController.getSelected();
        if (paymentMethod != null) {
            return paymentMethod;
        }

        paymentMethod = digitalMethodController.getSelected();
        if (paymentMethod != null) {
            return paymentMethod;
        }

        return null;
    }

    private DonationSetupParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof DonationSetupParent) {
            return (DonationSetupParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof DonationSetupParent) {
            return (DonationSetupParent) activity;
        }

        throw new IllegalStateException("parent does not support setup");
    }
}