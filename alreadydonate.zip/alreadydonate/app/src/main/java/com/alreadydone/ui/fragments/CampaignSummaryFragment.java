package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.campaigns.CampaignRowConfig;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.CampaignInfoObserver;
import com.alreadydone.data.Filters;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.RegistrationList;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.Category;
import com.alreadydone.ui.ActivitiesHelper;

import java.util.Arrays;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class CampaignSummaryFragment extends Fragment {

    private RecyclerListController<CampaignAndDonations> urgentListController;
    private Supplier<Set<Category>> urgentListCategories;
    private CampaignInfoObserver urgentObserver;

    private RecyclerListController<CampaignAndDonations> comingToAnEndListController;
    private Supplier<Set<Category>> comingToAnEndListCategories;
    private CampaignInfoObserver comingToAndEndObserver;

    private final RegistrationList registrationList = new RegistrationList();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_campaign_summery, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final View urgentBtn = view.findViewById(R.id.urgent_campaigns_see_all);
        final View comingToAndEndBtn = view.findViewById(R.id.coming_to_an_end_campaigns_see_all);

        urgentBtn.setOnClickListener((v)-> {
            MainFragment parent = getParent();
            if (parent != null) {
                parent.switchViewToUrgentView();
            }
        });
        comingToAndEndBtn.setOnClickListener((v)-> {
            MainFragment parent = getParent();
            if (parent != null) {
                parent.switchViewToComingToAnEndView();
            }
        });

        Consumer<CampaignAndDonations> onCampaignClick = (campaign)-> {
            ActivitiesHelper.moveToCampaign(getActivity(), campaign.getCampaign().getId());
        };

        final RecyclerView urgentCampaignsView = view.findViewById(R.id.view_campaigns_1);
        final RecyclerView urgentCampaignsCategoriesView = view.findViewById(R.id.view_categories_1);
        urgentListController =
                RecyclerHelper.loadCampaignsInto(urgentCampaignsView, CampaignRowConfig.forMain(), onCampaignClick);
        urgentObserver = MainRepository.getInstance().createCampaignObserver(urgentListController,
                Arrays.asList(
                        Filters.campaignWithDaysLeft(),
                        Filters.ongoingCampaign(),
                        Filters.urgentCampaign()));
        registrationList.add(urgentObserver);
        urgentListCategories = RecyclerHelper.loadCategoriesSmallInto(urgentCampaignsCategoriesView, (selected)-> {
            reloadUrgent();
        });

        final RecyclerView comingToAnEndCampaignsView = view.findViewById(R.id.view_campaigns_2);
        final RecyclerView comingToAnEndCampaignsCategoriesView = view.findViewById(R.id.view_categories_2);
        comingToAnEndListController =
                RecyclerHelper.loadCampaignsInto(comingToAnEndCampaignsView, CampaignRowConfig.forMain(), onCampaignClick);
        comingToAndEndObserver = MainRepository.getInstance().createCampaignObserver(comingToAnEndListController,
                Arrays.asList(
                        Filters.campaignWithDaysLeft(),
                        Filters.ongoingCampaign(),
                        Filters.comingToAnEndCampaign()));
        registrationList.add(comingToAndEndObserver);
        comingToAnEndListCategories = RecyclerHelper.loadCategoriesSmallInto(comingToAnEndCampaignsCategoriesView, (selected)-> {
            reloadComingToAnEnd();
        });
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        registrationList.close();
    }

    private void load() {
        reloadUrgent();
        reloadComingToAnEnd();
    }

    private void reloadUrgent() {
        Set<Category> selectedCategories = urgentListCategories.get();
        if (selectedCategories.isEmpty()) {
            urgentObserver.reFilter(Filters.noFilter());
        } else {
            urgentObserver.reFilter(Filters.campaignWithCategory(selectedCategories));
        }
    }

    private void reloadComingToAnEnd() {
        Set<Category> selectedCategories = comingToAnEndListCategories.get();
        if (selectedCategories.isEmpty()) {
            comingToAndEndObserver.reFilter(Filters.noFilter());
        } else {
            comingToAndEndObserver.reFilter(Filters.campaignWithCategory(selectedCategories));
        }
    }

    private MainFragment getParent() {
        Fragment fragment = getParentFragment();
        if (!(fragment instanceof MainFragment)) {
            return null;
        }

        return (MainFragment) fragment;
    }
}
