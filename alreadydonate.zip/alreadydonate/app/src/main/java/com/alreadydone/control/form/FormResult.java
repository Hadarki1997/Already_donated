package com.alreadydone.control.form;

import com.alreadydone.exceptions.TypeMismatchException;

import java.util.Map;
import java.util.NoSuchElementException;

public class FormResult {

    private final Map<String, ValidatedValue<?>> values;

    public FormResult(Map<String, ValidatedValue<?>> values) {
        this.values = values;
    }

    public boolean areAllValid() {
        for (ValidatedValue<?> value : values.values()) {
            if (!value.isValid()) {
                return false;
            }
        }

        return true;
    }

    public <T> T getField(String name, Class<T> cls) {
        ValidatedValue<?> fieldValue = values.get(name);
        if (fieldValue == null) {
            throw new NoSuchElementException(name);
        }

        if (!cls.isInstance(fieldValue.value)) {
            throw new TypeMismatchException(fieldValue.value.getClass(), cls);
        }

        return cls.cast(fieldValue.value);
    }
}
