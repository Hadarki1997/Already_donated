package com.alreadydone.ui.fragments;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.objectselection.UploadProfilePic;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.User;
import com.alreadydone.exceptions.CancelledException;
import com.alreadydone.util.Logger;
import com.alreadydone.util.future.Future;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class ProfileViewFragment extends Fragment {

    private UploadProfilePic uploadProfilePic;

    private ImageView profilePic;
    private View profilePicEdit;
    private TextView userName;
    private TextView aboutTxt;
    private TextInputLayout aboutEditLayout;
    private View aboutEdit;
    private RecyclerListController<Category> interestsController;

    private String userId;
    private boolean inAboutEditMode = false;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile_view, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        userId = args.getString("userId");

        uploadProfilePic = UploadProfilePic.create(this);

        profilePicEdit = view.findViewById(R.id.profile_pic_edit);
        profilePicEdit.setEnabled(false);

        profilePic = view.findViewById(R.id.setting_profile_image);
        userName = view.findViewById(R.id.user_name);
        aboutTxt = view.findViewById(R.id.about);
        aboutEdit = view.findViewById(R.id.about_edit);
        aboutEditLayout = view.findViewById(R.id.about_in_field_layout);
        final TextInputEditText aboutEditTxt = view.findViewById(R.id.about_in_field);

        final RecyclerView interestsView = view.findViewById(R.id.view_interests);
        interestsController = RecyclerHelper.loadCategoriesSmallInto2(interestsView);

        StorageRepository storageRepository = StorageRepository.getInstance();

        profilePicEdit.setOnClickListener((v)-> {
            profilePicEdit.setEnabled(false);

            Future.checkedCall(
                    uploadProfilePic::start,
                    (result)-> {
                        profilePicEdit.setEnabled(true);

                        if (result.hasValue()) {
                            Uri uri = result.getValue();

                            Future.checkedCall(
                                    ()-> storageRepository.uploadProfilePic(userId, uri),
                                    (resultImg)-> {
                                        if (resultImg.hasValue()) {
                                            Glide.with(this)
                                                    .load(result.getValue())
                                                    .into(profilePic);
                                        } else {
                                            Throwable error = result.getError();
                                            Logger.debug("failed to upload image", error);
                                            Toast.makeText(getContext(), "Failed to upload image", Toast.LENGTH_LONG).show();
                                        }
                                    }
                            );
                        } else {
                            Throwable error = result.getError();
                            Logger.debug("failed to load image", error);

                            if (error instanceof CancelledException) {
                                // this is fine
                                return;
                            }

                            Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
            );
        });

        aboutEdit.setOnClickListener((v)-> {
            if (userId == null) {
                inAboutEditMode = false;
                aboutEditLayout.setVisibility(View.GONE);
                aboutTxt.setVisibility(View.VISIBLE);
                return;
            }

            inAboutEditMode = !inAboutEditMode;
            if (inAboutEditMode) {
                aboutEditLayout.setVisibility(View.VISIBLE);
                aboutTxt.setVisibility(View.GONE);
                aboutEditTxt.setText(aboutTxt.getText());
            } else {
                aboutEditLayout.setVisibility(View.GONE);
                aboutTxt.setVisibility(View.VISIBLE);
                String txt = aboutEditTxt.getText().toString();

                aboutEdit.setEnabled(false);
                MainRepository mainRepository = MainRepository.getInstance();
                Future.checkedCall(
                        ()-> mainRepository.updateAboutField(userId, txt),
                        (result)-> {
                            aboutEdit.setEnabled(true);

                            if (result.hasError()) {
                                Logger.error("Failed to save new about", result.getError());
                                Toast.makeText(requireContext(), "Failed to save new about", Toast.LENGTH_SHORT).show();
                            } else {
                                aboutTxt.setText(txt);
                            }
                        }
                );
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        load();
    }

    private void load() {
        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        aboutEditLayout.setVisibility(View.GONE);
        aboutTxt.setVisibility(View.VISIBLE);
        inAboutEditMode = false;
        aboutEdit.setEnabled(false);

        Future.checkedCall(
                ()-> mainRepository.getUserById(userId),
                (result)-> {
                    aboutEdit.setEnabled(true);

                    if (result.hasValue()) {
                        User user = result.getValue();

                        userName.setText(user.getFullName());
                        aboutTxt.setText(user.getAbout() != null ? user.getAbout() : "");
                        interestsController.replace(mainRepository.getCategories(user.getInterests()));
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to profile info", error);
                        Toast.makeText(getContext(), "Failed to profile info", Toast.LENGTH_LONG).show();
                    }
                }
        );

        profilePicEdit.setEnabled(false);

        Future.checkedCall(
                ()-> storageRepository.getProfileImage(userId),
                (result)-> {
                    profilePicEdit.setEnabled(true);

                    if (result.hasValue()) {
                        Glide.with(this)
                                .load(result.getValue())
                                .into(profilePic);
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("failed to load image", error);
                        Toast.makeText(getContext(), "Failed to load profile pic", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }
}
