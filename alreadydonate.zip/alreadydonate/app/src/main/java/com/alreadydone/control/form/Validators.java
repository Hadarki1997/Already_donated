package com.alreadydone.control.form;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.function.Supplier;
import java.util.regex.Pattern;

public class Validators {

    private static final Pattern NUMBER_PATTERN = Pattern.compile("^\\d+$");
    private static final Pattern DATE_PATTERN = Pattern.compile("^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[13-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$");
    private static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("^\\(?([0-9]{3})\\)?([ .-]?)([0-9]{3})\\2([0-9]{4})$");
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$");
    private static final Pattern CREDIT_CARD_PATTERN = Pattern.compile("^(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\\d{3})\\d{11})$");

    private static final Validator<?> ALWAYS_TRUE_VALIDATOR = (value)-> ValidationResult.valid();

    public static <T> Validator<T> alwaysValid() {
        //noinspection unchecked
        return (Validator<T>) ALWAYS_TRUE_VALIDATOR;
    }

    public static Validator<String> notBlank() {
        return (value)-> {
            return !value.trim().isEmpty() ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Must not be blank");
        };
    }

    public static Validator<String> longEnough(int length) {
        return (value)-> {
            return value.trim().length() >= length ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Must be of length " + length);
        };
    }

    public static Validator<String> exactLength(int length) {
        return (value)-> {
            return value.trim().length() == length ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Must be of length " + length);
        };
    }

    public static <T> Validator<T> isIn(Set<T> values) {
        return (value)-> {
            return values.contains(value) ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Must be one of options: " + values);
        };
    }

    @SafeVarargs
    public static <T> Validator<T> isIn(T... values) {
        return isIn(new HashSet<>(Arrays.asList(values)));
    }

    public static <T> Validator<T> isIn(Supplier<Set<T>> supplier) {
        return (value)-> {
            Set<T> values = supplier.get();
            if (values == null) {
                return ValidationResult.valid();
            }

            return values.contains(value) ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Must be one of options: " + values);
        };
    }

    public static Validator<String> isNumber() {
        return (value)-> {
            return NUMBER_PATTERN.matcher(value).matches() ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Not a valid number");
        };
    }

    public static Validator<String> isDate() {
        return (value)-> {
            return DATE_PATTERN.matcher(value).matches() ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Not a valid date");
        };
    }

    public static Validator<Double> min(double min) {
        return (value)-> {
            return value >= min ?
                    ValidationResult.valid() :
                    ValidationResult.notValid(String.format(Locale.ENGLISH, "Value should be %.3f or more", min));
        };
    }

    public static Validator<Double> max(double max) {
        return (value)-> {
            return value <= max ?
                    ValidationResult.valid() :
                    ValidationResult.notValid(String.format(Locale.ENGLISH, "Value should be %.3f or less", max));
        };
    }

    public static Validator<LocalDate> afterToday() {
        LocalDate today = LocalDate.now();
        return (value)-> {
            return value.isAfter(today) ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Value should be after today");
        };
    }

    public static Validator<Boolean> isTrue() {
        return (value)-> {
            return value ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Must be true");
        };
    }

    public static Validator<String> isPhoneNumber() {
        return (value)-> {
            return PHONE_NUMBER_PATTERN.matcher(value).matches() ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Invalid Phone Number");
        };
    }

    public static Validator<String> isEmail() {
        return (value)-> {
            return EMAIL_PATTERN.matcher(value).matches() ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Invalid Email");
        };
    }

    public static Validator<String> creditCardNumber() {
        return (value)-> {
            return CREDIT_CARD_PATTERN.matcher(value).matches() ?
                    ValidationResult.valid() :
                    ValidationResult.notValid("Invalid Card Number");
        };
    }
}
