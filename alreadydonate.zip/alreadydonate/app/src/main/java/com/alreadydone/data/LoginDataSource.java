package com.alreadydone.data;

import com.alreadydone.data.exceptions.NoLoggedInUserException;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.util.future.Future;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Optional;

public class LoginDataSource {

    private final FirebaseAuth mAuth;

    public LoginDataSource() {
        mAuth = FirebaseAuth.getInstance();

    }

    public Future<LoggedInUser> login(String email, String password) {
        Task<AuthResult> task = mAuth.signInWithEmailAndPassword(email, password);
        return Future.create(task).as(this::authResultToUser);
    }

    public Future<LoggedInUser> signup(String email, String password) {
        Task<AuthResult> task = mAuth.createUserWithEmailAndPassword(email, password);
        return Future.create(task).as(this::authResultToUser);
    }

    public Optional<LoggedInUser> getCurrentLogin() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            return Optional.empty();
        }

        LoggedInUser loggedInUser = new LoggedInUser(user.getUid(), user.getEmail());
        return Optional.of(loggedInUser);
    }

    public void logout() {
        mAuth.signOut();
    }

    private LoggedInUser authResultToUser(AuthResult result) {
        FirebaseUser user = result.getUser();
        if (user == null) {
            throw new NoLoggedInUserException();
        }

        return new LoggedInUser(user.getUid(), user.getEmail());
    }
}