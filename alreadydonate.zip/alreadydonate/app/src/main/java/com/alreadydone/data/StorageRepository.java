package com.alreadydone.data;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;

import com.alreadydone.util.Result;
import com.alreadydone.util.future.Future;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class StorageRepository {

    private static StorageRepository instance;

    public static synchronized StorageRepository getInstance() {
        if (instance == null) {
            instance = new StorageRepository();
        }

        return instance;
    }

    private final FirebaseStorage storage;

    public StorageRepository() {
        storage = FirebaseStorage.getInstance();
    }

    public Future<Uri> getCampaignImage(String campaignId) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("images")
                .child(campaignId)
                .child("0");

        Task<Uri> task = reference.getDownloadUrl();
        return Future.create(task);
    }

    public Future<File> downloadCampaignProposalDocument(String campaignId, File outputDir) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("proposals")
                .child(campaignId);

        // TODO: GET EXTENSION AND FILE TYPE
        try {
            outputDir.mkdirs();
            File outputFile = File.createTempFile("proposalDocument", campaignId + ".txt", outputDir);
            FileDownloadTask task = reference.getFile(outputFile);
            return Future.create(task, outputFile);
        } catch (IOException e) {
            return Future.immediate(Result.error(e));
        }
    }

    public Future<File> downloadCampaignMedicalDocument(String campaignId, File outputDir) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("medicalProposals")
                .child(campaignId);

        // TODO: GET EXTENSION AND FILE TYPE
        try {
            outputDir.mkdirs();
            File outputFile = File.createTempFile("medicalDocument", campaignId + ".txt", outputDir);
            FileDownloadTask task = reference.getFile(outputFile);
            return Future.create(task, outputFile);
        } catch (IOException e) {
            return Future.immediate(Result.error(e));
        }
    }

    public Future<List<Uri>> getAllCampaignImages(String campaignId) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("images")
                .child(campaignId);

        return Future.create(reference.listAll()).andThen((result)-> {
            List<Future<Uri>> futures = result.getItems()
                    .stream()
                    .map(StorageReference::getDownloadUrl)
                    .map(Future::create)
                    .collect(Collectors.toList());
            return Future.merge(futures).as((allResult)-> {
                List<Uri> uris = new ArrayList<>(futures.size());
                for (Future<Uri> future : futures) {
                    Result<Uri> uriResult = allResult.getResultFor(future);
                    if (uriResult.hasError()) {
                        throw new RuntimeException(uriResult.getError());
                    }

                    uris.add(uriResult.getValue());
                }

                return uris;
            });
        });
    }

    public Future<Uri> getProfileImage(String userId) {
        StorageReference reference = storage.getReference()
                .child("users")
                .child("profilepics")
                .child(userId);

        Task<Uri> task = reference.getDownloadUrl();
        return Future.create(task);
    }

    public Future<Uri> getAssociationImage(String associationId) {
        StorageReference reference = storage.getReference()
                .child("associations")
                .child("profilepics")
                .child(associationId);

        Task<Uri> task = reference.getDownloadUrl();
        return Future.create(task);
    }

    public Future<Uri> uploadProfilePic(String userId, ImageView view) {
        StorageReference reference = storage.getReference()
                .child("users")
                .child("profilepics")
                .child(userId);

        byte[] data = imageFromImageView(view);
        return upload(reference, data);
    }

    public Future<Uri> uploadProfilePic(String userId, Uri uri) {
        StorageReference reference = storage.getReference()
                .child("users")
                .child("profilepics")
                .child(userId);

        return upload(reference, uri);
    }

    public Future<Uri> uploadAssociationPic(String associationId, Uri uri) {
        StorageReference reference = storage.getReference()
                .child("associations")
                .child("profilepics")
                .child(associationId);

        return upload(reference, uri);
    }

    public Future<Void> uploadCampaignPics(String campaignId, List<Uri> images) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("images")
                .child(campaignId);

        List<Future<Uri>> futures = new ArrayList<>();
        for (int i = 0; i < images.size(); i++) {
            StorageReference subRef = reference.child(String.format(Locale.ENGLISH, "%d", i));
            Uri uri = images.get(i);

            Future<Uri> future = upload(subRef, uri);
            futures.add(future);
        }

        return Future.merge(futures).as((r)-> null);
    }

    public Future<Uri> uploadCampaignProposalDocument(String campaignId, Uri uri) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("proposals")
                .child(campaignId);

        return upload(reference, uri);
    }

    public Future<Uri> uploadCampaignMedicalDocument(String campaignId, Uri uri) {
        StorageReference reference = storage.getReference()
                .child("campaigns")
                .child("medicalProposals")
                .child(campaignId);

        return upload(reference, uri);
    }

    private Future<Uri> upload(StorageReference reference, byte[] data) {
        UploadTask task = reference.putBytes(data);
        return Future.create(task);
    }

    private Future<Uri> upload(StorageReference reference, Uri uri) {
        UploadTask task = reference.putFile(uri);
        return Future.create(task);
    }

    private byte[] imageFromImageView(ImageView view) {
        Drawable drawable = view.getDrawable();
        Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        return baos.toByteArray();
    }
}
