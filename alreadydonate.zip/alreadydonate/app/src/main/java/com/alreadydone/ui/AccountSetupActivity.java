package com.alreadydone.ui;

import android.net.Uri;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.dialogs.SuccessDialog;
import com.alreadydone.control.countries.CountryInfo;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.data.model.User;
import com.alreadydone.data.model.UserType;
import com.alreadydone.databinding.ActivityAccountSetupBinding;
import com.alreadydone.ui.fragments.AccountEditFragment;
import com.alreadydone.ui.fragments.AccountSetupParent;
import com.alreadydone.ui.fragments.CountrySelectionFragment;
import com.alreadydone.ui.fragments.InterestSelectionFragment;
import com.alreadydone.ui.fragments.PinCreationFragment;
import com.alreadydone.util.Logger;
import com.alreadydone.util.Result;
import com.alreadydone.util.future.Future;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class AccountSetupActivity extends AppCompatActivity implements AccountSetupParent {

    private ActivityAccountSetupBinding binding;

    private CountryInfo selectedCountry;
    private EditableUserInfo selectedUserInfo;
    private Set<Category> selectedCategories;
    private String selectedPin;

    private View backArrow;
    private TextView pageTitle;
    private TextView pageDescription;
    private ViewPager2 pager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAccountSetupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        backArrow = binding.backArrow;
        pageTitle = binding.pageTitle;
        pageDescription = binding.pageDescription;
        pager = binding.pager;

        backArrow.setOnClickListener((v)-> {
            selectPreviousView();
        });

        Bundle additionalArgs = new Bundle();
        List<GenericPagerAdapter.FragmentDef> defs = new ArrayList<>();
        for (CurrentView view : CurrentView.values()) {
            defs.add(new GenericPagerAdapter.FragmentDef(
                    view::createFragment,
                    view::fillArgsForFragment
            ));
        }

        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                defs,
                additionalArgs
        ));

        selectView(CurrentView.COUNTRY_SELECT);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    private void selectNextView() {
        int current = pager.getCurrentItem();
        if (current < CurrentView.values().length - 1) {
            selectView(current + 1);
        } else {
            save();
        }
    }

    private void selectPreviousView() {
        int current = pager.getCurrentItem();
        if (current > 0) {
            selectView(current - 1);
        } else {
            finish();
        }
    }

    private void selectView(int index) {
        selectView(CurrentView.values()[index]);
    }

    private void selectView(CurrentView view) {
        pageTitle.setText(view.getPageTitle());

        String description = getString(view.getPageDescription());
        if (description.isEmpty()) {
            pageDescription.setText("");
            pageDescription.setVisibility(View.GONE);
        } else {
            pageDescription.setText(description);
            pageDescription.setVisibility(View.VISIBLE);
        }

        pager.setCurrentItem(view.ordinal(), false);
    }

    private void save() {
        LoginRepository loginRepository = LoginRepository.getInstance();
        Optional<LoggedInUser> loggedInUserOptional = loginRepository.getLoggedUser();
        if (!loggedInUserOptional.isPresent()) {
            // TODO: HANDLE THIS
            return;
        }

        LoggedInUser loggedInUser = loggedInUserOptional.get();

        List<String> interests = selectedCategories.stream()
                .map(Category::getId)
                .collect(Collectors.toList());

        User user = new User();
        user.setId(loggedInUser.getUserId());
        user.setEmail(loggedInUser.getEmail());
        user.setFullName(selectedUserInfo.fullName);
        user.setPhoneNumber(selectedUserInfo.phoneNumber);
        user.setGender(selectedUserInfo.gender);
        user.setCountry(selectedCountry.englishName);
        user.setCity(selectedUserInfo.city);
        user.setInterests(interests);
        user.setAssociationId(null);
        user.setPin(selectedPin);
        user.setType(UserType.NORMAL);

        // TODO: SHOW DIALOG OF WORK IN PROGRESS

        StorageRepository storageRepository = StorageRepository.getInstance();
        MainRepository mainRepository = MainRepository.getInstance();

        Future<Void> futureUser = mainRepository.addUser(user);
        Future<Pair<Result<Void>, Result<Uri>>> finalFuture;
        if (selectedUserInfo.profilePicture != null) {
            Logger.debug("User selected profile image");

            Future<Uri> futureUpload = storageRepository.uploadProfilePic(loggedInUser.getUserId(), selectedUserInfo.profilePicture);
            finalFuture = Future.merge(futureUser, futureUpload).as((result)-> {
                return Pair.create(result.getResultFor(futureUser), result.getResultFor(futureUpload));
            });
        } else {
            finalFuture = Future.merge(futureUser).as((result)-> {
                return Pair.create(result.getResultFor(futureUser), null);
            });
        }

        finalFuture.onComplete((result)-> {
            if (result.hasError()) {
                Logger.debug("unknown failure", result.getError());
                Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
            }

            Result<?> userResult = result.getValue().first;
            Result<?> uploadResult = result.getValue().second;

            boolean allOkay = true;

            if (uploadResult != null && uploadResult.hasError()) {
                allOkay = false;
                Logger.debug("image upload failed", uploadResult.getError());
                Toast.makeText(this, "Failed to upload profile picture", Toast.LENGTH_SHORT).show();
            }

            if (userResult.hasError()) {
                allOkay = false;
                Logger.debug("user creation failed", userResult.getError());
                Toast.makeText(this, "Failed to create user", Toast.LENGTH_LONG).show();
            }

            if (allOkay) {
                SuccessDialog dialog = new SuccessDialog(this,
                        new SuccessDialog.Info(
                                R.string.great,
                                R.string.account_created_para,
                                R.string.go_to_home
                        ));
                dialog.show();
                dialog.setOnDismissListener((v)-> {
                    ActivitiesHelper.moveToMain(AccountSetupActivity.this);
                });
            }
        });
    }

    @Override
    public void setSelectedCountry(CountryInfo countryInfo) {
        selectedCountry = countryInfo;
    }

    @Override
    public void setSelectedInterests(Set<Category> interests) {
        selectedCategories = interests;
    }

    @Override
    public void setSelectedPin(String pin) {
        selectedPin = pin;
    }

    @Override
    public void onContinue() {
        selectNextView();
    }

    @Override
    public Optional<CountryInfo> getSelectedCountry() {
        return Optional.ofNullable(selectedCountry);
    }

    @Override
    public void saveUserInfo(EditableUserInfo userInfo) {
        selectedUserInfo = userInfo;
        onContinue();
    }

    private enum CurrentView {
        COUNTRY_SELECT {
            @Override
            int getPageTitle() {
                return R.string.select_country;
            }

            @Override
            int getPageDescription() {
                return R.string.select_country_para;
            }

            @Override
            Fragment createFragment() {
                return new CountrySelectionFragment();
            }
        },
        ACCOUNT_INFO {
            @Override
            int getPageTitle() {
                return R.string.fill_in_account;
            }

            @Override
            int getPageDescription() {
                return R.string.fill_in_account_para;
            }

            @Override
            Fragment createFragment() {
                return new AccountEditFragment();
            }

            @Override
            void fillArgsForFragment(Bundle args) {
                args.putBoolean("selectCountry", false);
            }
        },
        INTEREST_SELECT {
            @Override
            int getPageTitle() {
                return R.string.select_your_interests;
            }

            @Override
            int getPageDescription() {
                return R.string.choose_interests_para;
            }

            @Override
            Fragment createFragment() {
                return new InterestSelectionFragment();
            }
        },
        PIN_CREATE {
            @Override
            int getPageTitle() {
                return R.string.create_your_pin;
            }

            @Override
            int getPageDescription() {
                return R.string.create_pin_para;
            }

            @Override
            Fragment createFragment() {
                return new PinCreationFragment();
            }
        }
        ;

        abstract int getPageTitle();
        abstract int getPageDescription();

        abstract Fragment createFragment();
        void fillArgsForFragment(Bundle args) {}
    }
}
