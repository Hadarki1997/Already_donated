package com.alreadydone.ui.fragments;

public interface PinSelectionParent {

    void setSelectedPin(String pin);
    void onContinue();
}
