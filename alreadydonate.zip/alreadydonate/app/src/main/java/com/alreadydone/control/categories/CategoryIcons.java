package com.alreadydone.control.categories;

import com.alreadydone.R;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class CategoryIcons {

    public static final Map<String, Integer> CATEGORY_ID_TO_RESOURCE;
    static {
        Map<String, Integer> map = new HashMap<>();
        map.put("education", R.drawable.category_education);
        map.put("environment", R.drawable.category_environment);
        map.put("social", R.drawable.category_social);
        map.put("sick_child", R.drawable.category_sickchild);
        map.put("medical", R.drawable.category_medical);
        map.put("infrastructure", R.drawable.category_infrastructure);
        map.put("art", R.drawable.category_art);
        map.put("disaster", R.drawable.category_disaster);
        map.put("orphanage", R.drawable.category_orphanage);
        map.put("disabled", R.drawable.category_disabled);
        map.put("humanity", R.drawable.category_humanity);
        map.put("other", R.drawable.category_other);

        CATEGORY_ID_TO_RESOURCE = Collections.unmodifiableMap(map);
    }
}
