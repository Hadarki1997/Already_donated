package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.control.recyclerview.ClickableAdapter;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.ui.ActivitiesHelper;

import java.util.ArrayList;
import java.util.List;

public class AdminMainFragment extends Fragment {

    private String userId;

    private View navbar1;
    private View navbar2;
    private TextView navbar2_pageTitle;
    private ViewPager2 pager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        userId = args.getString("userId");

        navbar1 = view.findViewById(R.id.navbar_1);
        navbar2 = view.findViewById(R.id.navbar_2);

        final View navbar2_backBtn = view.findViewById(R.id.back_arrow);
        navbar2_pageTitle = view.findViewById(R.id.page_title);

        pager = view.findViewById(R.id.pager);

        navbar2_backBtn.setOnClickListener((v)-> {
            int currentPage = pager.getCurrentItem();
            if (currentPage == 1) {
                switchView(0);
            } else if (currentPage > 1) {
                switchView(1);
            }
        });

        Bundle additionalArgs = new Bundle();
        additionalArgs.putString("userId", userId);

        List<GenericPagerAdapter.FragmentDef> defs = new ArrayList<>();
        defs.add(new GenericPagerAdapter.FragmentDef(AdminSettingsFragment::new));
        for (SettingEntryType type : SettingEntryType.values()) {
            defs.add(new GenericPagerAdapter.FragmentDef(
                    type::createFragment,
                    type::fillArgsForFragment
            ));
        }

        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                defs,
                additionalArgs
        ));

        switchView(0);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    public void onSettingEntrySelected(SettingEntryType type) {
        switch (type.getKind()) {
            case MENU:
                switchView(type);
                break;
            case ACTION:
                type.execute(this);
                break;
        }
    }

    private void switchView(SettingEntryType type) {
        navbar1.setVisibility(View.GONE);
        navbar2.setVisibility(View.VISIBLE);

        navbar2_pageTitle.setText(type.getName());

        switchView(1 + type.ordinal());
    }

    private void switchView(int index) {
        if (index == 0) {
            navbar1.setVisibility(View.VISIBLE);
            navbar2.setVisibility(View.GONE);

            navbar2_pageTitle.setText("");
        }

        pager.setCurrentItem(index, false);
    }

    public enum SettingEntryKind {
        MENU,
        ACTION
    }

    public enum SettingEntryType {
        REVIEW_CAMPAIGNS {
            @Override
            int getName() {
                return R.string.review_campaigns;
            }

            @Override
            int getIcon() {
                return R.drawable.setting_editprofile;
            }

            @Override
            SettingEntryKind getKind() {
                return SettingEntryKind.MENU;
            }

            @Override
            Fragment createFragment() {
                return new AdminCampaignsReviewFragment();
            }
        },
        LOGOUT {
            @Override
            int getName() {
                return R.string.logout;
            }

            @Override
            int getIcon() {
                return R.drawable.setting_logout;
            }

            @Override
            SettingEntryKind getKind() {
                return SettingEntryKind.ACTION;
            }

            @Override
            void execute(Fragment fragment) {
                LoginRepository repository = LoginRepository.getInstance();
                repository.logout();

                ActivitiesHelper.moveToLogin(fragment.getActivity());
            }
        }
        ;

        abstract int getName();
        abstract int getIcon();
        abstract SettingEntryKind getKind();

        // for menu
        Fragment createFragment() {
            return new EmptyFragment();
        }
        void fillArgsForFragment(Bundle args) {}

        // for action
        void execute(Fragment fragment) {}
    }

    public static class SettingEntryAdapter extends ClickableAdapter<SettingEntryType, SettingEntryAdapter.ViewHolder> {

        public SettingEntryAdapter() {
            super(R.layout.setting_box, ViewHolder::new, (item, holder)-> {
                if (item.getKind() == SettingEntryKind.MENU) {
                    holder.arrowIn.setVisibility(View.VISIBLE);
                } else {
                    holder.arrowIn.setVisibility(View.INVISIBLE);
                }

                holder.image.setImageResource(item.getIcon());
                holder.name.setText(item.getName());
            });
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {

            public final ImageView image;
            public final TextView name;
            public final ImageView arrowIn;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                image = itemView.findViewById(R.id.image);
                name = itemView.findViewById(R.id.name);
                arrowIn = itemView.findViewById(R.id.arrow_in);
            }
        }
    }
}
