package com.alreadydone.exceptions;

public class CancelledException extends Exception {
}
