package com.alreadydone.data.exceptions;

public class AbortedTransactionException extends DataException {
}
