package com.alreadydone.ui.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.campaigns.CampaignRowConfig;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.CampaignInfoObserver;
import com.alreadydone.data.DataRegistry;
import com.alreadydone.data.Filters;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.Registration;
import com.alreadydone.data.RegistrationList;
import com.alreadydone.data.model.Bookmark;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.Category;
import com.alreadydone.ui.ActivitiesHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class CampaignViewFragment extends Fragment {

    private String userId;
    private ViewType viewType;
    private EditText searchTxt;
    private RecyclerListController<CampaignAndDonations> campaignsController;
    private CampaignInfoObserver campaignInfoObserver;
    private Supplier<Set<Category>> selectCategories;
    private BookmarkObserver bookmarkObserver;

    private final RegistrationList registrationList = new RegistrationList();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_campignview, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle arguments = getArguments();
        userId = arguments.getString("userId");
        int viewTypeInt = arguments.getInt("viewType");
        viewType = ViewType.values()[viewTypeInt];

        final RecyclerView categoriesView = view.findViewById(R.id.view_categories);
        final RecyclerView campaignsView = view.findViewById(R.id.view_campaigns);
        searchTxt = view.findViewById(R.id.search_txt);

        campaignsController =
                RecyclerHelper.loadCampaignsInto(campaignsView, CampaignRowConfig.forListView(), (campaign)-> {
                    ActivitiesHelper.moveToCampaign(getActivity(), campaign.getCampaign().getId());
                });
        campaignInfoObserver = MainRepository.getInstance().createCampaignObserver(campaignsController,
                Arrays.asList(Filters.campaignWithDaysLeft(), Filters.ongoingCampaign()));
        registrationList.add(campaignInfoObserver);
        selectCategories = RecyclerHelper.loadCategoriesSmallInto(categoriesView, (categories)-> {
            reloadCampaigns();
        });

        searchTxt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0 && s.length() < before) {
                    reloadCampaigns();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                String txt = s.toString();
                if (txt.length() >= 2) {
                    reloadCampaigns();
                }
            }
        });

        if (viewType == ViewType.BOOKMARKS) {
            bookmarkObserver = new BookmarkObserver();
            Registration registration = MainRepository.getInstance().observeBookmarks(userId, bookmarkObserver);
            registrationList.add(registration);
        } else {
            bookmarkObserver = null;
        }

        reloadCampaigns();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        registrationList.close();
    }

    private void reloadCampaigns() {
        String search = searchTxt.getText().toString();
        Set<Category> categories = selectCategories.get();

        List<Predicate<Campaign>> predicates = viewType.getFilter(userId, search, categories);
        if (viewType == ViewType.BOOKMARKS) {
            predicates = new ArrayList<>(predicates);
            predicates.add(Filters.campaignsWithIds(bookmarkObserver.bookmarks));
        }

        campaignInfoObserver.reFilter(predicates);
    }

    public enum ViewType {
        BOOKMARKS {
            @Override
            int getPageTitle() {
                return R.string.bookmark;
            }

            @Override
            List<Predicate<Campaign>> getFilter(String userId, String filterTxt, Set<Category> categories) {
                return Arrays.asList(
                        Filters.campaignNameContains(filterTxt),
                        Filters.campaignWithCategory(categories)
                );
            }
        },
        URGENT {
            @Override
            int getPageTitle() {
                return R.string.urgent_funding;
            }

            @Override
            List<Predicate<Campaign>> getFilter(String userId, String filterTxt, Set<Category> categories) {
                return Arrays.asList(
                        Filters.urgentCampaign(),
                        Filters.campaignNameContains(filterTxt),
                        Filters.campaignWithCategory(categories)
                );
            }
        },
        COMING_TO_AN_END {
            @Override
            int getPageTitle() {
                return R.string.coming_to_an_end;
            }

            @Override
            List<Predicate<Campaign>> getFilter(String userId, String filterTxt, Set<Category> categories) {
                return Arrays.asList(
                        Filters.comingToAnEndCampaign(),
                        Filters.campaignNameContains(filterTxt),
                        Filters.campaignWithCategory(categories)
                );
            }
        },
        SEARCH {
            @Override
            int getPageTitle() {
                return R.string.search;
            }

            @Override
            List<Predicate<Campaign>> getFilter(String userId, String filterTxt, Set<Category> categories) {
                return Arrays.asList(
                        Filters.campaignNameContains(filterTxt),
                        Filters.campaignWithCategory(categories)
                );
            }
        }
        ;

        abstract int getPageTitle();
        abstract List<Predicate<Campaign>> getFilter(String userId, String filterTxt, Set<Category> categories);
    }

    private class BookmarkObserver implements DataRegistry.Observer<Bookmark> {

        final Set<String> bookmarks;

        private BookmarkObserver() {
            bookmarks = new HashSet<>();
        }

        @Override
        public void itemAdded(Bookmark bookmark) {
            bookmarks.addAll(bookmark.getCampaignIds());
            reloadCampaigns();
        }

        @Override
        public void itemChanged(Bookmark bookmark) {

        }

        @Override
        public void itemRemoved(Bookmark bookmark) {
            bookmarks.removeAll(bookmark.getCampaignIds());
            reloadCampaigns();
        }
    }
}
