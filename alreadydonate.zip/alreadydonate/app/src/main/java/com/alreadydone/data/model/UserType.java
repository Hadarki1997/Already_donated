package com.alreadydone.data.model;

public enum UserType {
    NORMAL,
    ADMIN
}
