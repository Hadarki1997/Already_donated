package com.alreadydone.control.campaigns;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.AdvancedClickableAdapter;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.util.Logger;
import com.bumptech.glide.Glide;

import java.util.Locale;
import java.util.Map;

public class CampaignRowAdapter extends AdvancedClickableAdapter<CampaignAndDonations, CampaignRowAdapter.ViewHolder, CampaignRowConfig.ClickType> {

    public CampaignRowAdapter(CampaignRowConfig config) {
        super(config.layoutType.layoutRes, (view)-> new ViewHolder(view, config.layoutType), (item, holder)-> {
            bindItem(item, holder, config);
        }, (item, holder)-> {
            return configureClicks(item, holder, config);
        });
    }

    private static void bindItem(CampaignAndDonations item, CampaignRowAdapter.ViewHolder holder, CampaignRowConfig config) {
        Campaign campaign = item.getCampaign();

        int width;
        int height;
        if (config.matchParentHorizontal) {
            width = ViewGroup.LayoutParams.MATCH_PARENT;
        } else {
            width = holder.itemView.getContext().getResources().getDimensionPixelSize(config.layoutType.widthSizeRes);
        }
        if (config.matchParentVertical) {
            height = ViewGroup.LayoutParams.MATCH_PARENT;
        } else {
            height = holder.itemView.getContext().getResources().getDimensionPixelSize(config.layoutType.heightSizeRes);
        }

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);

        int margin = holder.itemView.getContext().getResources().getDimensionPixelSize(R.dimen.campaign_box_margin);
        params.setMargins(margin, margin, margin, margin);

        holder.itemView.setLayoutParams(params);

        StorageRepository repository = StorageRepository.getInstance();
        repository.getCampaignImage(campaign.getId()).onComplete((result)-> {
            if (result.hasValue()) {
                Glide.with(holder.image.getContext())
                        .load(result.getValue())
                        .into(holder.image);
            } else {
                Logger.error("Failed to retrieve image for campaign", result.getError());
                holder.image.setImageResource(R.drawable.groups);
            }
        });

        holder.name.setText(campaign.getName());
        holder.donatedMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.getRaisedAmount()));
        holder.requiredMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.getGoalAmount()));
        holder.donors.setText(String.format(Locale.ENGLISH, "%d", item.getDonations().size()));
        holder.daysLeft.setText(String.format(Locale.ENGLISH, "%d", campaign.getDaysLeftToDonate()));
        holder.progressBar.setProgress((int) campaign.getRaisedAmount());
        holder.progressBar.setMax((int) campaign.getGoalAmount());

        if (config.layoutType == CampaignRowConfig.LayoutType.ASSOCIATION) {
            if (campaign.getState() == CampaignState.PENDING_APPROVAL || campaign.getState() == CampaignState.APPROVAL_REJECTED) {
                holder.associationSeeMoreTxt.setText("See Status");
            } else {
                holder.associationSeeMoreTxt.setText("See Results");
            }

            if (campaign.getState() == CampaignState.PENDING_APPROVAL) {
                holder.associationStateTxt.setText("Waiting Approval");
                holder.associationStateTxt.setTextColor(holder.itemView.getContext().getResources().getColor(R.color.main_theme_color));
                holder.associationStateTxt.setVisibility(View.VISIBLE);
            } else if (campaign.getState() == CampaignState.APPROVAL_REJECTED) {
                holder.associationStateTxt.setText("Rejected");
                holder.associationStateTxt.setTextColor(holder.itemView.getContext().getResources().getColor(R.color.rejected));
                holder.associationStateTxt.setVisibility(View.VISIBLE);
            } else {
                holder.associationStateTxt.setText("");
                holder.associationStateTxt.setVisibility(View.GONE);
            }
        }
    }

    private static Map<View, CampaignRowConfig.ClickType> configureClicks(CampaignAndDonations item, CampaignRowAdapter.ViewHolder holder, CampaignRowConfig config) {
        switch (config.layoutType) {
            case NORMAL:
            case SIDE_WAYS:
                return Map.of(holder.itemView, CampaignRowConfig.ClickType.CAMPAIGN);
            case ASSOCIATION:
                return Map.of(
                        holder.itemView, CampaignRowConfig.ClickType.CAMPAIGN,
                        holder.associationEditBtn, CampaignRowConfig.ClickType.EDIT,
                        holder.associationShareBtn, CampaignRowConfig.ClickType.SHARE,
                        holder.associationSeeMoreBtn, CampaignRowConfig.ClickType.SEE_MORE);
            default:
                return Map.of();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final ImageView image;
        public final TextView name;
        public final TextView donatedMoney;
        public final TextView requiredMoney;
        public final TextView donors;
        public final TextView daysLeft;
        public final ProgressBar progressBar;

        public final View associationBaseBox;
        public final View associationEditBtn;
        public final View associationShareBtn;
        public final View associationSeeMoreBtn;
        public final TextView associationSeeMoreTxt;
        public final TextView associationStateTxt;

        public ViewHolder(@NonNull View itemView, CampaignRowConfig.LayoutType layoutType) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            name = itemView.findViewById(R.id.name);
            donatedMoney = itemView.findViewById(R.id.raised_money);
            requiredMoney = itemView.findViewById(R.id.total_money);
            donors = itemView.findViewById(R.id.donors);
            daysLeft = itemView.findViewById(R.id.days_left);
            progressBar = itemView.findViewById(R.id.progress_bar);

            if (layoutType == CampaignRowConfig.LayoutType.ASSOCIATION) {
                associationBaseBox = itemView.findViewById(R.id.base_box);
                associationEditBtn = itemView.findViewById(R.id.edit_btn);
                associationShareBtn = itemView.findViewById(R.id.share_btn);
                associationSeeMoreBtn = itemView.findViewById(R.id.see_more_btn);
                associationSeeMoreTxt = itemView.findViewById(R.id.see_more_txt);
                associationStateTxt = itemView.findViewById(R.id.state);
            } else {
                associationBaseBox = null;
                associationEditBtn = null;
                associationShareBtn = null;
                associationSeeMoreBtn = null;
                associationSeeMoreTxt = null;
                associationStateTxt = null;
            }
        }
    }
}
