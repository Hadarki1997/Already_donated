package com.alreadydone.control.form;

import android.widget.CheckBox;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.function.Consumer;

public interface FormInput<T> {

    T getValue();

    void setValid();
    void setError(String message);

    void registerForValueChanges(Consumer<T> consumer);

    static FormInput<String> create(TextInputEditText field) {
        return new MaterialTextInput(field);
    }

    static FormInput<String> create(TextInputLayout layout) {
        return new MaterialLayoutTextInput(layout);
    }

    static FormInput<Boolean> create(CheckBox checkBox) {
        return new CheckBoxInput(checkBox);
    }
}
