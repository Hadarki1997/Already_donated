package com.alreadydone.util.future;

import android.os.Looper;

import com.alreadydone.util.Result;
import com.alreadydone.util.RunningJob;

import java.util.function.Consumer;
import java.util.function.Function;

public class GenericConvertedFuture<T, T2> implements Future<T2> {

    private final Object bean;
    private final Consumer<Consumer<Result<T>>> onComplete;

    private final Function<T, T2> valueConverter;
    private final Function<Throwable, Result<T2>> errorConverter;

    public GenericConvertedFuture(Object bean,
                                  Consumer<Consumer<Result<T>>> onComplete,
                                  Function<T, T2> valueConverter,
                                  Function<Throwable, Result<T2>> errorConverter) {
        this.bean = bean;
        this.onComplete = onComplete;
        this.valueConverter = valueConverter;
        this.errorConverter = errorConverter;
    }

    @Override
    public <R> Future<R> as(Function<T2, R> converter) {
        return new GenericConvertedFuture<>(
                bean,
                onComplete,
                this.valueConverter.andThen(converter),
                errorConverter == null ? null : (error) -> {
                    Result<T2> r = this.errorConverter.apply(error);
                    return r.as(converter);
                });
    }

    @Override
    public Future<T2> convertError(Function<Throwable, Result<T2>> converter) {
        return new GenericConvertedFuture<T, T2>(
                bean,
                onComplete,
                this.valueConverter,
                errorConverter == null ? converter : (error)-> {
                    Result<T2> r = this.errorConverter.apply(error);
                    if (r != null) {
                        return r;
                    }

                    return converter.apply(error);
                });
    }

    @Override
    public <R> Future<R> andThen(Function<T2, Future<R>> converter) {
        RunningJob<R> job = new RunningJob<>(Looper.getMainLooper());
        onComplete((result)-> {
            if (result.hasError()) {
                job.markErrored(result.getError());
            } else {
                try {
                    Future<R> finalFuture = converter.apply(result.getValue());
                    finalFuture.onComplete(job::markComplete);
                } catch (Throwable t) {
                    job.markErrored(t);
                }
            }
        });

        return Future.create(job);
    }

    @Override
    public void onComplete(Consumer<Result<T2>> consumer) {
        onComplete.accept((result)-> {
            Result<T2> finalResult;

            if (result.hasError() && errorConverter != null) {
                finalResult = errorConverter.apply(result.getError());
            } else {
                finalResult = result.as(valueConverter);

                if (finalResult.hasError() && errorConverter != null) {
                    finalResult = errorConverter.apply(finalResult.getError());
                }
            }

            consumer.accept(finalResult);
        });
    }
}
