package com.alreadydone.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.control.dialogs.CampaignRejectDialog;
import com.alreadydone.control.recyclerview.RecyclerHelper;
import com.alreadydone.control.recyclerview.RecyclerListController;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignState;
import com.alreadydone.data.model.CampaignWrapper;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.databinding.ActivityAdminCampaignBinding;
import com.alreadydone.util.Logger;
import com.alreadydone.util.function.BasicProperty;
import com.alreadydone.util.future.Future;

import java.io.File;
import java.util.Locale;
import java.util.Optional;

public class AdminCampaignActivity extends AppCompatActivity {

    private ActivityAdminCampaignBinding binding;
    private String campaignId = null;
    private Campaign campaign = null;

    private final BasicProperty<File> proposalDocFile = new BasicProperty<>(null);
    private final BasicProperty<File> medicalDocFile = new BasicProperty<>(null);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityAdminCampaignBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        final View approveBtn = binding.approveBtn;
        final View rejectBtn = binding.rejectBtn;
        final View backBtn = binding.back;
        final View proposalDocLayout = binding.proposaldocLayout;
        final View medicalDocLayout = binding.medicaldocLayout;
        final ImageView image = binding.image;
        final RecyclerView imagesView = binding.imagesView;
        final View associationLayout = binding.associationLayout;

        image.setVisibility(View.VISIBLE);
        imagesView.setVisibility(View.GONE);
        proposalDocLayout.setVisibility(View.GONE);
        medicalDocLayout.setVisibility(View.GONE);
        approveBtn.setEnabled(false);

        proposalDocLayout.setOnClickListener((v)-> {
            File file = proposalDocFile.get();
            if (file == null) {
                return;
            }

            Uri uri = FileProvider.getUriForFile(this,
                    getApplicationContext().getPackageName() + ".provider",
                    file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(uri, "text/plain");
            startActivity(intent);
        });
        medicalDocLayout.setOnClickListener((v)-> {
            File file = medicalDocFile.get();
            if (file == null) {
                return;
            }

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(Uri.fromFile(file), "text/plain");
            startActivity(intent);
        });

        approveBtn.setOnClickListener((v)-> {
            Optional<LoggedInUser> user = LoginRepository.getInstance().getLoggedUser();
            if (!user.isPresent()) {
                return;
            }
            if (campaignId == null) {
                return;
            }

            MainRepository mainRepository = MainRepository.getInstance();
            Future.checkedCall(
                    ()-> mainRepository.approveCampaign(campaign),
                    (result)-> {
                        if (result.hasError()) {
                            Logger.error("Failed to approve campaign", result.getError());
                            Toast.makeText(this, "Failed to approve campaign", Toast.LENGTH_SHORT).show();
                        } else {
                            finish();
                        }
                    }
            );
        });
        rejectBtn.setEnabled(true);
        rejectBtn.setClickable(true);
        rejectBtn.setOnClickListener((v)-> {
            CampaignRejectDialog dialog = new CampaignRejectDialog(this);
            dialog.setOnDismissListener((d) -> {
                Optional<String> optional = dialog.getResult();
                if (!optional.isPresent()) {
                    return;
                }

                MainRepository mainRepository = MainRepository.getInstance();
                String description = optional.get();
                Future.checkedCall(
                        ()-> mainRepository.rejectCampaign(campaign, description),
                        (result)-> {
                            if (result.hasError()) {
                                Logger.error("Failed to reject campaign", result.getError());
                                Toast.makeText(this, "Failed to reject campaign", Toast.LENGTH_SHORT).show();
                            } else {
                                finish();
                            }
                        }
                );
            });
            dialog.show();
        });
        backBtn.setOnClickListener((v)-> {
            finish();
        });
        associationLayout.setOnClickListener((v)-> {
            if (campaign != null) {
                ActivitiesHelper.moveToAssociation(this, campaign.getAssociationId());
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        loadCampaignInfo();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        campaignId = null;
        campaign = null;
    }

    private void loadCampaignInfo() {
        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        if (id == null) {
            Logger.error("Expected id in intent, but it is missing");
            finish();
        }

        campaignId = id;
        campaign = null;

        Optional<LoggedInUser> user = LoginRepository.getInstance().getLoggedUser();
        if (!user.isPresent()) {
            ActivitiesHelper.moveToLogin(this);
        }

        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        final ImageView image = binding.image;
        final RecyclerView imagesView = binding.imagesView;
        final TextView state = binding.state;
        final TextView name = binding.name;
        final TextView requiredMoney = binding.totalMoney;
        final TextView daysLeft = binding.daysLeft;
        final TextView category = binding.category;
        final TextView associationName = binding.associationName;
        final TextView recipientName = binding.recipientname;
        final View proposalDocLayout = binding.proposaldocLayout;
        final View medicalDocLayout = binding.medicaldocLayout;
        final TextView fundUsagePlan = binding.fundusageplan;
        final TextView description = binding.description;
        final View approveBtn = binding.approveBtn;
        final View rejectBtn = binding.rejectBtn;

        imagesView.setVisibility(View.GONE);
        proposalDocLayout.setVisibility(View.GONE);
        medicalDocLayout.setVisibility(View.GONE);
        state.setVisibility(View.GONE);
        approveBtn.setEnabled(false);
        rejectBtn.setEnabled(false);

        RecyclerListController<Uri> imagesController = RecyclerHelper.loadImagesInto(imagesView);

        mainRepository.getCampaign(id).onComplete((result)-> {
            if (result.hasError()) {
                Logger.error("Failed to load campaign", result.getError());
                Toast.makeText(this, "Failed to load campaign info", Toast.LENGTH_LONG).show();
                return;
            }

            CampaignWrapper campaign = result.getValue();
            this.campaign = campaign.campaign;

            storageRepository.getAllCampaignImages(campaign.campaign.getId()).onComplete((resultUri)-> {
                if (resultUri.hasValue()) {
                    imagesView.setVisibility(View.VISIBLE);
                    image.setVisibility(View.GONE);
                    imagesController.replace(resultUri.getValue());
                } else {
                    image.setVisibility(View.VISIBLE);
                    imagesView.setVisibility(View.GONE);
                    Logger.error("Failed to retrieve images for campaign", resultUri.getError());
                }
            });

            File docsOutputDir = new File(getCacheDir(), "campaignDocs");
            storageRepository.downloadCampaignProposalDocument(campaign.campaign.getId(), docsOutputDir).onComplete((resultFile)-> {
                if (resultFile.hasValue()) {
                    proposalDocFile.set(resultFile.getValue());
                    proposalDocLayout.setVisibility(View.VISIBLE);
                } else {
                    proposalDocFile.set(null);
                    proposalDocLayout.setVisibility(View.GONE);
                    Logger.error("Failed to retrieve file for campaign", resultFile.getError());
                }
            });
            storageRepository.downloadCampaignMedicalDocument(campaign.campaign.getId(), docsOutputDir).onComplete((resultFile)-> {
                if (resultFile.hasValue()) {
                    medicalDocFile.set(resultFile.getValue());
                    medicalDocLayout.setVisibility(View.VISIBLE);
                } else {
                    medicalDocFile.set(null);
                    medicalDocLayout.setVisibility(View.GONE);
                    Logger.error("Failed to retrieve file for campaign", resultFile.getError());
                }
            });

            category.setText(campaign.category.getName());
            name.setText(campaign.campaign.getName());
            requiredMoney.setText(String.format(Locale.ENGLISH, "$%d", (int) campaign.campaign.getGoalAmount()));
            daysLeft.setText(String.format(Locale.ENGLISH, "%d", campaign.campaign.getDaysLeftToDonate()));
            associationName.setText(campaign.association.getName());
            recipientName.setText(campaign.campaign.getRecipient());
            fundUsagePlan.setText(campaign.campaign.getUsagePlan());
            description.setText(campaign.campaign.getDescription());

            switch (campaign.campaign.getState()) {
                case PENDING_APPROVAL:
                    approveBtn.setEnabled(true);
                    rejectBtn.setEnabled(true);
                    state.setText("Waiting Approval");
                    state.setVisibility(View.VISIBLE);
                    break;
                case APPROVAL_REJECTED:
                    state.setText("Rejected");
                    state.setVisibility(View.VISIBLE);
                    break;
                default:
                    break;
            }

        });
    }
}
