package com.alreadydone.util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class CollectionHelper {

    public static <T, R> Function<List<T>, List<R>> listConverter(Function<T, R> converter) {
        return (list)-> {
            List<R> result = new ArrayList<>();
            for (T t : list) {
                R r = converter.apply(t);
                result.add(r);
            }

            return result;
        };
    }

    public static <T, R> List<R> convert(List<T> list, Function<T, R> converter) {
        return listConverter(converter).apply(list);
    }
}
