package com.alreadydone.control.campaigns;

import com.alreadydone.R;

public class CampaignRowConfig {

    public enum LayoutType {
        NORMAL(R.layout.campaign_box, R.dimen.campaign_box_width_default, -1),
        SIDE_WAYS(R.layout.campaign_box_sideways, -1, R.dimen.campaign_box_height_default),
        ASSOCIATION(R.layout.campaign_box_association, -1, R.dimen.campaign_box_height_expanded)
        ;

        public final int layoutRes;
        public final int widthSizeRes;
        public final int heightSizeRes;

        LayoutType(int layoutRes, int widthSizeRes, int heightSizeRes) {
            this.layoutRes = layoutRes;
            this.widthSizeRes = widthSizeRes;
            this.heightSizeRes = heightSizeRes;
        }
    }

    public enum ClickType {
        CAMPAIGN,
        EDIT,
        SHARE,
        SEE_MORE
    }

    public final LayoutType layoutType;
    public final boolean matchParentVertical;
    public final boolean matchParentHorizontal;

    public CampaignRowConfig(LayoutType layoutType, boolean matchParentVertical, boolean matchParentHorizontal) {
        this.layoutType = layoutType;
        this.matchParentVertical = matchParentVertical;
        this.matchParentHorizontal = matchParentHorizontal;
    }

    public static CampaignRowConfig forMain() {
        return new CampaignRowConfig(LayoutType.NORMAL, true, false);
    }

    public static CampaignRowConfig forListView() {
        return new CampaignRowConfig(LayoutType.SIDE_WAYS, false, true);
    }

    public static CampaignRowConfig forAssociationList() {
        return new CampaignRowConfig(LayoutType.ASSOCIATION, false, true);
    }
}
