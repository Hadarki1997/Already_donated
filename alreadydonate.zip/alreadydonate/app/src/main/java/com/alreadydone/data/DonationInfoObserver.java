package com.alreadydone.data;

import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.Donation;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.data.model.User;
import com.alreadydone.util.function.PredicateList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Predicate;

public class DonationInfoObserver implements Registration {

    private final DataRegistry<Donation> donationRegistry;
    private final DataRegistry<Campaign> campaignRegistry;
    private final DataRegistry<User> userRegistry;

    private final AtomicReference<DataRegistry.Observer<FullDonationInfo>> observerRef;
    private final AtomicReference<Predicate<FullDonationInfo>> filterRef;

    private final Map<String, FullDonationInfo> data;
    private final RegistrationList registrationList;

    public DonationInfoObserver(DataRegistry<Donation> donationRegistry,
                                DataRegistry<Campaign> campaignRegistry,
                                DataRegistry<User> userRegistry,
                                DataRegistry.Observer<FullDonationInfo> observer,
                                Predicate<Donation> baseFilter) {
        this.donationRegistry = donationRegistry;
        this.campaignRegistry = campaignRegistry;
        this.userRegistry = userRegistry;
        this.observerRef = new AtomicReference<>(observer);
        this.filterRef = new AtomicReference<>(Filters.noFilter());
        this.data = new HashMap<>();
        this.registrationList = new RegistrationList();

        Registration registration;
        registration = donationRegistry.observe(new DonationObserver(), baseFilter);
        registrationList.add(registration);
        registration = campaignRegistry.observe(new CampaignObserver());
        registrationList.add(registration);
        registration = userRegistry.observe(new UserObserver());
        registrationList.add(registration);
    }

    public void reFilter(Predicate<FullDonationInfo> newFilter) {
        DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
        if (observer == null) {
            return;
        }

        Predicate<FullDonationInfo> oldFilter = filterRef.getAndSet(newFilter);

        for (Map.Entry<String, FullDonationInfo> entry : data.entrySet()) {
            FullDonationInfo info = entry.getValue();
            boolean inOld = oldFilter.test(info);
            boolean inNew = newFilter.test(info);

            if (inOld && !inNew) {
                observer.itemRemoved(info);
            } else if (!inOld && inNew) {
                observer.itemAdded(info);
            }
        }
    }

    public void reFilter(List<Predicate<FullDonationInfo>> predicates) {
        reFilter(new PredicateList<>(predicates));
    }

    private void donationUpdated(Donation donation) {
        FullDonationInfo info = data.get(donation.getId());
        if (info == null) {
            Optional<Campaign> campaignOptional = campaignRegistry.getById(donation.getCampaignId());
            Optional<User> userOptional = donation.getUserId() != null ?
                    userRegistry.getById(donation.getUserId()) : Optional.empty();

            info = new FullDonationInfo(donation,
                    campaignOptional.orElse(null),
                    userOptional.orElse(null));
            data.put(donation.getId(), info);

            DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
            Predicate<FullDonationInfo> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemAdded(info);
            }
        } else {
            info.setDonation(donation);

            DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
            Predicate<FullDonationInfo> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemChanged(info);
            }
        }
    }

    private void donationRemoved(Donation donation) {
        FullDonationInfo info = data.remove(donation.getId());
        if (info == null) {
            return;
        }

        DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
        Predicate<FullDonationInfo> filter = filterRef.get();
        if (observer != null && (filter == null || filter.test(info))) {
            observer.itemRemoved(info);
        }
    }

    private void campaignUpdated(Campaign campaign) {
        for (FullDonationInfo info : data.values()) {
            if (info.getCampaign() == null || !info.getCampaign().getId().equals(campaign.getId())) {
                continue;
            }

            info.setCampaign(campaign);

            DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
            Predicate<FullDonationInfo> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemChanged(info);
            }
        }
    }

    private void campaignRemoved(Campaign campaign) {
        List<String> toRemove = new ArrayList<>();
        for (FullDonationInfo info : data.values()) {
            if (info.getCampaign() == null || !info.getCampaign().getId().equals(campaign.getId())) {
                continue;
            }

            toRemove.add(info.getDonation().getId());
        }

        removeAll(toRemove);
    }

    private void userUpdated(User user) {
        for (FullDonationInfo info : data.values()) {
            if (info.getUser() == null || !info.getUser().getId().equals(user.getId())) {
                continue;
            }

            info.setUser(user);

            DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
            Predicate<FullDonationInfo> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemChanged(info);
            }
        }
    }

    private void userRemoved(User user) {
        List<String> toRemove = new ArrayList<>();
        for (FullDonationInfo info : data.values()) {
            if (info.getUser() == null || !info.getUser().getId().equals(user.getId())) {
                continue;
            }

            toRemove.add(info.getDonation().getId());
        }

        removeAll(toRemove);
    }

    private void removeAll(Collection<String> ids) {
        for (String id : ids) {
            FullDonationInfo info = data.remove(id);
            if (info == null) {
                continue;
            }

            DataRegistry.Observer<FullDonationInfo> observer = observerRef.get();
            Predicate<FullDonationInfo> filter = filterRef.get();
            if (observer != null && (filter == null || filter.test(info))) {
                observer.itemRemoved(info);
            }
        }
    }

    @Override
    public void close() {
        registrationList.close();
    }

    private class DonationObserver implements DataRegistry.Observer<Donation> {

        @Override
        public void itemAdded(Donation donation) {
            donationUpdated(donation);
        }

        @Override
        public void itemChanged(Donation donation) {
            donationUpdated(donation);
        }

        @Override
        public void itemRemoved(Donation donation) {
            donationRemoved(donation);
        }
    }

    private class CampaignObserver implements DataRegistry.Observer<Campaign> {

        @Override
        public void itemAdded(Campaign campaign) {
            campaignUpdated(campaign);
        }

        @Override
        public void itemChanged(Campaign campaign) {
            campaignUpdated(campaign);
        }

        @Override
        public void itemRemoved(Campaign campaign) {
            campaignRemoved(campaign);
        }
    }

    private class UserObserver implements DataRegistry.Observer<User> {

        @Override
        public void itemAdded(User user) {
            userUpdated(user);
        }

        @Override
        public void itemChanged(User user) {
            userUpdated(user);
        }

        @Override
        public void itemRemoved(User user) {
            userRemoved(user);
        }
    }
}
