package com.alreadydone.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.alreadydone.R;
import com.alreadydone.control.dialogs.SuccessDialog;
import com.alreadydone.control.fragments.GenericPagerAdapter;
import com.alreadydone.data.LoginRepository;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.Donation;
import com.alreadydone.data.model.LoggedInUser;
import com.alreadydone.data.model.PaymentMethod;
import com.alreadydone.data.model.User;
import com.alreadydone.databinding.ActivityDonateBinding;
import com.alreadydone.ui.fragments.DonateAmountFragment;
import com.alreadydone.ui.fragments.DonationSetupParent;
import com.alreadydone.ui.fragments.PaymentMethodFragment;
import com.alreadydone.ui.fragments.PinCreationFragment;
import com.alreadydone.util.Logger;
import com.alreadydone.util.Result;
import com.alreadydone.util.future.Future;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DonateActivity extends AppCompatActivity implements DonationSetupParent {

    private ActivityDonateBinding binding;

    private DonationInfo selectedDonationInfo;
    private PaymentMethod selectedPaymentMethod;
    private String selectedPin;

    private View backArrow;
    private TextView pageTitle;
    private ViewPager2 pager;

    private String campaignId;
    private String associationId;
    private User currentUser;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        boolean forAssociation = intent.getBooleanExtra("toAssociation", false);
        if (id == null) {
            Logger.error("Expected id in intent, but it is missing");
            finish();
        }

        if (forAssociation) {
            campaignId = null;
            associationId = id;
        } else {
            campaignId = id;
            associationId = null;
        }

        binding = ActivityDonateBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        backArrow = binding.backArrow;
        pageTitle = binding.pageTitle;
        pager = binding.pager;

        backArrow.setOnClickListener((v)-> {
            selectPreviousView();
        });

        Bundle additionalArgs = new Bundle();
        List<GenericPagerAdapter.FragmentDef> defs = new ArrayList<>();
        for (CurrentView view : CurrentView.values()) {
            defs.add(new GenericPagerAdapter.FragmentDef(
                    view::createFragment,
                    view::fillArgsForFragment
            ));
        }

        pager.setUserInputEnabled(false);
        pager.setAdapter(new GenericPagerAdapter(
                this,
                defs,
                additionalArgs
        ));

        selectView(CurrentView.DONATE_AMOUNT);
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (currentUser == null) {
            LoginRepository loginRepository = LoginRepository.getInstance();
            MainRepository repository = MainRepository.getInstance();

            Optional<LoggedInUser> loggedInUserOptional = loginRepository.getLoggedUser();
            if (!loggedInUserOptional.isPresent()) {
                finish();
                return;
            }

            LoggedInUser loggedInUser = loggedInUserOptional.get();
            repository.getUserById(loggedInUser.getUserId()).onComplete((result)-> {
                if (result.hasValue()) {
                    currentUser = result.getValue();
                } else {
                    Logger.error("Failed to load user info", result.getError());
                    Toast.makeText(this, "Failed to load user info", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void selectNextView() {
        int current = pager.getCurrentItem();
        if (current < CurrentView.values().length - 1) {
            selectView(current + 1);
        } else {
            save();
        }
    }

    private void selectPreviousView() {
        int current = pager.getCurrentItem();
        if (current > 0) {
            selectView(current - 1);
        } else {
            finish();
        }
    }

    private void selectView(int index) {
        selectView(CurrentView.values()[index]);
    }

    private void selectView(CurrentView view) {
        pageTitle.setText(view.getPageTitle());
        pager.setCurrentItem(view.ordinal(), false);
    }

    private void save() {
        LoginRepository loginRepository = LoginRepository.getInstance();
        Optional<LoggedInUser> loggedInUserOptional = loginRepository.getLoggedUser();
        if (!loggedInUserOptional.isPresent()) {
            finish();
            return;
        }

        LoggedInUser loggedInUser = loggedInUserOptional.get();

        if (currentUser == null || !loggedInUser.getUserId().equals(currentUser.getId())) {
            Logger.error("No user info");
            Toast.makeText(this, "User info bad or unloaded", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!currentUser.getPin().equals(selectedPin)) {
            Logger.error("Wrong pin");
            Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show();
            selectView(CurrentView.PIN_CREATE);

            return;
        }

        Future<Void> future;
        if (campaignId != null) {
            Donation donation = new Donation();
            donation.setCampaignId(campaignId);
            donation.setUserId(selectedDonationInfo.anonymous ? null : loggedInUser.getUserId());
            donation.setAmount(selectedDonationInfo.amount);

            MainRepository repository = MainRepository.getInstance();
            future = repository.addDonation(donation);
        } else {
            // this is stub at the moment
            future = Future.immediate(Result.value(null));
        }

        future.onComplete((result)-> {
            if (result.hasError()) {
                Logger.error("Error making donation", result.getError());
                Toast.makeText(this, "Error while making donation", Toast.LENGTH_LONG).show();
            } else {
                SuccessDialog dialog = new SuccessDialog(this,
                        new SuccessDialog.Info(
                                R.string.successful,
                                R.string.thanks_for_donation,
                                R.string.ok
                        ));
                dialog.show();
                dialog.setOnDismissListener((v)-> {
                    finish();
                });
            }
        });
    }

    @Override
    public void setSelectedDonationInfo(DonationInfo info) {
        selectedDonationInfo = info;
    }

    @Override
    public void setPaymentMethod(PaymentMethod paymentMethod) {
        selectedPaymentMethod = paymentMethod;
    }

    @Override
    public void setSelectedPin(String pin) {
        selectedPin = pin;
    }

    @Override
    public void onContinue() {
        selectNextView();
    }

    private enum CurrentView {
        DONATE_AMOUNT {
            @Override
            int getPageTitle() {
                return R.string.donate;
            }

            @Override
            Fragment createFragment() {
                    return new DonateAmountFragment();
            }
        },
        PAYMENT_METHOD_SELECTION {
            @Override
            int getPageTitle() {
                return R.string.payment;
            }

            @Override
            Fragment createFragment() {
                return new PaymentMethodFragment();
            }
        },
        PIN_CREATE {
            @Override
            int getPageTitle() {
                return R.string.create_your_pin;
            }

            @Override
            Fragment createFragment() {
                return new PinCreationFragment();
            }
        }
        ;

        abstract int getPageTitle();

        abstract Fragment createFragment();
        void fillArgsForFragment(Bundle args) {}
    }
}
