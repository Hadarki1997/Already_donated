package com.alreadydone.data;

import com.alreadydone.util.future.Future;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

public interface DataSource<T> {

    enum AppendFlag {
        NO_DUPLICATES
    }

    interface Listener<T> {
        void onNew(T t);
        void onChanged(T t);
        void onRemoved(String id);
    }

    Future<List<T>> getAll();
    Future<List<T>> getAllByField(String fieldName, String value);

    Future<T> getById(String id);
    Future<List<T>> getAllByIds(Collection<String> ids, List<Predicate<T>> filters);

    default Future<List<T>> getAllByIds(Collection<String> ids) {
        return getAllByIds(ids, Collections.emptyList());
    }

    void listen(Listener<T> listener);

    Future<Void> add(T t);

    Future<Void> addToField(String id, String fieldName, double amount);
    Future<Void> appendToListField(String id, String fieldName, Object value, AppendFlag... flags);
    Future<Void> updateField(String id, String fieldName, Object value);
    Future<Void> update(T t);

    Future<Void> deleteById(String id);
}
