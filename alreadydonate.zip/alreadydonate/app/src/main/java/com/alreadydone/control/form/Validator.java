package com.alreadydone.control.form;

import java.util.Arrays;
import java.util.List;

public interface Validator<T> {

    ValidationResult validate(T t);

    default Validator<T> and(Validator<T> other) {
        return new AndValidator<>(this, other);
    }

    class GroupValidator<T> implements Validator<T> {

        private final List<Validator<T>> validators;

        public GroupValidator(List<Validator<T>> validators) {
            this.validators = validators;
        }

        public GroupValidator(Validator<T>... validators) {
            this(Arrays.asList(validators));
        }

        @Override
        public ValidationResult validate(T t) {
            for (Validator<T> validator : validators) {
                ValidationResult result = validator.validate(t);
                if (!result.isValid()) {
                    return result;
                }
            }

            return ValidationResult.valid();
        }
    }

    class AndValidator<T> implements Validator<T> {

        private final Validator<T> validator1;
        private final Validator<T> validator2;

        public AndValidator(Validator<T> validator1, Validator<T> validator2) {
            this.validator1 = validator1;
            this.validator2 = validator2;
        }

        @Override
        public ValidationResult validate(T t) {
            ValidationResult result = validator1.validate(t);
            if (!result.isValid()) {
                return result;
            }

            return validator2.validate(t);
        }
    }
}
