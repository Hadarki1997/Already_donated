package com.alreadydone.control;

import android.os.Looper;

import androidx.activity.result.ActivityResultCaller;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;

import com.alreadydone.util.RunningJob;
import com.alreadydone.util.future.Future;

import java.util.concurrent.atomic.AtomicReference;

public class OpenActivityForResult<I, O> {

    private final ActivityResultCaller resultCaller;
    private final Looper looper;
    private final AtomicReference<RunningJob<O>> currentJob;
    private final ActivityResultLauncher<I> activityResultLauncher;

    public OpenActivityForResult(ActivityResultCaller resultCaller, Looper looper, ActivityResultContract<I, O> contract) {
        this.resultCaller = resultCaller;
        this.looper = looper;
        this.currentJob = new AtomicReference<>(null);

        activityResultLauncher = resultCaller.registerForActivityResult(
                contract,
                result -> {
                    RunningJob<O> job = currentJob.getAndSet(null);
                    job.markFinished(result);
                });
    }

    public Future<O> launch(I input) {
        if (currentJob.get() != null) {
            throw new IllegalArgumentException("activity result in progress");
        }

        RunningJob<O> job = new RunningJob<>(looper);
        currentJob.set(job);

        activityResultLauncher.launch(input);

        return Future.create(job);
    }
}
