package com.alreadydone.data.model;

import com.alreadydone.data.meta.annotations.Column;
import com.alreadydone.data.meta.annotations.Ref;

import java.util.List;
import java.util.Objects;

@Ref(name = "bookmarks")
public class Bookmark {
    @Column(primaryKey = true)
    private String id;
    @Column
    private List<String> campaignIds;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<String> getCampaignIds() {
        return campaignIds;
    }

    public void setCampaignIds(List<String> campaignIds) {
        this.campaignIds = campaignIds;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof Bookmark)) return false;
        Bookmark bookmark = (Bookmark) object;
        return Objects.equals(id, bookmark.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
