package com.alreadydone.control.objectselection;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.alreadydone.util.future.Future;

public class UploadFile {

    private static final String[] PERMISSIONS = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};

    private final Chooser chooser;

    public UploadFile(Chooser chooser) {
        this.chooser = chooser;
    }

    public static UploadFile create(AppCompatActivity activity) {
        return new UploadFile(Chooser.create(activity));
    }

    public static UploadFile create(Fragment fragment) {
        return new UploadFile(Chooser.create(fragment));
    }

    public Future<Uri> start() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");

        return chooser.start(intent, PERMISSIONS);
    }
}
