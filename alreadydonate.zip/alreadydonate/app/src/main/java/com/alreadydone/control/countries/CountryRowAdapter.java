package com.alreadydone.control.countries;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;

import java.util.List;
import java.util.function.Consumer;

public class CountryRowAdapter extends RecyclerView.Adapter<CountryRowAdapter.ViewHolder> {

    private final List<CountryInfo> countries;
    private final Consumer<CountryInfo> onSelect;

    private ViewHolder selectedView;
    private CountryInfo selectedCountry;

    public CountryRowAdapter(List<CountryInfo> countries, Consumer<CountryInfo> onSelect) {
        this.countries = countries;
        this.onSelect = onSelect;

        selectedView = null;
        selectedCountry = null;
    }

    public CountryInfo getSelectedCountry() {
        return selectedCountry;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View contactView = inflater.inflate(R.layout.country_row, parent, false);
        return new ViewHolder(contactView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CountryInfo countryInfo = countries.get(position);

        // Set item views based on your views and data model
        holder.flagView.setText(countryInfo.flagEmoji);
        holder.countryName.setText(countryInfo.englishName);
        holder.selectedButton.setChecked(false);
        holder.itemView.setClickable(true);
        holder.itemView.setOnClickListener((view)-> {
            select(holder, countryInfo);
        });
    }

    @Override
    public int getItemCount() {
        return countries.size();
    }

    private void select(ViewHolder holder, CountryInfo info) {
        unselect();

        selectedView = holder;
        holder.selectedButton.setChecked(true);
        selectedCountry = info;

        onSelect.accept(info);
    }

    private void unselect() {
        if (selectedView != null) {
            selectedView.selectedButton.setChecked(false);
            selectedView = null;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final TextView flagView;
        public final TextView countryName;
        public final RadioButton selectedButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            flagView = itemView.findViewById(R.id.flagIcon);
            countryName = itemView.findViewById(R.id.countryName);
            selectedButton = itemView.findViewById(R.id.selectedButton);
        }
    }
}
