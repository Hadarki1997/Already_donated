package com.alreadydone.util.future;

import com.alreadydone.util.Result;

import java.util.Collections;
import java.util.Map;
import java.util.NoSuchElementException;

public class FuturesResult {

    private final Map<Future<?>, Result<?>> results;

    FuturesResult(Map<Future<?>, Result<?>> results) {
        this.results = Collections.unmodifiableMap(results);
    }

    public boolean hasResultFor(Future<?> future) {
        return this.results.containsKey(future);
    }

    public <T> Result<T> getResultFor(Future<T> future) {
        //noinspection unchecked
        Result<T> result = (Result<T>) this.results.get(future);
        if (result == null) {
            throw new NoSuchElementException("No result for requested future");
        }

        return result;
    }
}
