package com.alreadydone.data.meta;

import com.alreadydone.data.exceptions.DataException;
import com.alreadydone.data.exceptions.IllegalModelException;
import com.alreadydone.data.meta.annotations.Column;
import com.alreadydone.data.meta.annotations.Ref;
import com.google.firebase.database.DataSnapshot;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ReflectiveModelMeta<T> implements ModelMeta<T> {

    private final Class<T> cls;
    private final Ref ref;
    private final Field idField;

    public ReflectiveModelMeta(Class<T> cls) {
        this.cls = cls;

        Ref ref = getAnnotationOrThrow(Ref.class);
        if (ref.name().isEmpty()) {
            throw new IllegalModelException(cls, "missing ref name in type: " + cls.getName());
        }

        this.ref = ref;
        this.idField = getIdField();
    }

    @Override
    public String getRefName() {
        return ref.name();
    }

    @Override
    public String getId(T t) {
        return readField(t, idField, String.class);
    }

    @Override
    public Map<String, Object> serialize(T t) {
        Map<String, Object> data = new HashMap<>();

        for (Field field : cls.getDeclaredFields()) {
            Column column = field.getAnnotation(Column.class);
            if (column == null) {
                continue;
            }
            if (column.primaryKey()) {
                continue; // primary keys are handled separately
            }

            String name = getFieldName(field);

            Object value = readFieldRaw(t, field);
            if (value == null) {
                if (!column.optional()) {
                    throw new IllegalModelException(cls, String.format(Locale.ENGLISH, "column %s is not optional but value is null", name));
                }
            } else {
                value = serializeValue(value);
                data.put(name, value);
            }
        }

        return data;
    }

    @Override
    public T parse(DataSnapshot dataSnapshot) {
        try {
            Object instance = cls.newInstance();

            String key = dataSnapshot.getKey();
            writeFieldRaw(instance, idField, key);

            for (Field field : cls.getDeclaredFields()) {
                Column column = field.getAnnotation(Column.class);
                if (column == null) {
                    continue;
                }
                if (column.primaryKey()) {
                    continue; // primary keys are handled separately
                }

                String name = getFieldName(field);

                DataSnapshot valueSnapshot = dataSnapshot.child(name);
                if (valueSnapshot.exists()) {
                    Object value = parseValue(valueSnapshot, field.getType());
                    writeFieldRaw(instance, field, value);
                } else {
                    if (!column.optional()) {
                        throw new IllegalModelException(cls, String.format(Locale.ENGLISH, "column %s is not optional but value is null", name));
                    }
                    writeFieldRaw(instance, field, null); // technically not necessary, but let's make it explicit
                }
            }

            return cls.cast(instance);
        } catch (IllegalAccessException | InstantiationException e) {
            throw new DataException(e);
        }
    }

    @Override
    public Object serializeValue(Object value) {
        if (value instanceof Number || value instanceof String || value instanceof List ||
                value instanceof Boolean) {
            return value;
        }

        if (value.getClass().isEnum()) {
            return ((Enum<?>) value).name().toLowerCase(Locale.ENGLISH);
        }

        if (value instanceof ZonedDateTime) {
            return ((ZonedDateTime) value).withZoneSameInstant(ZoneOffset.UTC).toInstant().toEpochMilli();
        }

        throw new DataException("unsupported value type");
    }

    private <A extends Annotation> A getAnnotationOrThrow(Class<A> annotationCls) {
        A annotation = cls.getAnnotation(annotationCls);
        if (annotation == null) {
            throw new IllegalArgumentException("annotation missing: " + annotationCls.getName());
        }

        return annotation;
    }

    private Field getIdField() {
        for (Field field : cls.getDeclaredFields()) {
            Column column = field.getAnnotation(Column.class);
            if (column == null) {
                continue;
            }

            if (column.primaryKey()) {
                if (!String.class.isAssignableFrom(field.getType())) {
                    throw new IllegalModelException(cls, "id field is not string");
                }

                return field;
            }
        }

        throw new IllegalModelException(cls, "no id field for model");
    }

    private <R> R readField(Object instance, Field field, Class<R> valueType) {
        if (!valueType.isAssignableFrom(field.getType())) {
            throw new DataException(String.format(Locale.ENGLISH, "field %s type %s does not match wanted type %s", field.getName(), field.getType().getName(), valueType.getName()));
        }

        Object value = readFieldRaw(instance, field);
        return valueType.cast(value);
    }

    private Object readFieldRaw(Object instance, Field field) {
        try {
            field.setAccessible(true);
            return field.get(instance);
        } catch (IllegalAccessException e) {
            throw new DataException(e);
        }
    }

    private void writeFieldRaw(Object instance, Field field, Object value) {
        try {
            field.setAccessible(true);
            field.set(instance, value);
        } catch (IllegalAccessException e) {
            throw new DataException(e);
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private Object parseValue(DataSnapshot snapshot, Class<?> type) {
        if (type.isAssignableFrom(double.class) || type.isAssignableFrom(int.class) ||
                type.isAssignableFrom(long.class) || type.isAssignableFrom(boolean.class) ||
                type.isAssignableFrom(Number.class) || type.isAssignableFrom(String.class)) {
            return snapshot.getValue(type);
        }

        if (type.isEnum()) {
            String name = snapshot.getValue(String.class);
            if (name == null) {
                return null;
            }

            return Enum.valueOf((Class) type, name.toUpperCase(Locale.ENGLISH));
        }

        if (type.isAssignableFrom(ZonedDateTime.class)) {
            Long epochTime = snapshot.getValue(Long.class);
            if (epochTime == null) {
                return null;
            }

            return Instant.ofEpochMilli(epochTime).atZone(ZoneOffset.UTC);
        }

        if (type.equals(List.class)) {
            Object actualValue = snapshot.getValue();
            if (actualValue instanceof List) {
                return actualValue;
            } else {
                throw new DataException("data is not actually a list, but should be");
            }
        }

        throw new DataException("unsupported value type");
    }

    private String getFieldName(Field field) {
        Column column = field.getAnnotation(Column.class);
        if (column == null || column.name() == null || column.name().isEmpty()) {
            return field.getName();
        }

        return column.name();
    }
}
