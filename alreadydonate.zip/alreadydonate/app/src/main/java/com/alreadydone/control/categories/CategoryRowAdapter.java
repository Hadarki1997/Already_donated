package com.alreadydone.control.categories;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.R;
import com.alreadydone.control.recyclerview.ListSelectableAdapter;
import com.alreadydone.data.model.Category;

public class CategoryRowAdapter extends ListSelectableAdapter<Category, CategoryRowAdapter.ViewHolder> {

    public CategoryRowAdapter() {
        super(R.layout.category_box, ViewHolder::new, (item, holder)-> {
            holder.name.setText(item.getName());

            Integer iconRes = CategoryIcons.CATEGORY_ID_TO_RESOURCE.get(item.getId());
            if (iconRes != null) {
                holder.iconView.setImageResource(iconRes);
            }
        });
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public final CardView layout;
        public final ImageView iconView;
        public final TextView name;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            layout = itemView.findViewById(R.id.layout);
            iconView = itemView.findViewById(R.id.icon);
            name = itemView.findViewById(R.id.name);
        }
    }
}
