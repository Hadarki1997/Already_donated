package com.alreadydone.data.model;

public enum PaymentMethodType {
    PAYPAL,
    GOOGLE_PAY,
    CREDIT_CARD
}
