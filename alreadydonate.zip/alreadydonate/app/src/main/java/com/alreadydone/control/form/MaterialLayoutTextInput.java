package com.alreadydone.control.form;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

import java.util.function.Consumer;

public class MaterialLayoutTextInput implements FormInput<String> {

    private final TextInputLayout layout;
    private final EditText input;

    public MaterialLayoutTextInput(TextInputLayout layout) {
        this.layout = layout;
        this.input = layout.getEditText();
    }

    @Override
    public String getValue() {
        return input.getText().toString();
    }

    @Override
    public void setValid() {
        input.setError(null);
    }

    @Override
    public void setError(String message) {
        input.setError(message);
    }

    @Override
    public void registerForValueChanges(Consumer<String> consumer) {
        input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                consumer.accept(s.toString());
            }
        });
    }
}
