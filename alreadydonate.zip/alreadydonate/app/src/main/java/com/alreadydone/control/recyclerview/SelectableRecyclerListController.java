package com.alreadydone.control.recyclerview;

import java.util.Set;

public class SelectableRecyclerListController<T> extends RecyclerListController<T> {

    private final ListSelectableAdapter<T, ?> adapter;

    public SelectableRecyclerListController(ListSelectableAdapter<T, ?> adapter) {
        super(adapter);
        this.adapter = adapter;
    }

    public Set<T> getSelected() {
        return adapter.getSelected();
    }
}
