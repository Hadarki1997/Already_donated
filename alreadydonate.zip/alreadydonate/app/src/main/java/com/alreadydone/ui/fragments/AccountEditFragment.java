package com.alreadydone.ui.fragments;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.alreadydone.R;
import com.alreadydone.control.countries.CountryInfo;
import com.alreadydone.control.countries.CountryList;
import com.alreadydone.control.form.Form;
import com.alreadydone.control.form.FormInput;
import com.alreadydone.control.form.FormResult;
import com.alreadydone.control.form.Validators;
import com.alreadydone.control.objectselection.UploadProfilePic;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.StorageRepository;
import com.alreadydone.data.model.User;
import com.alreadydone.data.places.BasicPlaceInfo;
import com.alreadydone.data.places.PlacesApi;
import com.alreadydone.data.places.PlacesAutocompletePredictions;
import com.alreadydone.exceptions.CancelledException;
import com.alreadydone.util.Logger;
import com.alreadydone.util.future.Future;
import com.bumptech.glide.Glide;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class AccountEditFragment extends Fragment {

    private final List<String> GENDERS = Arrays.asList("Male", "Female", "Bi Gender", "Gender Fluid", "A-Gender", "Other", "Prefer not to Say");

    private UploadProfilePic uploadProfilePic;
    private PlacesAutocompletePredictions placesAutocompletePredictions;

    private ImageView profilePic;
    private View profilePicEdit;

    private TextInputEditText fullNameTxt;
    private TextInputEditText phoneNumberTxt;
    private AutoCompleteTextView genderSpinner;
    private AutoCompleteTextView countryTxt;
    private AutoCompleteTextView cityTxt;

    private View continueBtn;
    private Form form;

    private String userId;
    private Uri selectedPicUri;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_edit_account, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        userId = args.getString("userId");
        boolean selectCountry = args.getBoolean("selectCountry", true);

        uploadProfilePic = UploadProfilePic.create(this);

        try {
            PlacesApi placesApi = new PlacesApi(requireContext());
            placesAutocompletePredictions = placesApi.createAutocomplete();
        } catch (Throwable t) {
            Logger.error("Failed to initialize places api", t);
            placesAutocompletePredictions = null;
        }

        profilePicEdit = view.findViewById(R.id.profile_pic_edit);
        profilePicEdit.setEnabled(false);

        profilePic = view.findViewById(R.id.setting_profile_image);

        fullNameTxt = view.findViewById(R.id.full_name);
        phoneNumberTxt = view.findViewById(R.id.phone_number);
        genderSpinner = view.findViewById(R.id.gender);
        countryTxt = view.findViewById(R.id.country);
        cityTxt = view.findViewById(R.id.city);

        final View countryView = view.findViewById(R.id.country_view);
        final TextInputLayout genderLayout = view.findViewById(R.id.gender_layout);
        final TextInputLayout countryLayout = view.findViewById(R.id.country_layout);
        final TextInputLayout cityLayout = view.findViewById(R.id.city_layout);
        continueBtn = view.findViewById(R.id.continueBtnFillup);

        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, GENDERS);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        genderSpinner.setAdapter(genderAdapter);

        ArrayAdapter<String> countryAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_dropdown_item_1line);
        countryTxt.setAdapter(countryAdapter);
        if (!selectCountry) {
            countryView.setVisibility(View.GONE);
        }

        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_dropdown_item_1line);
        cityTxt.setAdapter(cityAdapter);

        if (placesAutocompletePredictions != null) {
            countryTxt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    String query = s.toString();
                    if (query.length() < 2) {
                        return;
                    }

                    placesAutocompletePredictions.findOptionsForCountry(query).onComplete((result)-> {
                        if (result.hasValue()) {
                            List<String> countries = result.getValue().stream()
                                    .map(BasicPlaceInfo::getName)
                                    .collect(Collectors.toList());

                            countryAdapter.clear();
                            countryAdapter.addAll(countries);
                        } else {
                            Logger.debug("Failed country autocomplete request", result.getError());
                        }
                    });
                }
            });

            cityTxt.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    String query = s.toString();
                    if (query.length() < 2) {
                        return;
                    }

                    CountryInfo countryInfo;
                    if (selectCountry) {
                        String countryName = countryTxt.getText().toString();
                        countryInfo = CountryList.NAME_TO_INFO.get(countryName);
                    } else {
                        Optional<CountryInfo> optional = getParent().getSelectedCountry();
                        if (!optional.isPresent()) {
                            return;
                        }

                        countryInfo = optional.get();
                    }

                    if (countryInfo == null) {
                        return;
                    }

                    placesAutocompletePredictions.findOptionsForCity(countryInfo, query).onComplete((result)-> {
                        if (result.hasValue()) {
                            List<String> cities = result.getValue().stream()
                                    .map(BasicPlaceInfo::getName)
                                    .collect(Collectors.toList());

                            cityAdapter.clear();
                            cityAdapter.addAll(cities);
                        } else {
                            Logger.debug("Failed city autocomplete request", result.getError());
                        }
                    });
                }
            });
        }

        Form.Builder formBuilder = new Form.Builder()
                .register("FullName", FormInput.create(fullNameTxt))
                        .withValidator(Validators.longEnough(3))
                        .build()
                .register("PhoneNumber", FormInput.create(phoneNumberTxt))
                    .withValidator(Validators.isNumber())
                    .withValidator(Validators.isPhoneNumber())
                    .build()
                .register("Gender", FormInput.create(genderLayout))
                    .withValidator(Validators.notBlank())
                    .withValidator(Validators.isIn(GENDERS.toArray(new String[0])))
                    .build()
                .register("City", FormInput.create(cityLayout))
                    .withValidator(Validators.notBlank())
                    .build();

        if (selectCountry) {
            formBuilder.register("Country", FormInput.create(countryLayout))
                    .withValidator(Validators.notBlank())
                    .build();
        }

        form = formBuilder.build();
        form.enableAutoValidation();

        profilePicEdit.setOnClickListener((v)-> {
            profilePicEdit.setEnabled(false);

            Future.checkedCall(
                uploadProfilePic::start,
                (result)-> {
                    profilePicEdit.setEnabled(true);

                    if (result.hasValue()) {
                        Uri uri = result.getValue();
                        selectedPicUri = uri;
                        Glide.with(this)
                                .load(uri)
                                .into(profilePic);
                    } else {
                        selectedPicUri = null;
                        Throwable error = result.getError();
                        Logger.debug("failed to load image", error);

                        if (error instanceof CancelledException) {
                            // this is fine
                            return;
                        }

                        Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            );
        });

        continueBtn.setOnClickListener((v)-> {
            FormResult result = form.getResult();
            if (!result.areAllValid()) {
                return;
            }

            String fullName = result.getField("FullName", String.class).trim();
            String phoneNumber = result.getField("PhoneNumber", String.class).trim();
            String gender = result.getField("Gender", String.class).trim();
            String city = result.getField("City", String.class).trim();

            String country;
            if (selectCountry) {
                country = result.getField("Country", String.class).trim();
            } else {
                country = null;
            }

            AccountEditParent.EditableUserInfo userInfo = new AccountEditParent.EditableUserInfo();
            userInfo.profilePicture = selectedPicUri;
            userInfo.fullName = fullName;
            userInfo.phoneNumber = phoneNumber;
            userInfo.gender = gender;
            userInfo.country = country;
            userInfo.city = city;

            getParent().saveUserInfo(userInfo);
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        loadData();
    }

    private void loadData() {
        if (userId != null) {
            loadDataForExistingUser(userId);
        } else {
            profilePicEdit.setEnabled(true);
        }

        continueBtn.setEnabled(true);
    }

    private void loadDataForExistingUser(String userId) {
        MainRepository mainRepository = MainRepository.getInstance();
        StorageRepository storageRepository = StorageRepository.getInstance();

        Future.checkedCall(
                ()-> mainRepository.getUserById(userId),
                (result)-> {
                    if (result.hasValue()) {
                        User user = result.getValue();

                        fullNameTxt.setText(user.getFullName());
                        phoneNumberTxt.setText(user.getPhoneNumber());
                        countryTxt.setText(user.getCountry());
                        cityTxt.setText(user.getCity());

                        int index = GENDERS.indexOf(user.getGender());
                        if (index < 0) {
                            index = 0;
                        }
                        genderSpinner.setText(GENDERS.get(index), false);
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("Failed to profile info", error);
                        Toast.makeText(getContext(), "Failed to profile info", Toast.LENGTH_LONG).show();
                    }
                }
        );

        profilePicEdit.setEnabled(false);
        Future.checkedCall(
                ()-> storageRepository.getProfileImage(userId),
                (result)-> {
                    profilePicEdit.setEnabled(true);

                    if (result.hasValue()) {
                        Glide.with(this)
                                .load(result.getValue())
                                .into(profilePic);
                    } else {
                        Throwable error = result.getError();
                        Logger.debug("failed to load image", error);
                        Toast.makeText(getContext(), "Failed to load profile pic", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    private AccountEditParent getParent() {
        Fragment fragment = getParentFragment();
        if (fragment instanceof AccountEditParent) {
            return (AccountEditParent) fragment;
        }

        Activity activity = getActivity();
        if (activity instanceof AccountEditParent) {
            return (AccountEditParent) activity;
        }

        throw new IllegalStateException("parent does not support saving");
    }
}
