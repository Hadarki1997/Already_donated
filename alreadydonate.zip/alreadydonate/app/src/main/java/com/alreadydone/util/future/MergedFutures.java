package com.alreadydone.util.future;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import androidx.annotation.NonNull;

import com.alreadydone.util.Result;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

public class MergedFutures {

    private final Handler handler;
    private final AtomicInteger waitingForFutures;
    private final Map<Future<?>, Result<?>> results;
    private final Queue<Consumer<Result<FuturesResult>>> onComplete;

    public MergedFutures(Looper looper, Collection<Future<?>> futures) {
        this.handler = new Handler(looper) {
            @Override
            public void handleMessage(@NonNull Message msg) {
                FuturesResult result = new FuturesResult(results);
                Result<FuturesResult> resultWrapper = Result.value(result);

                if (msg.obj != null) {
                    //noinspection unchecked
                    Consumer<Result<FuturesResult>> consumer = (Consumer<Result<FuturesResult>>) msg.obj;
                    consumer.accept(resultWrapper);
                } else {
                    for (Consumer<Result<FuturesResult>> consumer : onComplete) {
                        consumer.accept(resultWrapper);
                    }
                }
            }
        };

        this.waitingForFutures = new AtomicInteger(futures.size());
        this.results = new ConcurrentHashMap<>(futures.size());
        this.onComplete = new LinkedList<>();

        for (Future<?> future : futures) {
            future.onComplete((result)-> {
                onNewResult(future, result);
            });
        }
    }

    public synchronized void addOnComplete(Consumer<Result<FuturesResult>> consumer) {
        if (waitingForFutures.get() < 1) {
            Message message = handler.obtainMessage();
            message.obj = consumer;
            message.sendToTarget();
        } else {
            onComplete.add(consumer);
        }
    }

    private synchronized void onNewResult(Future<?> future, Result<?> result) {
        results.put(future, result);

        if (waitingForFutures.decrementAndGet() < 1) {
            Message message = handler.obtainMessage();
            message.sendToTarget();
        }
    }
}
