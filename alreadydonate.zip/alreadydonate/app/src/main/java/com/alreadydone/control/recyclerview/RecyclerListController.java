package com.alreadydone.control.recyclerview;

import com.alreadydone.data.DataRegistry;
import com.alreadydone.util.Logger;
import com.alreadydone.util.future.Future;

import java.util.List;

public class RecyclerListController<T> implements DataRegistry.Observer<T> {

    private final BaseAdapter<T, ?> adapter;
    private final List<T> list;

    public RecyclerListController(BaseAdapter<T, ?> adapter) {
        this.adapter = adapter;
        this.list = adapter.list;
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public void add(T item) {
        int lastSize = list.size();
        list.add(item);
        adapter.notifyItemRangeInserted(lastSize, 1);
    }

    public void update(T item) {
        int index = list.indexOf(item);
        if (index >= 0) {
            list.set(index, item);
            adapter.notifyItemChanged(index);
        }
    }

    public void remove(T item) {
        int index = list.indexOf(item);
        if (index >= 0) {
            list.remove(index);
            adapter.notifyItemRangeRemoved(index, 1);
        }
    }

    public void replace(List<T> newList) {
        int lastSize = list.size();
        list.clear();
        adapter.notifyItemRangeRemoved(0, lastSize);

        list.addAll(newList);
        adapter.notifyItemRangeInserted(0, list.size());
    }

    public void replace(Future<List<T>> future) {
        future.onComplete((result)-> {
            if (result.hasValue()) {
                replace(result.getValue());
            } else {
                Logger.error("Error loading data for list", result.getError());
            }
        });
    }

    @Override
    public void itemAdded(T t) {
        add(t);
    }

    @Override
    public void itemChanged(T t) {
        update(t);
    }

    @Override
    public void itemRemoved(T t) {
        remove(t);
    }
}
