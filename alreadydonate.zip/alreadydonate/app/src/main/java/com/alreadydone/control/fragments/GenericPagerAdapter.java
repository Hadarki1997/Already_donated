package com.alreadydone.control.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class GenericPagerAdapter extends FragmentStateAdapter {

    private final List<FragmentDef> fragmentDefs;
    private final Bundle additionalArgs;

    public GenericPagerAdapter(AppCompatActivity activity,
                               List<FragmentDef> fragmentDefs, Bundle additionalArgs) {
        super(activity.getSupportFragmentManager(), activity.getLifecycle());
        this.fragmentDefs = fragmentDefs;
        this.additionalArgs = additionalArgs;
    }

    public GenericPagerAdapter(Fragment fragment,
                               List<FragmentDef> fragmentDefs, Bundle additionalArgs) {
        super(fragment);
        this.fragmentDefs = fragmentDefs;
        this.additionalArgs = additionalArgs;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position < 0 || position >= fragmentDefs.size()) {
            // should not reach this
            throw new AssertionError();
        }

        FragmentDef def = fragmentDefs.get(position);
        Fragment fragment = def.creator.get();

        Bundle args = new Bundle();
        if (def.argSetter != null) {
            def.argSetter.accept(args);
        }
        args.putAll(additionalArgs);

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public int getItemCount() {
        return fragmentDefs.size();
    }

    public static class FragmentDef {
        public final Supplier<Fragment> creator;
        public final Consumer<Bundle> argSetter;

        public FragmentDef(Supplier<Fragment> creator, Consumer<Bundle> argSetter) {
            this.creator = creator;
            this.argSetter = argSetter;
        }

        public FragmentDef(Supplier<Fragment> creator) {
            this(creator, null);
        }
    }
}
