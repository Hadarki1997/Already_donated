package com.alreadydone.control.recyclerview;

import android.net.Uri;

import androidx.recyclerview.widget.RecyclerView;

import com.alreadydone.control.campaigns.CampaignImageAdapter;
import com.alreadydone.control.campaigns.CampaignRowAdapter;
import com.alreadydone.control.campaigns.CampaignRowConfig;
import com.alreadydone.control.campaigns.CampaignTypeRowSmallAdapter;
import com.alreadydone.control.campaigns.DonationFullRowAdapter;
import com.alreadydone.control.campaigns.DonationRowAdapter;
import com.alreadydone.control.campaigns.InAdminCampaignRowAdapter;
import com.alreadydone.control.categories.CategoryRowAdapter;
import com.alreadydone.control.categories.CategoryRowSmallAdapter;
import com.alreadydone.control.categories.SelectableCategoryRowSmallAdapter;
import com.alreadydone.control.payments.PaymentMethodRowAdapter;
import com.alreadydone.data.MainRepository;
import com.alreadydone.data.model.Campaign;
import com.alreadydone.data.model.CampaignAndDonations;
import com.alreadydone.data.model.Category;
import com.alreadydone.data.model.FullDonationInfo;
import com.alreadydone.data.model.FundraisingTypeData;
import com.alreadydone.data.model.PaymentMethod;
import com.alreadydone.util.Logger;

import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class RecyclerHelper {

    public static RecyclerListController<CampaignAndDonations> loadCampaignsInto(
            RecyclerView recyclerView,
            CampaignRowConfig config,
            Consumer<CampaignAndDonations> onClick) {
        CampaignRowAdapter adapter = new CampaignRowAdapter(config);
        adapter.setOnClick((campaign, type)-> {
            if (type == CampaignRowConfig.ClickType.CAMPAIGN) {
                onClick.accept(campaign);
            }
        });
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static RecyclerListController<CampaignAndDonations> loadCampaignsInto(
            RecyclerView recyclerView,
            CampaignRowConfig config,
            BiConsumer<CampaignAndDonations, CampaignRowConfig.ClickType> onClick) {
        CampaignRowAdapter adapter = new CampaignRowAdapter(config);
        adapter.setOnClick(onClick);
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static RecyclerListController<Campaign> loadAdminCampaignsInto(
            RecyclerView recyclerView,
            BiConsumer<Campaign, InAdminCampaignRowAdapter.ClickType> onClick) {
        InAdminCampaignRowAdapter adapter = new InAdminCampaignRowAdapter();
        adapter.setOnClick(onClick);
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static RecyclerListController<Uri> loadImagesInto(
            RecyclerView recyclerView) {
        CampaignImageAdapter adapter = new CampaignImageAdapter();
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static SelectableRecyclerListController<Category> loadCategoriesInto(RecyclerView recyclerView) {
        CategoryRowAdapter adapter = new CategoryRowAdapter();
        adapter.setOnSelect((selected)-> {
            Logger.debug("Categories Selected %s", selected.toString());
        });
        recyclerView.setAdapter(adapter);

        MainRepository mainRepository = MainRepository.getInstance();
        SelectableRecyclerListController<Category> controller = new SelectableRecyclerListController<>(adapter);
        controller.replace(mainRepository.getAllCategories());

        return controller;
    }

    public static Supplier<Set<Category>> loadCategoriesSmallInto(RecyclerView recyclerView, Consumer<Set<Category>> onSelect) {
        SelectableCategoryRowSmallAdapter adapter = new SelectableCategoryRowSmallAdapter();
        adapter.setOnSelect(onSelect);
        recyclerView.setAdapter(adapter);

        MainRepository mainRepository = MainRepository.getInstance();
        SelectableRecyclerListController<Category> controller = new SelectableRecyclerListController<>(adapter);
        controller.replace(mainRepository.getAllCategories());

        return controller::getSelected;
    }

    public static RecyclerListController<Category> loadCategoriesSmallInto2(RecyclerView recyclerView) {
        CategoryRowSmallAdapter adapter = new CategoryRowSmallAdapter();
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static SingleSelectableRecyclerListController<FundraisingTypeData> loadFundraisingTypeSmallInto(
            RecyclerView recyclerView,
            Consumer<FundraisingTypeData> onSelect) {
        CampaignTypeRowSmallAdapter adapter = new CampaignTypeRowSmallAdapter();
        adapter.setOnSelect(onSelect);
        recyclerView.setAdapter(adapter);

        return new SingleSelectableRecyclerListController<>(adapter);
    }

    public static RecyclerListController<FullDonationInfo> loadDonationsInto(
            RecyclerView recyclerView,
            Consumer<FullDonationInfo> onClick) {
        DonationRowAdapter adapter = new DonationRowAdapter();
        adapter.setOnClick(onClick);
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static RecyclerListController<FullDonationInfo> loadDonationsFullInto(
            RecyclerView recyclerView,
            Consumer<FullDonationInfo> onClick) {
        DonationFullRowAdapter adapter = new DonationFullRowAdapter();
        adapter.setOnClick(onClick);
        recyclerView.setAdapter(adapter);

        return new RecyclerListController<>(adapter);
    }

    public static SingleSelectableRecyclerListController<PaymentMethod> loadPaymentMethodsInto(
            RecyclerView recyclerView,
            Consumer<PaymentMethod> onClick) {
        PaymentMethodRowAdapter adapter = new PaymentMethodRowAdapter();
        adapter.setOnSelect(onClick);
        recyclerView.setAdapter(adapter);

        return new SingleSelectableRecyclerListController<>(adapter);
    }
}
