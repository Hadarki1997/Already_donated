package com.alreadydone.util.future;

import android.os.Looper;

import com.alreadydone.util.Result;
import com.alreadydone.util.RunningJob;

import java.util.function.Consumer;
import java.util.function.Function;

public class GenericFuture<T> implements Future<T> {

    private final Object bean;
    private final Consumer<Consumer<Result<T>>> onComplete;

    public GenericFuture(Object bean, Consumer<Consumer<Result<T>>> onComplete) {
        this.bean = bean;
        this.onComplete = onComplete;
    }

    @Override
    public <R> Future<R> as(Function<T, R> converter) {
        return new GenericConvertedFuture<>(bean, onComplete, converter, null);
    }

    @Override
    public Future<T> convertError(Function<Throwable, Result<T>> converter) {
        return new GenericConvertedFuture<>(bean, onComplete, (v)-> v, converter);
    }

    @Override
    public <R> Future<R> andThen(Function<T, Future<R>> converter) {
        RunningJob<R> job = new RunningJob<>(Looper.getMainLooper());
        onComplete((result)-> {
            if (result.hasError()) {
                job.markErrored(result.getError());
            } else {
                try {
                    Future<R> finalFuture = converter.apply(result.getValue());
                    finalFuture.onComplete(job::markComplete);
                } catch (Throwable t) {
                    job.markErrored(t);
                }
            }
        });

        return Future.create(job);
    }

    @Override
    public void onComplete(Consumer<Result<T>> consumer) {
        onComplete.accept(consumer);
    }
}
