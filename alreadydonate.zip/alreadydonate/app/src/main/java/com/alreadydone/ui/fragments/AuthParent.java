package com.alreadydone.ui.fragments;

import java.util.function.Consumer;

public interface AuthParent {
    class AutoInfo {
        public String email;
        public String password;
    }

    String getBtnText();

    void acceptAuthInfo(AutoInfo info, Consumer<String> onError);
}
