# alreadydone-project

Repository for the AlreadyDonated donation app. Allowing users to create fundraising campaigns and receive
donations from other users of the application. Generally, users of the application are divided into _associations_ which
create fundraising requests, and _normal users_ which browse, track and donate to created fundraising campaigns.

This application was written for android, using the Java API framework targeting most modern android devices.
- Minimum Supported version: Android 11 (_Red Velvet Cake_, SDK Level `30`)
- Targeted version: Android 14 (_Upside Down Cake_, SDK Level `34`)

## Setting Up for Build

Building (or developing for) the application requires an installation of _Android Studio_ with Android SDK 34 also installed. Simply get the project
files and open the folder with _Android Studio_. Let the IDE load the project and download necessary dependencies. Due to the use of _Gradle_ no additional
work is required for preparation of the code.

The application uses several external services. To allow deploying the project with these services being supported, you will need to provide access tokens for these services.

### Firebase

The application uses several _Firebase_ services, namely:
- Authentication
- Storage
- Realtime Database

For the application to be able to access this, you will need to provide a file with access tokens to a firebase project with these services configured.
Follow steps 1-3 [here](https://firebase.google.com/docs/android/setup#console) to retreive and add this file.

### Google Places API

The application uses the _Places API_ service from _Google Cloud_. 

For the application to be able to access this, a token must be provided. This is completely optional, as the application can function without this service.
Create and configure a Google Cloud project with Places API and export an API key. Create (in the root of the application project) the file `secrets.properties` and add a line
```
PLACES_API_KEY=your api key
```

If access to this service isn't wanted or required, instead create (in the root of the application project) the file `local.defaults.properties` with the data
```
PLACES_API_KEY=DEFAULT_API_KEY
```
